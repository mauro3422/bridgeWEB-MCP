import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  MAX_PROJECT_CONTEXT_CHARS,
  MAX_SEGMENTED_PROJECT_CONTEXT_SOURCE_BYTES,
  loadProjectContextModuleManifest,
  loadProjectContextModules,
  readBoundedMarkdown,
  extractProjectContextSections,
  safeMarkdownPath,
} from "../dist/project-context-loader.js";
import { structuredSkillIntentSchema } from "../dist/index.js";

const base = await fs.mkdtemp(path.join(os.tmpdir(), "mssr-project-context-loader-"));

function mod(id, overrides = {}) {
  return { id, path: `${id}.md`, priority: 0, required: false, estimatedChars: 256, ...overrides };
}

async function writeFixture(name, { modules = [], core = [], files = {}, withManifest = true }) {
  const root = path.join(base, name);
  await fs.rm(root, { recursive: true, force: true });
  await fs.mkdir(path.join(root, ".mssr"), { recursive: true });
  await fs.mkdir(path.join(root, "docs"), { recursive: true });
  if (withManifest) {
    const toRich = (module) => ({
      id: module.id,
      kind: "context",
      description: `Fixture ${module.id}`,
      source: { path: module.path },
      stages: module.stages ?? [],
      domains: module.domains ?? [],
      actions: module.actions ?? [],
      artifacts: module.artifacts ?? [],
      needs: module.needs ?? [],
      signals: module.signals ?? [],
      priority: module.priority ?? 0,
      required: module.required ?? false,
      ...(module.maxChars !== undefined ? { maxChars: module.maxChars } : {}),
      ...(module.requiredWhen ? { requiredWhen: module.requiredWhen } : {}),
      ...(module.exclusiveGroup ? { exclusiveGroup: module.exclusiveGroup } : {}),
    });
    const coreSet = new Set(core);
    await fs.writeFile(
      path.join(root, ".mssr", "project-context.json"),
      JSON.stringify({
        schemaVersion: 1,
        core: modules.filter((module) => coreSet.has(module.id)).map((module) => {
          const rich = toRich(module);
          return { id: rich.id, kind: rich.kind, description: rich.description, source: rich.source };
        }),
        modules: modules.filter((module) => !coreSet.has(module.id)).map(toRich),
      }),
      "utf8",
    );
  }
  for (const [rel, content] of Object.entries(files)) {
    const target = path.join(root, rel);
    await fs.mkdir(path.dirname(target), { recursive: true });
    await fs.writeFile(target, content, "utf8");
  }
  return root;
}

function intent(overrides = {}) {
  return structuredSkillIntentSchema.parse({
    domains: ["coding"],
    actions: ["edit"],
    needs: [],
    signals: ["nominal"],
    risk: "write",
    ambiguity: "low",
    ...overrides,
  });
}

const intentEdit = intent({ domains: ["coding"], actions: ["edit"] });
const intentBlender = intent({ domains: ["blender"], actions: ["discover"], risk: "read-only" });

try {
  const repositoryRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
  const repositoryManifest = JSON.parse(await fs.readFile(path.join(repositoryRoot, ".mssr", "project-context.json"), "utf8"));
  assert.equal(repositoryManifest.modules.length, 55, "the indexed expansion/adoption, project-evidence, bootstrap-friction, and script-promotion handoffs are included with the existing scoped operation modules");
  const crossRepoOwnershipEntry = repositoryManifest.modules.find((entry) => entry.id === "cross-repo-asset-ownership-transaction");
  assert.ok(crossRepoOwnershipEntry, "the existing cross-repo ownership carrier remains the owner of pre-mutation project guidance");
  assert.deepEqual(crossRepoOwnershipEntry.requiredWhen, { mutation: true, artifacts: ["animation"] }, "animation mutations require the existing ownership guidance before tool selection");
  assert.ok(crossRepoOwnershipEntry.actions.includes("create"));
  assert.ok(crossRepoOwnershipEntry.artifacts.includes("animation"));
  const crossRepoAnimationCreation = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Create a GIF animation requested from AURO 3D context; confirm whether AURO Motions owns this production phase before choosing a tool",
      domains: ["blender", "agent-orchestration"],
      actions: ["create"],
      artifacts: ["animation"],
      needs: ["cross-agent"],
      signals: ["nominal"],
      risk: "write",
    }),
    stage: "implement",
    maxChars: 6_000,
  });
  const crossRepoAnimationModule = crossRepoAnimationCreation.selected.find((record) => record.ref === "cross-repo-asset-ownership-transaction");
  assert.ok(crossRepoAnimationModule, "cross-project animation mutation must load owner guidance before the host selects a write tool");
  assert.deepEqual(crossRepoAnimationCreation.decisions.find((decision) => decision.id === crossRepoOwnershipEntry.id)?.requiredBy, ["mutation", "artifact:animation"]);
  assert.match(crossRepoAnimationModule.content, /antes de seleccionar la primera herramienta de escritura/i);
  assert.match(crossRepoAnimationModule.content, /No cambiar la raíz automáticamente/i);
  const readOnlyProjectInventory = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Read-only inventory of current AURO 3D files and project sources",
      domains: ["filesystem"],
      actions: ["discover"],
      artifacts: ["project", "document"],
      needs: [],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "start",
    maxChars: 6_000,
  });
  assert.ok(!readOnlyProjectInventory.selected.some((record) => record.ref === "cross-repo-asset-ownership-transaction"), "ordinary read-only inventory must not load cross-repo mutation guidance");
  const scriptPromotionEntry = repositoryManifest.modules.find((entry) => entry.id === "promocion-scripts-a-herramientas-handoff");
  assert.ok(scriptPromotionEntry, "the script-promotion operations handoff must be indexed");
  const scriptPromotionPositive = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Review a repeated manual script workaround for a reusable MCP tool in its owning provider project",
      domains: ["coding"],
      actions: ["analyze"],
      artifacts: ["mcp"],
      needs: ["unit-tests"],
      signals: ["manual-workaround"],
      risk: "write",
    }),
    stage: "implement",
    maxChars: 6_000,
  });
  const scriptPromotionRecord = scriptPromotionPositive.selected.find((record) => record.ref === scriptPromotionEntry.id);
  assert.ok(scriptPromotionRecord, "reusable script-promotion work must select its indexed owner handoff");
  assert.match(scriptPromotionRecord.content, /Decidir entre reutilizar, extender, promover o conservar el script/);
  assert.ok(scriptPromotionPositive.core.reduce((sum, record) => sum + record.bytes, 0)
    + scriptPromotionPositive.selected.reduce((sum, record) => sum + record.bytes, 0) <= 6_000,
  "the positive script-promotion route must stay within the standard project-context budget");
  const scriptPromotionContinuation = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Resume the owning provider's script-to-tool promotion handoff after reviewing a reusable workaround",
      domains: ["coding"],
      actions: ["review", "maintain"],
      artifacts: ["mcp"],
      needs: ["unit-tests"],
      signals: ["reusable-pattern"],
      risk: "write",
    }),
    stage: "resume",
    maxChars: 6_000,
  });
  assert.ok(scriptPromotionContinuation.selected.some((record) => record.ref === scriptPromotionEntry.id),
    "a matching handoff must remain recoverable on continuation");
  const scriptPromotionNegative = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Read-only inventory of project files without promoting scripts",
      domains: ["filesystem"],
      actions: ["discover"],
      artifacts: ["project", "document"],
      needs: [],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "start",
    maxChars: 6_000,
  });
  assert.ok(!scriptPromotionNegative.selected.some((record) => record.ref === scriptPromotionEntry.id),
    "ordinary read-only inventory must not activate the script-promotion handoff");
  const bootstrapFrictionEntry = repositoryManifest.modules.find((entry) => entry.id === "mssr-bootstrap-friction-handoff");
  assert.ok(bootstrapFrictionEntry, "the bootstrap-friction handoff must be indexed");
  const bootstrapFrictionIntent = (signals, actions) => intent({
    summary: "Recover a repeated lifecycle preflight denial and its missing trace correlation",
    domains: ["skill-system", "agent-orchestration", "filesystem"],
    actions,
    artifacts: ["mcp", "repository", "document"],
    needs: ["history-recovery", "cross-agent"],
    signals,
    risk: "read-only",
    ambiguity: "low",
  });
  const bootstrapFrictionPositive = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: bootstrapFrictionIntent(["recovery-needed", "repeated-friction"], ["recover", "debug", "review"]),
    stage: "resume",
    maxChars: 6_000,
  });
  assert.ok(bootstrapFrictionPositive.selected.some((record) => record.ref === bootstrapFrictionEntry.id), "the bootstrap-friction handoff must fit and activate under the standard 6000-character project-context budget");
  assert.ok(bootstrapFrictionPositive.core.reduce((sum, record) => sum + record.bytes, 0) + bootstrapFrictionPositive.selected.reduce((sum, record) => sum + record.bytes, 0) <= 6_000, "the positive route must stay within the standard project-context budget");
  const bootstrapFrictionNegative = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: bootstrapFrictionIntent(["nominal"], ["review", "analyze"]),
    stage: "start",
    maxChars: 6_000,
  });
  assert.ok(!bootstrapFrictionNegative.selected.some((record) => record.ref === bootstrapFrictionEntry.id), "a nominal router review must not activate the bootstrap-friction handoff");
  const projectEvidenceNeedsEntry = repositoryManifest.modules.find((entry) => entry.id === "project-evidence-needs-handoff");
  assert.ok(projectEvidenceNeedsEntry, "the project evidence-needs handoff must be indexed");
  const projectEvidenceNeeds = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Review project evidence requirements and verified references",
      domains: ["skill-system", "agent-orchestration", "filesystem", "artifacts"],
      actions: ["discover", "review", "design", "verify", "recover", "coordinate"],
      artifacts: ["project", "document", "mcp", "skill"],
      needs: ["cross-agent", "integrity-verification", "history-recovery"],
      signals: ["reusable-pattern", "missing-capability", "capability-discovery-needed", "tool-chain-needed"],
    }),
    stage: "start",
    includeCore: false,
    maxChars: 20_000,
    maxModules: 40,
  });
  const selectedProjectEvidenceNeeds = projectEvidenceNeeds.selected.find((record) => record.ref === projectEvidenceNeedsEntry.id);
  assert.ok(selectedProjectEvidenceNeeds, "structured project evidence-needs intent selects its indexed handoff");
  assert.match(selectedProjectEvidenceNeeds.content, /## Contratos existentes: reutilizar antes de ampliar/);
  const driftReviewEntry = repositoryManifest.modules.find((entry) => entry.id === "mssr-project-knowledge-drift-review");
  assert.ok(driftReviewEntry, "the project knowledge drift review module must stay indexed");
  const instructionImpactIntent = (summary, signals = ["conflicting-evidence", "reusable-pattern"], artifacts = ["code", "project", "repository", "mcp"]) => intent({
    summary,
    domains: ["skill-system", "agent-orchestration", "filesystem"],
    actions: ["review", "maintain", "verify"],
    artifacts,
    needs: ["cross-agent", "integrity-verification", "version-control"],
    signals,
    risk: "read-only",
  });
  const instructionImpactPositive = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: instructionImpactIntent("Revisar impacto de instrucciones y adopción de regla transversal en MSSR", undefined, ["skill"]),
    stage: "verify",
    maxChars: 6_000,
  });
  const instructionImpactRecord = instructionImpactPositive.selected.find((record) => record.ref === driftReviewEntry.id);
  assert.ok(instructionImpactRecord, "instruction-impact intent must load its compact module/handoff within the standard budget");
  assert.match(instructionImpactRecord.content, /## MSSR resumption summary/);
  assert.equal(instructionImpactRecord.referenceDecisions.find((item) => item.id === "mssr-instruction-impact-review-resume")?.selected, true);
  assert.equal(instructionImpactRecord.referenceDecisions.find((item) => item.id === "mssr-instruction-impact-review-implementation")?.selected, false);
  assert.ok(instructionImpactRecord.bytes < 1_260, "the compact instruction-impact handoff must preserve headroom under the standard budget");
  const instructionImpactBudgetUse = instructionImpactPositive.core.reduce((sum, record) => sum + record.bytes, 0) + instructionImpactPositive.selected.reduce((sum, record) => sum + record.bytes, 0);
  assert.ok(instructionImpactBudgetUse <= 6_000, `instruction-impact selection must stay within 6,000 bytes, used ${instructionImpactBudgetUse}`);
  const instructionImpactNegative = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: instructionImpactIntent("Revisión normal del router sin cambios transversales", ["nominal"]),
    stage: "verify",
    maxChars: 6_000,
  });
  assert.ok(!instructionImpactNegative.selected.some((record) => record.ref === driftReviewEntry.id), "ordinary router review must not load project instruction-impact context");
  const instructionImpactDetail = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: instructionImpactIntent("Revisar evaluadores puros e implementación MSSR", undefined, ["skill"]),
    stage: "verify",
    includeCore: false,
    maxChars: 20_000,
  });
  const instructionImpactDetailRecord = instructionImpactDetail.selected.find((record) => record.ref === driftReviewEntry.id);
  assert.ok(instructionImpactDetailRecord, "explicit fixture/contract intent must load the detailed instruction-impact handoff");
  assert.match(instructionImpactDetailRecord.content, /## Implementación MSSR acotada/);
  assert.equal(instructionImpactDetailRecord.referenceDecisions.find((item) => item.id === "mssr-instruction-impact-review-implementation")?.selected, true);
  assert.equal(instructionImpactDetailRecord.referenceDecisions.find((item) => item.id === "mssr-instruction-impact-review-resume")?.selected, false);
  const instructionImpactAdoption = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: instructionImpactIntent("Revisar adopción host y criterio de notice", undefined, ["skill"]),
    stage: "verify",
    includeCore: false,
    maxChars: 20_000,
  });
  const instructionImpactAdoptionRecord = instructionImpactAdoption.selected.find((record) => record.ref === driftReviewEntry.id);
  assert.ok(instructionImpactAdoptionRecord, "explicit host-adoption intent must load its bounded adoption reference");
  assert.match(instructionImpactAdoptionRecord.content, /## Brecha restante: registro y adopción host/);
  assert.ok(instructionImpactAdoptionRecord.bytes < 3_200, "host adoption context must remain within the revised module budget");
  const instructionImpactNotice = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: instructionImpactIntent("Revisar criterio de notice para consumidor real conocido", undefined, ["skill"]),
    stage: "verify",
    includeCore: false,
    maxChars: 20_000,
  });
  const instructionImpactNoticeRecord = instructionImpactNotice.selected.find((record) => record.ref === driftReviewEntry.id);
  assert.ok(instructionImpactNoticeRecord, "explicit notice intent must load its bounded criteria reference");
  assert.match(instructionImpactNoticeRecord.content, /## Instrucciones y criterio de notice/);
  assert.equal(instructionImpactNoticeRecord.referenceDecisions.find((item) => item.id === "mssr-instruction-impact-review-notice")?.selected, true);
  const indexedHandoffCases = [
    {
      id: "mssr-history-proposal-20261110",
      summary: "Revisar el historial de contexto de MSSR",
      pattern: /Handoff diferido: historial consultable de contexto de proyecto/,
    },
    {
      id: "mssr-host-github-capability-20261111",
      summary: "Revisar las capacidades del host GitHub y su autenticación",
      pattern: /## Estado vigente — 2026-11-13/,
    },
    {
      id: "mssr-visual-identity-handoff-20261111",
      summary: "Revisar el handoff de identidad visual de proyecto",
      pattern: /## Estado vigente — 2026-11-12/,
    },
    {
      id: "mssr-project-checklist-handoff-20261111",
      summary: "Revisar el checklist de proyecto y continuidad",
      pattern: /checklist de proyecto y continuidad MSSR/,
    },
    {
      id: "mssr-auto-handoff-indexing-20261112",
      summary: "Revisar la indexación automática de handoffs MSSR",
      pattern: /indexación automática de handoffs MSSR/,
    },
    {
      id: "mssr-limpieza-continua-temporales-20261112",
      summary: "Revisar limpieza continua de temporales y estado operativo",
      pattern: /## Estado vigente — 2026-11-12/,
    },
  ];
  for (const handoffCase of indexedHandoffCases) {
    const indexedHandoff = await loadProjectContextModules({
      projectRoot: repositoryRoot,
      intent: intent({
        summary: handoffCase.summary,
        domains: ["skill-system", "agent-orchestration"],
        actions: ["create", "document", "coordinate"],
        artifacts: ["project", "document"],
        needs: ["cross-agent", "integrity-verification"],
        signals: ["reusable-pattern"],
      }),
      stage: "implement",
      includeCore: false,
      maxChars: 20_000,
      maxModules: 40,
    });
    const handoffCarrier = indexedHandoff.selected.find((record) => record.ref === "mssr-module-handoff-capability-escalation");
    assert.ok(handoffCarrier, `handoff intent should select the carrier module for ${handoffCase.id}`);
    assert.match(handoffCarrier.content, handoffCase.pattern, `handoff intent should load ${handoffCase.id}`);
    assert.equal(handoffCarrier.referenceDecisions.find((item) => item.id === handoffCase.id)?.selected, true);
    if (handoffCase.id === "mssr-host-github-capability-20261111") {
      assert.match(handoffCarrier.content, /sesión autenticada sigue válida mientras el host declare activa/);
      assert.doesNotMatch(handoffCarrier.content, /El mismo push funcionó con/);
      assert.ok(handoffCarrier.bytes < 3_000, "ordinary host capability context should not load the full historical GitHub incident");
    }
    if (handoffCase.id === "mssr-visual-identity-handoff-20261111") {
      assert.ok(handoffCarrier.bytes < 3_000, "ordinary visual identity context should load only the current project-owned disposition");
      assert.doesNotMatch(handoffCarrier.content, /## Investigación propuesta/);
    }
    if (handoffCase.id === "mssr-limpieza-continua-temporales-20261112") {
      assert.ok(handoffCarrier.bytes < 3_000, "ordinary cleanup context should load the compact ownership/status summary");
      assert.doesNotMatch(handoffCarrier.content, /## Contrato propuesto para estudiar/);
    }
  }
  const tlsHandoff = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Investigar el error de certificados GitHub y TLS schannel en un Git push",
      domains: ["skill-system", "agent-orchestration"],
      actions: ["create", "document", "coordinate"],
      artifacts: ["project", "document"],
      needs: ["cross-agent", "integrity-verification"],
      signals: ["reusable-pattern"],
    }),
    stage: "implement",
    includeCore: false,
    maxChars: 20_000,
    maxModules: 40,
  });
  const tlsCarrier = tlsHandoff.selected.find((record) => record.ref === "mssr-module-handoff-capability-escalation");
  assert.ok(tlsCarrier, "specific TLS investigation selects the same owner carrier");
  assert.equal(tlsCarrier.referenceDecisions.find((item) => item.id === "mssr-host-github-tls-incident")?.selected, true);
  assert.match(tlsCarrier.content, /sslBackend=schannel/);
  const visualResearch = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Investigar patrones visuales y personalidad por proyecto con recuperación por intención visual",
      domains: ["skill-system", "agent-orchestration"],
      actions: ["create", "document", "coordinate"],
      artifacts: ["project", "document"],
      needs: ["cross-agent", "integrity-verification"],
      signals: ["reusable-pattern"],
    }),
    stage: "implement",
    includeCore: false,
    maxChars: 20_000,
    maxModules: 40,
  });
  const visualCarrier = visualResearch.selected.find((record) => record.ref === "mssr-module-handoff-capability-escalation");
  assert.ok(visualCarrier);
  assert.equal(visualCarrier.referenceDecisions.find((item) => item.id === "mssr-visual-pattern-research")?.selected, true);
  assert.match(visualCarrier.content, /## Investigación propuesta/);
  const cleanupDetail = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Definir ciclo de vida de temporales, promoción de experimentos y pruebas cleanup temporal seguro",
      domains: ["skill-system", "agent-orchestration"],
      actions: ["create", "document", "coordinate"],
      artifacts: ["project", "document"],
      needs: ["cross-agent", "integrity-verification"],
      signals: ["reusable-pattern"],
    }),
    stage: "implement",
    includeCore: false,
    maxChars: 20_000,
    maxModules: 40,
  });
  const cleanupCarrier = cleanupDetail.selected.find((record) => record.ref === "mssr-module-handoff-capability-escalation");
  assert.ok(cleanupCarrier);
  assert.equal(cleanupCarrier.referenceDecisions.find((item) => item.id === "mssr-temporary-cleanup-contract")?.selected, true);
  assert.match(cleanupCarrier.content, /## Contrato propuesto para estudiar/);
  assert.match(cleanupCarrier.content, /## Criterios de aceptación y siguiente paso/);
  assert.ok(cleanupCarrier.bytes < 7_500, "specific cleanup planning receives bounded contract/acceptance detail");
  const expansionRoadmapIntent = intent({
    summary: "Plan project maintenance notice delivery",
    domains: ["skill-system", "agent-orchestration", "filesystem"],
    actions: ["discover", "design", "review", "verify", "maintain", "document"],
    artifacts: ["skill", "project", "repository", "mcp", "document"],
    needs: ["integrity-verification", "cross-agent"],
    signals: ["missing-capability", "reusable-pattern", "conflicting-evidence", "replan-needed"],
  });
  const expansionRoadmap = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: expansionRoadmapIntent,
    stage: "start",
    maxChars: 8_000,
  });
  const selectedExpansionRoadmap = expansionRoadmap.selected.find((record) => record.ref === "mssr-module-expansion-adoption-roadmap-20261112");
  assert.ok(selectedExpansionRoadmap, "structured expansion/adoption work selects its roadmap");
  assert.match(selectedExpansionRoadmap.content, /## Findings and notice rule/, "the matching activation-notice segment loads with the compact card");
  assert.ok(selectedExpansionRoadmap.bytes < 900, "the activation card and selected detail stay within the module budget");
  const taskMapIntent = intent({ ...expansionRoadmapIntent, summary: "Stabilize MSSR task map and workstream inventory" });
  const taskMapContext = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: taskMapIntent,
    stage: "verify",
    maxChars: 8_000,
  });
  const selectedTaskMap = taskMapContext.selected.find((record) => record.ref === "mssr-module-expansion-adoption-roadmap-20261112");
  assert.ok(selectedTaskMap, "structured MSSR task-map intent selects the expansion roadmap");
  assert.match(selectedTaskMap.content, /## MSSR task-map activation summary/);
  assert.match(selectedTaskMap.content, /142 ownership.*pure contract\/tests done/);
  assert.ok(selectedTaskMap.bytes < 900, "the compact task map fits beside the project core in the ordinary context budget");
  const detailedTaskMapContext = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({ ...expansionRoadmapIntent, summary: "Show detailed MSSR workstream paths and owner gates" }),
    stage: "verify",
    maxChars: 10_000,
  });
  const selectedDetailedTaskMap = detailedTaskMapContext.selected.find((record) => record.ref === "mssr-module-expansion-adoption-roadmap-20261112");
  assert.ok(selectedDetailedTaskMap, "an explicit deep-review intent selects detailed workstream paths");
  assert.match(selectedDetailedTaskMap.content, /## MSSR task map — observed working tree/);
  assert.match(selectedDetailedTaskMap.content, /mixed task set, not commit boundaries/);
  assert.ok(selectedDetailedTaskMap.bytes < 4000, "the detailed map remains under its expanded module budget");
  const projectOwnerSnapshot = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({ ...expansionRoadmapIntent, summary: "Stabilize AURO TECH and Motions repositories" }),
    stage: "start",
    maxChars: 8_000,
  });
  const selectedProjectSnapshot = projectOwnerSnapshot.selected.find((record) => record.ref === "mssr-module-expansion-adoption-roadmap-20261112");
  assert.ok(selectedProjectSnapshot, "explicit project stabilization selects the expansion register");
  assert.match(selectedProjectSnapshot.content, /## AURO TECH and Motions snapshot/);
  assert.ok(selectedProjectSnapshot.bytes < 900, "project snapshot remains within the module budget");
  const unrelatedExpansion = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({ domains: ["blender"], actions: ["discover"], artifacts: ["asset"], risk: "read-only" }),
    stage: "implement",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  assert.equal(unrelatedExpansion.selected.some((record) => record.ref === "mssr-module-expansion-adoption-roadmap-20261112"), false, "unrelated asset inspection does not load the MSSR adoption roadmap");
  assert.equal(repositoryManifest.modules.some((entry) => entry.id === "mssr-jev-live-paired-source-diagnostic-20261011"), false);
  assert.equal(repositoryManifest.modules.some((entry) => entry.id === "mssr-jev-confidence-cross-project-follow-ups-20261012"), false, "historical detail should be a segment of the existing run-history module");
  const crossProjectFollowUpsSource = await fs.readFile(path.join(repositoryRoot, ".mssr/knowledge/reference/mssr-jev-confidence-run-history.md"), "utf8");
  const crossProjectFollowUpsHeading = "## Cross-project live follow-ups: Runs 62–63 (2026-10-12)";
  assert.equal(
    createHash("sha256").update(extractProjectContextSections(crossProjectFollowUpsSource, [crossProjectFollowUpsHeading]), "utf8").digest("hex"),
    "0fc901ba86f368043703f2f601072f2d6866ac563821ccdaa4f3bea408e7e05e",
    "the exact Runs 62–63 follow-up section must survive the history split byte-for-byte",
  );
  const liveSmokeEntry = repositoryManifest.modules.find((entry) => entry.id === "mssr-jev-live-bridge-smoke-20261011");
  assert.ok(liveSmokeEntry, "the parent live-smoke module must remain independently selectable");
  const pairedHistorySource = await fs.readFile(path.join(repositoryRoot, ".mssr/knowledge/reference/jev-mssr-live-bridge-smoke-20261011.md"), "utf8");
  const pairedHistoryHash = createHash("sha256").update(extractProjectContextSections(pairedHistorySource, [
    "## Paired source-grouped development diagnostic — 2026-10-11",
  ]), "utf8").digest("hex");
  assert.equal(pairedHistoryHash, "bfbe3ac8082a1dff70de17241a917c85f499c2006cc02249c5abd4b45743c2f7", "the indexed paired diagnostic must preserve its historical source section byte-for-byte");
  const liveSmokeIntent = (summary, signals = ["uncertainty"]) => intent({
    summary,
    domains: ["coding", "filesystem"],
    actions: ["analyze", "verify"],
    artifacts: ["document", "repository", "mcp"],
    needs: ["integrity-verification"],
    signals,
    risk: "read-only",
  });
  const baselineLiveSmoke = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: liveSmokeIntent("Review the live MSSR Bridge Jev smoke reproducibility"),
    stage: "verify",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  const baselineLiveSmokeRecord = baselineLiveSmoke.selected.find((record) => record.ref === liveSmokeEntry.id);
  assert.ok(baselineLiveSmokeRecord, "the parent module should still load for its original stage and intent");
  assert.match(baselineLiveSmokeRecord.content, /## Bilingual abstention and range-precision follow-up/);
  assert.doesNotMatch(baselineLiveSmokeRecord.content, /## Paired source-grouped development diagnostic/);
  assert.equal(baselineLiveSmokeRecord.segmentDecisions.find((decision) => decision.id === "live-smoke-baseline")?.selected, true);
  assert.equal(baselineLiveSmokeRecord.segmentDecisions.find((decision) => decision.id === "paired-source-diagnostic")?.reason, "intent-mismatch");
  const pairedLiveSmoke = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: liveSmokeIntent("Review paired source-grouped development diagnostic Bridge 0.6.167 MSSR 0.2.115"),
    stage: "verify",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  const pairedLiveSmokeRecord = pairedLiveSmoke.selected.find((record) => record.ref === liveSmokeEntry.id);
  assert.ok(pairedLiveSmokeRecord, "the exact paired diagnostic intent should select its parent module");
  assert.ok(pairedLiveSmokeRecord.bytes <= liveSmokeEntry.maxChars, "baseline plus the selected historical section must remain within the parent's declared context budget");
  assert.match(pairedLiveSmokeRecord.content, /## Paired source-grouped development diagnostic/);
  assert.equal(pairedLiveSmokeRecord.segmentDecisions.find((decision) => decision.id === "paired-source-diagnostic")?.selected, true);
  const missingUncertainty = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: liveSmokeIntent("Review paired source-grouped development diagnostic Bridge 0.6.167 MSSR 0.2.115", ["conflicting-evidence"]),
    stage: "verify",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  const missingUncertaintyRecord = missingUncertainty.selected.find((record) => record.ref === liveSmokeEntry.id);
  assert.ok(missingUncertaintyRecord, "the parent remains eligible on its conflicting-evidence selector");
  assert.doesNotMatch(missingUncertaintyRecord.content, /## Paired source-grouped development diagnostic/);
  assert.equal(missingUncertaintyRecord.segmentDecisions.find((decision) => decision.id === "paired-source-diagnostic")?.reason, "intent-mismatch");
  const semanticEvidenceEntry = repositoryManifest.modules.find((entry) => entry.id === "mssr-semantic-evidence-plane");
  assert.ok(semanticEvidenceEntry, "the semantic evidence plane must remain an indexed project-context module");
  assert.equal(semanticEvidenceEntry.maxChars, 10_000, "segmentation must solve pressure without raising the declared entry budget");

  const semanticEvidenceLibrarian = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "MSSR bibliotecario Jev búsqueda exacta y fetch de evidencia",
      domains: ["coding"],
      actions: ["analyze"],
      artifacts: ["document"],
      needs: ["integrity-verification"],
      signals: ["tool-chain-needed"],
      risk: "read-only",
    }),
    stage: "implement",
    maxChars: 20_000,
    maxModules: 32,
    includeCore: false,
  });
  const evidencePlane = semanticEvidenceLibrarian.selected.find((record) => record.ref === "mssr-semantic-evidence-plane");
  assert.ok(evidencePlane, "the repository's semantic evidence plane should load for Librarian/Jev work");
  assert.ok(evidencePlane.bytes <= 10_000, "selected EvidenceAtom + Librarian sections must stay within the declared 10k budget");
  assert.match(evidencePlane.content, /## Core Document and Librarian guarantees/);
  assert.doesNotMatch(evidencePlane.content, /## Document Surface and Librarian contract/);
  assert.match(evidencePlane.content, /same source revision/);
  assert.equal(evidencePlane.segmentDecisions.some((decision) => decision.id === "document-surface-librarian-details"), false);
  const librarianContract = semanticEvidenceLibrarian.selected.find((record) => record.ref === "mssr-document-surface-librarian-contract");
  assert.ok(librarianContract, "focused Librarian work should load its independently budgeted contract module");
  assert.ok(librarianContract.bytes <= 10_000);
  assert.match(librarianContract.content, /## Document Surface and Librarian contract/);
  assert.equal(librarianContract.segmentDecisions.find((decision) => decision.id === "document-surface-librarian-details")?.selected, true);
  const librarianContractSource = await fs.readFile(path.join(repositoryRoot, ".mssr/knowledge/architecture/document-surface-librarian-contract.md"), "utf8");
  assert.equal(
    createHash("sha256").update(extractProjectContextSections(librarianContractSource, ["## Document Surface and Librarian contract"]), "utf8").digest("hex"),
    "168fe012f29f5f39d66260be18618e5b8dd0bf3f40047d45b1c2e66a368f3fbd",
    "the extracted Librarian contract must preserve the hash-addressed source section",
  );
  assert.deepEqual(semanticEvidenceLibrarian.ambiguousSegments, []);

  const semanticEvidenceTriage = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Jev semantic triage reduction batching and circuit breaking",
      domains: ["coding"],
      actions: ["analyze"],
      artifacts: ["project"],
      needs: ["integrity-verification"],
      signals: ["tool-chain-needed"],
      risk: "read-only",
    }),
    stage: "implement",
    maxChars: 20_000,
    maxModules: 32,
    includeCore: false,
  });
  const triagePlane = semanticEvidenceTriage.selected.find((record) => record.ref === "mssr-semantic-evidence-plane");
  assert.ok(triagePlane, "the repository's semantic evidence plane should load for Jev triage work");
  assert.ok(triagePlane.bytes <= 10_000, "selected EvidenceAtom + Jev triage sections must stay within the declared 10k budget");
  assert.match(triagePlane.content, /## Reduction, batching and semantic triage/);
  assert.equal(triagePlane.segmentDecisions.find((decision) => decision.id === "reduction-semantic-triage")?.selected, true);
  assert.deepEqual(semanticEvidenceTriage.ambiguousSegments, []);

  const jevBenchmarkContext = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Jev confidence gates and measured MSSR Librarian benchmark history",
      domains: ["coding", "agent-orchestration", "skill-system"],
      actions: ["analyze", "review", "verify"],
      artifacts: ["project", "repository", "document"],
      needs: ["integrity-verification", "cross-agent"],
      signals: ["uncertainty", "conflicting-evidence"],
      risk: "read-only",
    }),
    stage: "verify",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  const jevById = new Map(jevBenchmarkContext.selected.map((record) => [record.ref, record]));
  assert.equal(repositoryManifest.modules.find((entry) => entry.id === "mssr-jev-confidence-merge-policy")?.curationScope, "research");
  const confidencePolicy = jevById.get("mssr-jev-confidence-merge-policy");
  const runHistory = jevById.get("mssr-jev-confidence-run-history");
  const crossProjectFollowUps = jevById.get("mssr-jev-confidence-cross-project-follow-ups-20261012");
  const evaluationProtocol = jevById.get("mssr-jev-confidence-benchmark-history");
  const connectedDiagnostics = jevById.get("mssr-jev-connected-diagnostics-20261011");
  assert.ok(confidencePolicy, "research scope must not suppress normal Jev context selection");
  assert.ok(runHistory, "Jev benchmark review should load measured run history independently");
  assert.equal(crossProjectFollowUps, undefined, "resume-only historical detail must not crowd ordinary benchmark context");
  assert.equal(runHistory.segmentDecisions.find((decision) => decision.id === "cross-project-runs-62-63")?.selected, false);
  assert.doesNotMatch(runHistory.content, /## Cross-project live follow-ups: Runs 62–63/);
  assert.ok(evaluationProtocol, "Jev benchmark review should retain the active evaluation protocol");
  assert.ok(connectedDiagnostics, "Jev benchmark review should load the recent connected diagnostic module independently");
  const selectorReleaseHistory = jevById.get("mssr-jev-librarian-selector-release-history");
  assert.ok(selectorReleaseHistory, "Jev benchmark review should load the exact selector release history");
  assert.ok(confidencePolicy.bytes < 4_000);
  assert.ok(runHistory.bytes < 6_500);
  assert.ok(evaluationProtocol.bytes < 1_800);
  assert.match(confidencePolicy.content, /uncalibrated; do not call a raw threshold/i);
  assert.match(runHistory.content, /What the MSSR runs establish/);
  assert.match(runHistory.content, /labels were not independently\s+adjudicated/i);
  assert.doesNotMatch(runHistory.content, /## Confidence and merge policy/);

  const historicalResumeContext = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Recover and continue the historical cross-project Jev runs 62 and 63",
      domains: ["coding", "agent-orchestration", "skill-system"],
      actions: ["recover", "review"],
      artifacts: ["document", "project"],
      needs: ["integrity-verification", "cross-agent"],
      signals: ["uncertainty", "conflicting-evidence"],
      risk: "read-only",
    }),
    stage: "resume",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  const resumedFollowUps = historicalResumeContext.selected.find((record) => record.ref === "mssr-jev-confidence-run-history");
  assert.ok(resumedFollowUps, "the run-history module must load when resuming related work");
  assert.equal(resumedFollowUps.segmentDecisions.find((decision) => decision.id === "cross-project-runs-62-63")?.selected, true);
  assert.equal(
    createHash("sha256").update(extractProjectContextSections(resumedFollowUps.content, [crossProjectFollowUpsHeading]), "utf8").digest("hex"),
    "0fc901ba86f368043703f2f601072f2d6866ac563821ccdaa4f3bea408e7e05e",
    "resumed historical context must preserve the indexed Runs 62–63 evidence",
  );
  assert.match(connectedDiagnostics.content, /answer-complete/i);
  assert.match(connectedDiagnostics.content, /not owner-gold, reliability estimates,/i);
  assert.match(evaluationProtocol.content, /Next MSSR evaluation/);
  assert.match(selectorReleaseHistory.content, /35\/52/);
  assert.match(selectorReleaseHistory.content, /uncalibrated/i);
  const selectorHistorySource = await fs.readFile(path.join(repositoryRoot, ".mssr/knowledge/reference/mssr-jev-librarian-selector-release-history.md"), "utf8");
  assert.equal(
    createHash("sha256").update(extractProjectContextSections(selectorHistorySource, [
      "## Explicit Jev selection for the Librarian — 0.2.95",
      "## Probabilistic shortlists across Jev option shards — 0.2.97",
    ]), "utf8").digest("hex"),
    "2d999cf30476852a2da68407981070d3eed256be5d9e56168ba8524880919f14",
    "selector release history must preserve both source sections exactly",
  );

  const currentDocumentEvaluationContext = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Review CBAnimal current-document Jev Librarian evaluation and exact-fetch evidence",
      domains: ["filesystem"],
      actions: ["analyze"],
      artifacts: ["document", "mcp"],
      needs: ["integrity-verification"],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "verify",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  const currentDocumentEvaluation = currentDocumentEvaluationContext.selected.find(
    (record) => record.ref === "mssr-jev-cross-project-family-smokes-20261010",
  );
  assert.ok(currentDocumentEvaluation, "CBAnimal evaluation should load as a focused indexed module");
  assert.ok(currentDocumentEvaluation.bytes <= 4_500);
  assert.match(currentDocumentEvaluation.content, /CBAnimal/);
  assert.match(currentDocumentEvaluation.content, /not owner-gold/i);
  const currentDocumentSource = await fs.readFile(path.join(repositoryRoot, ".mssr/knowledge/reference/jev-cross-project-family-smokes-20261010.md"), "utf8");
  assert.equal(
    createHash("sha256").update(extractProjectContextSections(currentDocumentSource, ["## Scope and interpretation", "## Evaluation records"]), "utf8").digest("hex"),
    "59c1fcd6885bf9b0c28e2639d88dd8d60bf9cfdceb5b48885585984869635ef0",
    "cross-project family evaluation must preserve the hash-addressed source section",
  );

  const crossRepositoryEvaluationContext = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Review Elemental Frontier bilingual Jev range granularity: Spanish query, English variant, primary-first queryVariants",
      domains: ["filesystem"],
      actions: ["analyze", "verify"],
      artifacts: ["repository", "document", "mcp"],
      needs: ["integrity-verification"],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "verify",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  const crossRepositoryEvaluation = crossRepositoryEvaluationContext.selected.find(
    (record) => record.ref === "mssr-jev-crossrepo-bilingual-range-retrieval-20261010",
  );
  assert.ok(crossRepositoryEvaluation, "cross-repository retrieval evaluation should load as a focused indexed module");
  assert.ok(crossRepositoryEvaluation.bytes <= 5_000);
  assert.match(crossRepositoryEvaluation.content, /queryVariants/);
  assert.match(crossRepositoryEvaluation.content, /uncalibrated/i);
  const crossRepositorySource = await fs.readFile(path.join(repositoryRoot, ".mssr/knowledge/reference/jev-crossrepo-bilingual-range-retrieval-20261010.md"), "utf8");
  assert.equal(
    createHash("sha256").update(extractProjectContextSections(crossRepositorySource, ["## Scope and interpretation", "## Evaluation records"]), "utf8").digest("hex"),
    "afa002afe8c3e4019a528769f9a15e6c9e576178b0a8c9a5d035cb6fb793d3d8",
    "cross-repository retrieval evaluation must preserve the hash-addressed source section",
  );

  const relationControlEvaluation = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Verify Jev relation controls, contradictions, supersession, and independent evidence",
      domains: ["filesystem"],
      actions: ["analyze", "verify"],
      artifacts: ["document", "mcp"],
      needs: ["integrity-verification"],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "verify",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  assert.ok(relationControlEvaluation.selected.some((record) => record.ref === "mssr-jev-relation-control-cohorts-20261010"), "relation-control terms should select their focused evaluation module");
  assert.ok(relationControlEvaluation.selected.find((record) => record.ref === "mssr-jev-relation-control-cohorts-20261010").bytes <= 9_500);

  const genericVerificationEvaluation = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Verify files in this project",
      domains: ["filesystem"],
      actions: ["analyze", "verify"],
      artifacts: ["document"],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "verify",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  assert.equal(genericVerificationEvaluation.selected.some((record) => record.ref.startsWith("mssr-jev-") && /evaluation|cohort|smokes|retrieval/.test(record.ref)), false, "generic verification should not load all dated Jev evaluation history");

  const unrelatedEvaluationContext = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      summary: "Inspect a Blender image preview",
      domains: ["blender"],
      actions: ["discover"],
      artifacts: ["asset"],
      needs: ["visual-qa"],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "implement",
    maxChars: 20_000,
    maxModules: 40,
    includeCore: false,
  });
  assert.equal(unrelatedEvaluationContext.selected.some((record) =>
    record.ref.startsWith("mssr-jev-")
      || record.ref === "mssr-document-surface-librarian-contract"
      || record.ref === "mssr-jev-librarian-selector-release-history"), false,
  "unrelated image work must not load Jev evaluation or Librarian contract evidence");

  const librarianModules = (result) => result.selected
    .filter((record) => record.ref.startsWith("mssr-project-context-librarian"));
  const librarianImplementation = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      domains: ["coding"],
      actions: ["edit"],
      artifacts: ["code"],
      needs: ["unit-tests"],
      signals: ["nominal"],
      risk: "write",
    }),
    stage: "implement",
    includeCore: false,
  });
  const implementationModules = librarianModules(librarianImplementation);
  assert.deepEqual(implementationModules.map((record) => record.ref).sort(), [
    "mssr-project-context-librarian-metadata-core",
    "mssr-project-context-librarian-projection",
  ]);
  const implementationText = implementationModules.map((record) => record.content).join("\n");
  assert.match(implementationText, /ordinary module selection, routing, context budgets, permission, or\s+canonical truth/);
  assert.match(implementationText, /stale fingerprint produce an omission reason/);
  assert.doesNotMatch(implementationText, /up to 512 heading declarations/);

  const librarianDebug = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      domains: ["coding"],
      actions: ["debug"],
      artifacts: ["code"],
      needs: ["integrity-verification"],
      signals: ["error-observed"],
      risk: "read-only",
    }),
    stage: "implement",
    includeCore: false,
  });
  const debugModules = librarianModules(librarianDebug);
  assert.deepEqual(debugModules.map((record) => record.ref).sort(), [
    "mssr-project-context-librarian-metadata-core",
    "mssr-project-context-librarian-projection",
  ]);
  assert.match(debugModules.map((record) => record.content).join("\n"), /stale fingerprint produce an omission reason/);

  const librarianDesign = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      domains: ["coding"],
      actions: ["design"],
      artifacts: ["document"],
      needs: [],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "start",
    includeCore: false,
  });
  const designModules = librarianModules(librarianDesign);
  assert.deepEqual(designModules.map((record) => record.ref).sort(), [
    "mssr-project-context-librarian-metadata",
    "mssr-project-context-librarian-metadata-core",
  ]);
  assert.match(designModules.map((record) => record.content).join("\n"), /up to 512 heading declarations/);
  assert.doesNotMatch(designModules.map((record) => record.content).join("\n"), /stale fingerprint produce an omission reason/);

  const librarianWrongArtifact = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      domains: ["coding"],
      actions: ["debug"],
      artifacts: ["spreadsheet"],
      needs: [],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "implement",
    includeCore: false,
  });
  assert.deepEqual(librarianModules(librarianWrongArtifact), []);

  const librarianWrongAction = await loadProjectContextModules({
    projectRoot: repositoryRoot,
    intent: intent({
      domains: ["coding"],
      actions: ["review"],
      artifacts: ["code"],
      needs: [],
      signals: ["nominal"],
      risk: "read-only",
    }),
    stage: "implement",
    includeCore: false,
  });
  assert.deepEqual(librarianModules(librarianWrongAction).map((record) => record.ref), [
    "mssr-project-context-librarian-metadata-core",
  ]);

  const filesA = {
    "core-a.md": "# Core\n\nAlways loaded.\n",
    "opt-edit.md": "# Edit\n\nChosen when editing.\n",
    "opt-verify-stage.md": "# Verify stage\n\nOnly in verify stage.\n",
    "opt-unrelated.md": "# Unrelated\n\nThemed for roblox review.\n",
  };
  const modulesA = [
    mod("core-a", { estimatedChars: 64 }),
    mod("opt-edit", { domains: ["coding"], actions: ["edit"], stages: ["implement"], estimatedChars: 128 }),
    mod("opt-verify-stage", { domains: ["coding"], actions: ["edit"], stages: ["verify"], estimatedChars: 128 }),
    mod("opt-unrelated", { domains: ["roblox"], actions: ["review"], estimatedChars: 128 }),
  ];
  const rootA = await writeFixture("a-basic", { modules: modulesA, core: ["core-a"], files: filesA });

  const resA = await loadProjectContextModules({ projectRoot: rootA, intent: intentEdit, stage: "implement" });
  assert.equal(resA.advisoryOnly, true);
  assert.deepEqual(resA.core.map((r) => r.ref), ["core-a"]);
  assert.deepEqual(resA.selected.map((r) => r.ref), ["opt-edit"]);
  assert.equal(resA.decisions.length, 3);
  assert.equal(resA.decisions.find((d) => d.id === "opt-verify-stage").selected, false);
  assert.equal(resA.decisions.find((d) => d.id === "opt-unrelated").selected, false);
  assert.equal(typeof resA.remainingChars, "number");
  assert.ok(resA.remainingChars >= 0);

  const resAWithoutCore = await loadProjectContextModules({ projectRoot: rootA, intent: intentEdit, stage: "implement", includeCore: false });
  assert.deepEqual(resAWithoutCore.core, []);
  assert.deepEqual(resAWithoutCore.selected.map((r) => r.ref), ["opt-edit"]);
  assert.ok(resAWithoutCore.remainingChars > resA.remainingChars);

  const resUnrelated = await loadProjectContextModules({ projectRoot: rootA, intent: intentBlender, stage: "close" });
  assert.deepEqual(resUnrelated.core.map((r) => r.ref), ["core-a"]);
  assert.deepEqual(resUnrelated.selected.map((r) => r.ref), []);
  assert.equal(resUnrelated.decisions.every((d) => d.selected === false), true);

  const filesB = { "core-a.md": "Core.", "opt-req.md": "# Req\nTiny.\n", "opt-free.md": "# Free\nTiny.\n" };
  const modulesB = [
    mod("core-a", { estimatedChars: 64 }),
    mod("opt-req", { domains: ["coding"], actions: ["edit"], stages: ["implement"], required: true, estimatedChars: 256 }),
    mod("opt-free", { domains: ["coding"], actions: ["edit"], stages: ["implement"], estimatedChars: 256 }),
  ];
  const rootB = await writeFixture("b-budget", { modules: modulesB, core: ["core-a"], files: filesB });
  const resB = await loadProjectContextModules({ projectRoot: rootB, intent: intentEdit, stage: "implement", maxChars: 5, maxModules: 1 });
  assert.deepEqual(resB.selected.map((r) => r.ref), ["opt-req"]);
  assert.deepEqual(resB.requiredBudgetExceeded.sort(), ["opt-req"]);
  assert.equal(resB.decisions.find((d) => d.id === "opt-free").reason, "budget-exceeded");
  assert.equal(resB.decisions.find((d) => d.id === "opt-free").selected, false);

  // An eligible optional module that exceeds its own entry budget must degrade to an
  // observable omission rather than aborting the whole project-context bootstrap.
  const rootB0 = await writeFixture("b0-optional-entry-overflow", {
    modules: [
      mod("opt-over-entry", { domains: ["coding"], actions: ["edit"], priority: 90, maxChars: 200 }),
      mod("opt-ok-entry", { domains: ["coding"], actions: ["edit"], priority: 80, maxChars: 400 }),
    ],
    files: {
      "opt-over-entry.md": `# Oversized optional\n${"x".repeat(500)}\n`,
      "opt-ok-entry.md": "# Healthy optional\nStill loadable.\n",
    },
  });
  const resB0 = await loadProjectContextModules({ projectRoot: rootB0, intent: intentEdit, stage: "implement" });
  assert.deepEqual(resB0.selected.map((record) => record.ref), ["opt-ok-entry"]);
  assert.equal(resB0.decisions.find((decision) => decision.id === "opt-over-entry").selected, false);
  assert.equal(resB0.decisions.find((decision) => decision.id === "opt-over-entry").reason, "budget-exceeded");
  assert.equal(resB0.decisions.find((decision) => decision.id === "opt-over-entry").chars > 200, true);

  // The same per-entry overflow remains fail-visible when the module is required.
  const rootB0Required = await writeFixture("b0-required-entry-overflow", {
    modules: [mod("req-over-entry", { domains: ["coding"], actions: ["edit"], required: true, maxChars: 200 })],
    files: { "req-over-entry.md": `# Oversized required\n${"r".repeat(500)}\n` },
  });
  await assert.rejects(
    () => loadProjectContextModules({ projectRoot: rootB0Required, intent: intentEdit, stage: "implement" }),
    /selection exceeds 200 bytes/,
  );

  // Cross-cutting mutation contracts are materialized before semantic ranking. This
  // reproduces the failure mode where a UTF-8/runtime rule exists durably but the
  // task intent is narrowly classified around an unrelated subsystem.
  const filesB1 = {
    "critical-utf8.md": "# UTF-8 runtime invariant\nPayload text must remain UTF-8.\n",
    "semantic-map.md": "# Map sync\nSubsystem-specific implementation notes.\n",
  };
  const modulesB1 = [
    mod("critical-utf8", {
      domains: ["other"],
      actions: ["review"],
      requiredWhen: { mutation: true, artifacts: ["code"] },
      priority: -80,
    }),
    mod("semantic-map", { domains: ["coding"], actions: ["edit"], artifacts: ["code"], priority: 90 }),
  ];
  const rootB1 = await writeFixture("b1-cross-cutting", { modules: modulesB1, files: filesB1 });
  const mutationB1 = await loadProjectContextModules({
    projectRoot: rootB1,
    intent: intent({ domains: ["coding"], actions: ["edit"], artifacts: ["code"], risk: "write" }),
    stage: "implement",
    maxChars: 40,
    maxModules: 1,
  });
  assert.deepEqual(mutationB1.selected.map((record) => record.ref), ["critical-utf8"]);
  assert.deepEqual(mutationB1.requiredBudgetExceeded, ["critical-utf8"]);
  assert.equal(mutationB1.decisions.find((d) => d.id === "critical-utf8").required, true);
  assert.deepEqual(mutationB1.decisions.find((d) => d.id === "critical-utf8").requiredBy, ["mutation", "artifact:code"]);
  assert.equal(mutationB1.decisions.find((d) => d.id === "semantic-map").selected, false);

  const readOnlyB1 = await loadProjectContextModules({
    projectRoot: rootB1,
    intent: intent({ domains: ["coding"], actions: ["review"], artifacts: ["code"], risk: "read-only" }),
    stage: "implement",
  });
  assert.equal(readOnlyB1.selected.some((record) => record.ref === "critical-utf8"), false);
  assert.equal(readOnlyB1.decisions.find((d) => d.id === "critical-utf8").required, false);
  assert.equal(readOnlyB1.decisions.find((d) => d.id === "critical-utf8").reason, "intent-mismatch");

  const filesB2 = {
    "core-big.md": "C".repeat(30_000),
    "req-big.md": "R".repeat(25_000),
    "notreq-big.md": "N".repeat(25_000),
  };
  const modulesB2 = [
    mod("core-big", { estimatedChars: 30_000 }),
    mod("req-big", { required: true, estimatedChars: 25_000, domains: ["coding"], actions: ["edit"] }),
    mod("notreq-big", { required: false, estimatedChars: 25_000, domains: ["coding"], actions: ["edit"] }),
  ];
  const rootB2 = await writeFixture("b-overflow", { modules: modulesB2, core: ["core-big"], files: filesB2 });
  const resB2 = await loadProjectContextModules({ projectRoot: rootB2, intent: intentEdit, stage: "implement" });
  assert.deepEqual(resB2.requiredOverflow.sort(), ["core-big", "req-big"]);
  assert.equal(resB2.requiredOverflow.includes("notreq-big"), false);

  const dirC = path.join(base, "c-safety");
  await fs.rm(dirC, { recursive: true, force: true });
  await fs.mkdir(path.join(dirC, ".mssr"), { recursive: true });
  assert.throws(() => safeMarkdownPath(dirC, "../evil.md"), /traverse/);
  assert.throws(() => safeMarkdownPath(dirC, path.join("sub", "..", "..", "escape.md")), /traverse/);
  assert.throws(() => safeMarkdownPath(dirC, "notes.txt"), /markdown/);
  assert.throws(() => safeMarkdownPath(dirC, path.join(dirC, "abs.md")), /absolute/);
  assert.equal(
    path.resolve(safeMarkdownPath(dirC, "docs/good.md")),
    path.resolve(path.join(dirC, "docs", "good.md")),
  );

  const tooBig = path.join(dirC, "big.md");
  await fs.writeFile(tooBig, "x".repeat(MAX_PROJECT_CONTEXT_CHARS + 1), "utf8");
  await assert.rejects(() => readBoundedMarkdown(tooBig), /exceeds/);

  const small = path.join(dirC, "small.md");
  await fs.writeFile(small, "hi", "utf8");
  const rawSmall = await readBoundedMarkdown(small);
  assert.equal(rawSmall.content, "hi");
  assert.equal(rawSmall.bytes, 2);
  await assert.rejects(() => readBoundedMarkdown(small, 1), /exceeds/);

  // A per-entry maxChars limit applies after section extraction. The backing
  // authority may be larger as long as it stays under the global source cap.
  const rootSectionMax = path.join(base, "c-section-max");
  await fs.rm(rootSectionMax, { recursive: true, force: true });
  await fs.mkdir(path.join(rootSectionMax, ".mssr"), { recursive: true });
  const sectionPayload = "r".repeat(215);
  const sectionAuthority = `# History\n${"x".repeat(3_000)}\n\n## Current release\n${sectionPayload}\n\n## Other\n${"y".repeat(500)}\n`;
  await fs.writeFile(path.join(rootSectionMax, "authority.md"), sectionAuthority, "utf8");
  const sectionManifest = (maxChars) => ({
    schemaVersion: 1,
    core: [{
      id: "section-core",
      kind: "state",
      description: "Small selected section from a larger authority",
      source: { path: "authority.md", sections: ["## Current release"] },
      maxChars,
    }],
    modules: [],
  });
  await fs.writeFile(path.join(rootSectionMax, ".mssr", "project-context.json"), JSON.stringify(sectionManifest(256)), "utf8");
  const sectionLimited = await loadProjectContextModules({ projectRoot: rootSectionMax, intent: intentEdit, stage: "start" });
  assert.equal(sectionLimited.core[0].content, `## Current release\n${sectionPayload}`);
  assert.ok(sectionLimited.core[0].bytes > 200 && sectionLimited.core[0].bytes < 256);

  await fs.writeFile(path.join(rootSectionMax, ".mssr", "project-context.json"), JSON.stringify(sectionManifest(200)), "utf8");
  await assert.rejects(
    () => loadProjectContextModules({ projectRoot: rootSectionMax, intent: intentEdit, stage: "start" }),
    /selection exceeds 200 bytes/,
  );

  // One logical project-context module may expose a compact unconditional baseline plus
  // one deep semantic segment. Parent routing/ref identity stays stable; segment choice is
  // deterministic and observable rather than creating independently-budgeted child modules.
  const segmentedRoot = path.join(base, "c-semantic-segments");
  await fs.rm(segmentedRoot, { recursive: true, force: true });
  await fs.mkdir(path.join(segmentedRoot, ".mssr"), { recursive: true });
  await fs.writeFile(
    path.join(segmentedRoot, "history.md"),
    "# History\n\n## Baseline\nCurrent invariant.\n\n## Alpha\nAlpha historical detail.\n\n## Beta\nBeta historical detail.\n",
    "utf8",
  );
  const segmentedManifest = {
    schemaVersion: 1,
    core: [],
    modules: [{
      id: "semantic-history",
      kind: "memory",
      description: "Segmented history fixture.",
      source: { path: "history.md" },
      domains: ["coding"],
      actions: ["recover"],
      artifacts: [],
      needs: ["history-recovery"],
      signals: [],
      required: false,
      priority: 10,
      maxChars: 500,
    }],
  };
  const segmentedSidecar = {
    schemaVersion: 1,
    modules: [{
      moduleId: "semantic-history",
      segments: [
        { id: "baseline", sections: ["## Baseline"], baseline: true },
        { id: "alpha", sections: ["## Alpha"], terms: ["alpha subsystem"], priority: 10 },
        { id: "beta", sections: ["## Beta"], terms: ["beta subsystem"], priority: 10 },
      ],
    }],
  };
  await fs.writeFile(path.join(segmentedRoot, ".mssr", "project-context.json"), JSON.stringify(segmentedManifest), "utf8");
  await fs.writeFile(path.join(segmentedRoot, ".mssr", "project-context-segments.json"), JSON.stringify(segmentedSidecar), "utf8");
  const segmentedIntent = (summary) => intent({ summary, domains: ["coding"], actions: ["recover"], needs: ["history-recovery"], risk: "read-only" });
  const alphaSegment = await loadProjectContextModules({ projectRoot: segmentedRoot, intent: segmentedIntent("Recover alpha subsystem history"), stage: "implement", includeCore: false });
  assert.deepEqual(alphaSegment.selected.map((record) => record.ref), ["semantic-history"]);
  assert.match(alphaSegment.selected[0].content, /Current invariant/);
  assert.match(alphaSegment.selected[0].content, /Alpha historical detail/);
  assert.doesNotMatch(alphaSegment.selected[0].content, /Beta historical detail/);
  assert.deepEqual(alphaSegment.ambiguousSegments, []);
  assert.equal(alphaSegment.selected[0].segmentDecisions.find((item) => item.id === "baseline").reason, "baseline");
  assert.equal(alphaSegment.selected[0].segmentDecisions.find((item) => item.id === "alpha").selected, true);

  const genericSegment = await loadProjectContextModules({ projectRoot: segmentedRoot, intent: segmentedIntent("Recover project history"), stage: "implement", includeCore: false });
  assert.match(genericSegment.selected[0].content, /Current invariant/);
  assert.doesNotMatch(genericSegment.selected[0].content, /historical detail/);
  assert.deepEqual(genericSegment.ambiguousSegments, []);

  const ambiguousSegment = await loadProjectContextModules({ projectRoot: segmentedRoot, intent: segmentedIntent("Recover alpha subsystem and beta subsystem history"), stage: "implement", includeCore: false });
  assert.match(ambiguousSegment.selected[0].content, /Current invariant/);
  assert.doesNotMatch(ambiguousSegment.selected[0].content, /historical detail/);
  assert.deepEqual(ambiguousSegment.ambiguousSegments, [{ moduleId: "semantic-history", candidates: ["alpha", "beta"], score: 26 }]);
  assert.equal(ambiguousSegment.selected[0].segmentDecisions.find((item) => item.id === "alpha").reason, "ambiguous-candidate");
  assert.equal(ambiguousSegment.selected[0].segmentDecisions.find((item) => item.id === "beta").reason, "ambiguous-candidate");

  // A segmented backing file may temporarily exceed the normal 64 KiB maintenance budget
  // without making MSSR blind. The selected payload stays bounded and the larger recovery
  // hard limit exists so health/maintenance can still inspect and repair the source.
  const recoverableLargeHistory = `# History\n\n## Baseline\nCurrent invariant.\n\n## Alpha\nAlpha historical detail.\n\n## Beta\nBeta historical detail.\n\n## Archive\n${"z".repeat(MAX_PROJECT_CONTEXT_CHARS + 1_024)}\n`;
  assert.ok(Buffer.byteLength(recoverableLargeHistory, "utf8") > MAX_PROJECT_CONTEXT_CHARS);
  assert.ok(Buffer.byteLength(recoverableLargeHistory, "utf8") < MAX_SEGMENTED_PROJECT_CONTEXT_SOURCE_BYTES);
  await fs.writeFile(path.join(segmentedRoot, "history.md"), recoverableLargeHistory, "utf8");
  const recoverableLargeSelection = await loadProjectContextModules({ projectRoot: segmentedRoot, intent: segmentedIntent("Recover alpha subsystem history"), stage: "implement", includeCore: false });
  assert.match(recoverableLargeSelection.selected[0].content, /Current invariant/);
  assert.match(recoverableLargeSelection.selected[0].content, /Alpha historical detail/);
  assert.doesNotMatch(recoverableLargeSelection.selected[0].content, /## Archive/);

  const overlapSidecar = structuredClone(segmentedSidecar);
  overlapSidecar.modules[0].segments[0].sections = ["# History"];
  await fs.writeFile(path.join(segmentedRoot, ".mssr", "project-context-segments.json"), JSON.stringify(overlapSidecar), "utf8");
  await assert.rejects(
    () => loadProjectContextModules({ projectRoot: segmentedRoot, intent: segmentedIntent("Recover alpha subsystem history"), stage: "implement", includeCore: false }),
    /segment sections overlap/,
  );
  await fs.writeFile(path.join(segmentedRoot, ".mssr", "project-context-segments.json"), JSON.stringify(segmentedSidecar), "utf8");

  const unknownSidecar = structuredClone(segmentedSidecar);
  unknownSidecar.modules[0].moduleId = "missing-history";
  await fs.writeFile(path.join(segmentedRoot, ".mssr", "project-context-segments.json"), JSON.stringify(unknownSidecar), "utf8");
  await assert.rejects(() => loadProjectContextModuleManifest(segmentedRoot), /references unknown module/);
  await fs.writeFile(path.join(segmentedRoot, ".mssr", "project-context-segments.json"), JSON.stringify(segmentedSidecar), "utf8");

  const parentSectionManifest = structuredClone(segmentedManifest);
  parentSectionManifest.modules[0].source.sections = ["## Baseline"];
  await fs.writeFile(path.join(segmentedRoot, ".mssr", "project-context.json"), JSON.stringify(parentSectionManifest), "utf8");
  await assert.rejects(() => loadProjectContextModuleManifest(segmentedRoot), /cannot also declare parent source.sections/);
  await fs.writeFile(path.join(segmentedRoot, ".mssr", "project-context.json"), JSON.stringify(segmentedManifest), "utf8");

  // External references keep the parent module baseline physically compact while routing at most
  // one deep Markdown ref from a separate file. Old hosts can still read the compact parent source.
  const referencedRoot = path.join(base, "c-external-refs");
  await fs.rm(referencedRoot, { recursive: true, force: true });
  await fs.mkdir(path.join(referencedRoot, ".mssr", "knowledge", "history"), { recursive: true });
  await fs.writeFile(path.join(referencedRoot, "history-current.md"), "# Current History\n\nCurrent invariant.\n", "utf8");
  await fs.writeFile(path.join(referencedRoot, ".mssr", "knowledge", "history", "alpha.md"), "# Alpha History\n\nAlpha external detail.\n", "utf8");
  await fs.writeFile(path.join(referencedRoot, ".mssr", "knowledge", "history", "beta.md"), "# Beta History\n\nBeta external detail.\n", "utf8");
  const referencedManifest = {
    schemaVersion: 1,
    core: [],
    modules: [{
      id: "referenced-history",
      kind: "memory",
      description: "Compact history baseline with selective external refs.",
      source: { path: "history-current.md" },
      domains: ["coding"],
      actions: ["recover"],
      artifacts: [],
      needs: ["history-recovery"],
      signals: [],
      required: false,
      priority: 10,
      maxChars: 500,
    }],
  };
  const referencedSidecar = {
    schemaVersion: 1,
    modules: [{
      moduleId: "referenced-history",
      references: [
        { id: "alpha", source: { path: ".mssr/knowledge/history/alpha.md" }, terms: ["alpha subsystem"], priority: 10 },
        { id: "beta", source: { path: ".mssr/knowledge/history/beta.md" }, terms: ["beta subsystem"], priority: 10 },
      ],
    }],
  };
  await fs.writeFile(path.join(referencedRoot, ".mssr", "project-context.json"), JSON.stringify(referencedManifest), "utf8");
  await fs.writeFile(path.join(referencedRoot, ".mssr", "project-context-refs.json"), JSON.stringify(referencedSidecar), "utf8");
  const referencedIntent = (summary) => intent({ summary, domains: ["coding"], actions: ["recover"], needs: ["history-recovery"], risk: "read-only" });

  const alphaReference = await loadProjectContextModules({ projectRoot: referencedRoot, intent: referencedIntent("Recover alpha subsystem history"), stage: "implement", includeCore: false });
  assert.deepEqual(alphaReference.selected.map((record) => record.ref), ["referenced-history"]);
  assert.match(alphaReference.selected[0].content, /Current invariant/);
  assert.match(alphaReference.selected[0].content, /Alpha external detail/);
  assert.doesNotMatch(alphaReference.selected[0].content, /Beta external detail/);
  assert.deepEqual(alphaReference.ambiguousReferences, []);
  assert.equal(alphaReference.selected[0].referenceDecisions.find((item) => item.id === "alpha").selected, true);

  const genericReference = await loadProjectContextModules({ projectRoot: referencedRoot, intent: referencedIntent("Recover project history"), stage: "implement", includeCore: false });
  assert.match(genericReference.selected[0].content, /Current invariant/);
  assert.doesNotMatch(genericReference.selected[0].content, /external detail/);
  assert.deepEqual(genericReference.ambiguousReferences, []);

  const ambiguousReference = await loadProjectContextModules({ projectRoot: referencedRoot, intent: referencedIntent("Recover alpha subsystem and beta subsystem history"), stage: "implement", includeCore: false });
  assert.match(ambiguousReference.selected[0].content, /Current invariant/);
  assert.doesNotMatch(ambiguousReference.selected[0].content, /external detail/);
  assert.deepEqual(ambiguousReference.ambiguousReferences, [{ moduleId: "referenced-history", candidates: ["alpha", "beta"], score: 26 }]);
  assert.equal(ambiguousReference.selected[0].referenceDecisions.find((item) => item.id === "alpha").reason, "ambiguous-candidate");

  const referencedLoad = await loadProjectContextModuleManifest(referencedRoot);
  assert.equal(referencedLoad.found, true);
  assert.equal(referencedLoad.referencesStatus, "loaded");
  assert.equal(referencedLoad.manifest.modules[0].references.length, 2);

  const unknownReferenceSidecar = structuredClone(referencedSidecar);
  unknownReferenceSidecar.modules[0].moduleId = "missing-history";
  await fs.writeFile(path.join(referencedRoot, ".mssr", "project-context-refs.json"), JSON.stringify(unknownReferenceSidecar), "utf8");
  await assert.rejects(() => loadProjectContextModuleManifest(referencedRoot), /reference sidecar references unknown module/);
  await fs.writeFile(path.join(referencedRoot, ".mssr", "project-context-refs.json"), JSON.stringify(referencedSidecar), "utf8");

  const traversalReferenceSidecar = structuredClone(referencedSidecar);
  traversalReferenceSidecar.modules[0].references[0].source.path = "../outside.md";
  await fs.writeFile(path.join(referencedRoot, ".mssr", "project-context-refs.json"), JSON.stringify(traversalReferenceSidecar), "utf8");
  await assert.rejects(() => loadProjectContextModuleManifest(referencedRoot), /must not traverse|escapes project root/);
  await fs.writeFile(path.join(referencedRoot, ".mssr", "project-context-refs.json"), JSON.stringify(referencedSidecar), "utf8");

  const mixedSegmentSidecar = { schemaVersion: 1, modules: [{ moduleId: "referenced-history", segments: [
    { id: "baseline", sections: ["# Current History"], baseline: true },
    { id: "deep", sections: ["## Deep"], terms: ["deep"] },
  ] }] };
  await fs.writeFile(path.join(referencedRoot, ".mssr", "project-context-segments.json"), JSON.stringify(mixedSegmentSidecar), "utf8");
  await assert.rejects(() => loadProjectContextModuleManifest(referencedRoot), /cannot mix internal segments and external references/);
  await fs.rm(path.join(referencedRoot, ".mssr", "project-context-segments.json"), { force: true });

  const constrainedManifest = structuredClone(referencedManifest);
  constrainedManifest.modules[0].maxChars = 200;
  await fs.writeFile(path.join(referencedRoot, ".mssr", "project-context.json"), JSON.stringify(constrainedManifest), "utf8");
  await fs.writeFile(path.join(referencedRoot, ".mssr", "knowledge", "history", "alpha.md"), `# Alpha History\n\n${"x".repeat(300)}\n`, "utf8");
  const oversizedReference = await loadProjectContextModules({ projectRoot: referencedRoot, intent: referencedIntent("Recover alpha subsystem history"), stage: "implement", includeCore: false });
  assert.deepEqual(oversizedReference.selected, []);
  assert.equal(oversizedReference.decisions.find((item) => item.id === "referenced-history").reason, "budget-exceeded");

  const filesC2 = { "core-safe.md": "safe", "evil.md": "evil" };
  const rootC2 = await writeFixture("c-traverse", {
    modules: [mod("core-safe", { estimatedChars: 16 }), mod("evil", { path: "../evil.md", estimatedChars: 16 })],
    core: ["evil"],
    files: filesC2,
  });
  await assert.rejects(
    () => loadProjectContextModules({ projectRoot: rootC2, intent: intentEdit, stage: "implement" }),
    /traverse/,
  );

  const rootC3 = await writeFixture("c-nonmd", {
    modules: [mod("core-safe", { estimatedChars: 16 }), mod("txt", { path: "core.txt", estimatedChars: 16 })],
    core: ["txt"],
    files: { "core-safe.md": "safe", "core.txt": "not markdown" },
  });
  await assert.rejects(
    () => loadProjectContextModules({ projectRoot: rootC3, intent: intentEdit, stage: "implement" }),
    /markdown/,
  );

  const rootC4 = await writeFixture("c-oversize", {
    modules: [mod("huge", { path: "huge.md", estimatedChars: MAX_PROJECT_CONTEXT_CHARS })],
    core: ["huge"],
    files: { "huge.md": "x".repeat(MAX_PROJECT_CONTEXT_CHARS + 1) },
  });
  await assert.rejects(
    () => loadProjectContextModules({ projectRoot: rootC4, intent: intentEdit, stage: "implement" }),
    /exceeds/,
  );

  const filesD = { "core-x.md": "x", "g-a.md": "alpha\n", "g-b.md": "beta\n", "g-c.md": "gamma\n" };
  const modulesD = [
    mod("core-x", { estimatedChars: 16 }),
    mod("g-a", { exclusiveGroup: "pair", domains: ["coding"], actions: ["edit"], stages: ["implement"], estimatedChars: 128 }),
    mod("g-b", { exclusiveGroup: "pair", domains: ["coding"], actions: ["edit"], stages: ["implement"], estimatedChars: 128 }),
    mod("g-c", { exclusiveGroup: "solo", domains: ["coding"], actions: ["edit"], stages: ["implement"], estimatedChars: 128 }),
  ];
  const rootD = await writeFixture("d-exclusive", { modules: modulesD, core: ["core-x"], files: filesD });
  const resD = await loadProjectContextModules({ projectRoot: rootD, intent: intentEdit, stage: "implement" });
  assert.equal(resD.ambiguousExclusiveGroups.length, 1);
  const ambiguous = resD.ambiguousExclusiveGroups[0];
  assert.equal(ambiguous.group, "pair");
  assert.deepEqual(ambiguous.candidates, ["g-a", "g-b"]);
  assert.equal(typeof ambiguous.score, "number");
  assert.deepEqual(resD.selected.map((r) => r.ref), ["g-c"]);
  assert.equal(resD.decisions.find((d) => d.id === "g-a").reason, "ambiguous-candidate");
  assert.equal(resD.decisions.find((d) => d.id === "g-a").selected, false);
  assert.equal(resD.decisions.find((d) => d.id === "g-b").reason, "ambiguous-candidate");
  assert.equal(resD.decisions.find((d) => d.id === "g-b").selected, false);
  assert.equal(resD.decisions.find((d) => d.id === "g-c").selected, true);

  const rootE1 = await writeFixture("e-empty", { withManifest: false });
  const missingManifest = await loadProjectContextModuleManifest(rootE1);
  assert.equal(missingManifest.found, false);
  const resE1 = await loadProjectContextModules({ projectRoot: rootE1, intent: intentEdit, stage: "start" });
  assert.equal(resE1.manifestStatus, "missing");
  assert.deepEqual(resE1.core, []);
  assert.deepEqual(resE1.selected, []);
  assert.deepEqual(resE1.decisions, []);
  assert.equal(resE1.remainingChars, 6000);

  // Docs or PROJECT_* files alone never bypass explicit MSSR initialization.
  const rootE2 = await writeFixture("e-docs", { files: { "docs/PROJECT_CONTEXT.md": "# Docs context\n" }, withManifest: false });
  const resE2 = await loadProjectContextModules({ projectRoot: rootE2, intent: intentEdit, stage: "start" });
  assert.equal(resE2.manifestStatus, "missing");
  assert.deepEqual(resE2.core, []);

  const rootE3 = await writeFixture("e-authority-without-contract", {
    files: { ".mssr/PROJECT_CONTEXT.md": "# Canonical context\n", "docs/PROJECT_CONTEXT.md": "# Docs context\n" },
    withManifest: false,
  });
  const resE3 = await loadProjectContextModules({ projectRoot: rootE3, intent: intentEdit, stage: "start" });
  assert.equal(resE3.manifestStatus, "missing");
  assert.deepEqual(resE3.core, []);
  assert.deepEqual(resE3.selected, []);

  const shaFile = path.join(dirC, "sha.md");
  await fs.writeFile(shaFile, "alpha beta gamma", "utf8");
  const sha1 = await readBoundedMarkdown(shaFile);
  const sha2 = await readBoundedMarkdown(shaFile);
  assert.equal(sha1.sha256, sha2.sha256);
  assert.equal(sha1.sha256, createHash("sha256").update("alpha beta gamma").digest("hex"));

  const resA2 = await loadProjectContextModules({ projectRoot: rootA, intent: intentEdit, stage: "implement" });
  assert.equal(resA.core[0].sha256, resA2.core[0].sha256);
  assert.equal(resA.selected[0].sha256, resA2.selected[0].sha256);
  assert.equal(resA.advisoryOnly, true);

  console.log("project-context-loader tests passed");
} finally {
  await fs.rm(base, { recursive: true, force: true });
}
