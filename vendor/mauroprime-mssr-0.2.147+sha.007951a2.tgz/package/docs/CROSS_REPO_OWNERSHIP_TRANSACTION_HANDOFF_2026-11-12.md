# MSSR — Handoff de propiedad y transacciones entre repositorios (12/11/2026)

**Estado: contrato portable v1 implementado en source; verificación de release y adopción operacional Bridge pendientes. No es una guardia automática desplegada.** Destinatario: agente responsable del repositorio `D:\Dev\mssr`. La semántica MSSR y la ejecución Bridge usan trazas **separadas**.

## Incidente que motiva el módulo

- El usuario ya había separado `D:\Dev\impresion-3d-lab` (curso/pruebas), `D:\Dev\Auro-3D` (venta, inventario y fotos de productos), `D:\Dev\auro-tech` (branding/marketing transversal) y `D:\Dev\bridge-mcp` (transporte/ejecución).
- Al retomar edición de seis fotos de compras Flexi 11/11 y su composición, el agente continuó en `impresion-3d-lab` por historial de conversación, creó allí guías/manifest/handoff y llegó a tratar esa ruta como propietario. **Ya existían seis fotos originales y manifiesto canónico en `Auro-3D\compras\flexi\evidencias\2026-11-11`**, junto con inventario comercial. La escritura fue técnicamente válida pero semánticamente ubicada en el dueño equivocado.
- Se detectó el conflicto solo tras corrección expresa del usuario. Se preservaron los originales, se copiaron/hash-verificaron baseline y recorte a `Auro-3D\marketing\fotoproductos\compra-flexi-2026-11-11` y se creó `HANDOFF-MSSR.md` comercial. El laboratorio sigue teniendo documentos/copia histórica; no borrarlos automáticamente. AURO TECH consume solo una **exportación aprobada**, no fuentes privadas.
- Este incidente no prueba ausencia de Project Context, Situation Model, context-modules o skill routing. Prueba una **brecha en la selección del dueño antes del primer write y en el handoff transaccional cross-repo**. No convertirlo en permisión implícita ni atribuirlo a falta de una tool de guardar imágenes.

## Componentes ya existentes: reutilizar, NO duplicar

1. **Project Context selectivo**: `.mssr/PROJECT_CONTEXT.md`, `PROJECT_MEMORY.md`, `PROJECT_STATE.md`, manifest `project-context.json`, módulos `context/memory/state/directive` y selección por intención/fase. `requiredWhen.mutation` puede activar una directiva de mutación en un repositorio, pero no deduce la titularidad de un recurso entre repositorios.
2. **Skill context expansion**: `context-modules.json` por skill, contexto mínimo+referencias selectivas/paginadas+presupuesto; no cargar todos los handoffs y módulos permanentemente ni elevar presupuestos. No existe motivo para crear otro motor de memoria paralela.
3. **Trace lifecycle integrity**: una traza conocida jamás migra de proyecto/workflow. El destino requiere una traza propia/delegada; la relación cross-repo es evidencia acotada, NO transferencia de identidad de la traza.
4. **Situation Model / R4 / C2c**: compara claims explícitos, autoridad y temporalidad, no interpreta automáticamente texto libre ni transforma evidencias en permiso de escritura. Puede **consumir** una claim declarada `asset-owner`, no inventarla.
5. **MauroPrime Bridge**: puede observar archivos, hash, manifest, Git, copies y persistencia. Solo Bridge/host puede implementar I/O, staging, lock/rollback y transacción física. MSSR solo contrato/plan/diagnóstico portable y advisory.
6. **Asset libraries/skills existentes**: reutilizar `cross-project-asset-library` cuando esté presente y `mauroprime-bridge-collaboration`; no crear otra skill de fotografía por este motivo. Una skill **cross-project-ownership-handoff** solo si auditoría de catálogo muestra objetivo/gate verdaderamente independiente.

## Propuesta: CrossRepoOwnershipTransaction v1

Una operación que lee en proyecto A y crea/actualiza derivado en proyecto B declara:
- `transactionId` estable/idempotente y `intent` estructurado con `sourceProject`, `targetProject`, `currentTraceId`, `relatedTraceId` (si está disponible), `artifactKind`, `operation`, `expectedOwnerProject`, `sourceRefs` y `targetRefs`.
- Evidencias normalizadas **host-observed**, no inventadas: `canonicalOwnerClaim` con `ownerProject`, `authoritySource` (AGENTS/Project Context/manifest/usuario), `authorityRevision/hash`, `scope` (raw-evidence, commercial-work-asset, approved-public-export), `observedAt`, `confidenceKind` (declared/observed/unknown), `conflicts[]`.
- **Decision pura/advisory MSSR:** `same-owner`, `delegated-to-owner`, `cross-repo-copy-reviewed`, `owner-ambiguous-blocked`, `owner-conflict-blocked`, `duplicate-existing-abstain`. El decision object proporciona `nextGate`, `requiredEvidence`, `reasonCodes`, `relatedProjectRefs`, pero NO hace write ni autoriza permisos. La ausencia de evidencia debe abstenerse.
- **Transacción host por pasos:** `discovered -> owner-resolved -> proposed -> staged -> copied -> verified -> pointer-updated -> committed -> closed`. Estados alternativos `blocked`/`aborted`/`rollback-needed`. El host debe mantener journal durable, hash esperado/final, destino y evidencia de readback. El pointer/handoff de quien consume solo cambia después de validación de archivos de destino; evitar swaps sin verificación.
- **Preservación de fuentes:** `copy+verify+link` por defecto, no mover ni borrar por heurística. Si ya hay archivo idéntico en destino (hash), reutilizarlo, declarar `deduplicated` y no modificar timestamps por gusto. Diferente hash en destino = conflicto, nunca overwrite silencioso.
- **Cambios en varias autoridades**: no existe commit físico ACID entre FS y Git de varios repos; hablar de protocolo de **compensación y reconciliación**, no de 2PC atómico real. `pending` explícito si copia ok pero handoff no actualizado; nunca declarar operación completa al crear solo una carpeta.
- **Historia y memoria:** `PROJECT_CONTEXT` conserva roles estables, `PROJECT_MEMORY` decisión de ownership, `PROJECT_STATE` propietario actual, progreso y pendientes, `.mssr/runtime/` receipts/journal reconstruibles; skill guía procedural. Los módulos son seleccionados por intents y artefactos, no propagados por copia de texto entre todas las `.mssr`.

## Detección antes de escribir — gates propuestos

- Trigger **estructurado**: `risk!=read-only` y `artifacts` incluye `asset/project/document` y la operación involucra `sourceProject != targetProject`, `needs=[cross-agent]`, o handoff/copy/move de recursos. NO activar por una consulta general a varios proyectos ni por una foto sin destino.
- Obtener evidencia de owner explícita de las raíces candidatas antes de materializar una ruta de trabajo. Si la selección de repo proviene solo del chat o del cwd, proyectar `owner-ambiguous`; preguntar o inspeccionar, **sin crear manifest/handoff propietario en el repo de origen**.
- **Extensión propuesta: aviso de owner de tarea/fase antes de elegir herramienta.** El contrato actual cubre operaciones de assets entre repos, pero no está demostrada la entrega de una advertencia visible cuando el entregable o la fase especializada pertenecen a otro proyecto y todavía no hay una copia/escritura. Analizar si el host puede comparar el intent estructurado con roles declarados en `AGENTS.md` / `.mssr/` y usar el índice selectivo de Project Observer solo para descubrir relaciones. El aviso debe nombrar proyecto actual, owner propuesto, autoridad/revisión que lo respalda, motivo y próximo paso; no cambiar de proyecto automáticamente. Claims ausentes/conflictivas quedan como revisión, y una consulta read-only no debe bloquearse. No crear otro módulo/router hasta probar que el módulo de ownership y el flujo existente de Context Messages/Notice no bastan. Este aviso de orientación es distinto del preflight transaccional obligatorio antes de una mutación cross-repo.
- Si la misma foto tiene `commercial raw evidence` en AURO 3D y una copia educativa, AURO 3D manda como dueño de marketing; esa copia educativa es `source/history`, no autoridad comercial. Un proyecto puede ser **publisher/consumer** sin ser owner del source.
- Tras comprobar propietario, ejecutar bootstrap en la **raíz dueña**, con traza nueva y referencia a evidence/handoff de la traza anterior; mantener tracers cross-project aislados.
- Proyectar `review-due` si cambios del handoff/owner rompen la relación de archivos; jamás auto-reescribir contexto por notificación de drift.

## Fixtures/aceptación para el siguiente agente

1. **Caso real**: tareas «mejorar fotos de stock para web AURO» desde conversación educativa => owner `Auro-3D`, no `impresion-3d-lab`. Se permite derivado interno y consumer `auro-tech` solo luego de aprobación.
2. **Negativo**: ejercicio calibración/primer Benchy en laboratorio => dueño educativo; no carga memoria comercial ni mueve materiales.
3. **Negativo**: branding del logo D2 AURO TECH => `auro-tech` sin migrar a AURO 3D.
4. **Conflicto**: dos proyectos declaran owner incompatible de la misma identidad/scope => bloquear/abstener y pedir evidencia específica, no elegir por similitud léxica.
5. **Idempotencia**: replay con el mismo source hash ya copiado y manifest presente => no repetir importación ni modificar evidencia.
6. **Fallo a mitad**: copia sin verificar, manifest/cambio de puntero fallidos, hashes contradictorios, origen inaccesible => no `committed`; journal resumible o rollback explícito.
7. **Trazas**: no reasignar traceId del laboratorio al proyecto comercial, y no vincular éxito a otra transacción solo por compartir fecha/nombre.
8. **Contexto selectivo**: en lectura de un proyecto aislado no se inyecta la guía de transacción completa; en mutación cross-repo se carga núcleo y unidad específica, con presupuesto y receipts válidos.
9. **Host parity**: fixtures codex-local vs chatgpt-web exigen mismas decisiones puras con evidencia equivalente; host mantiene ejecución y permisos.
10. **Privacy**: hashes, rutas necesarias y ref sin tokens, sin adjuntar archivos/clientes/URLs firmadas a telemetría o aprendizaje.
11. **Aviso previo a la herramienta**: desde un contexto AURO 3D, una solicitud de crear un GIF/animación debe mostrar la derivación propuesta a AURO Motions con referencia a la regla de ownership; no necesita mover un archivo para mostrarla. Una consulta read-only sobre inventario permanece en AURO 3D. Owner desconocido o conflictivo no produce un reroute silencioso. Verificar selección de evidencia y entrega visible en Codex; la prueba del evaluador portable por sí sola no acredita adopción del host.

## Implementación sugerida y propietarias

- **MSSR portable (owner semántico):** tipo/validador/proyector y fixtures de `CrossRepoOwnershipTransaction`; integrarlo con ownership claims declarados, C2c y trace lifecycle; actualizar docs/decisions, versioned changelog y `npm run verify` antes de marcar integrado.
- **Bridge host (owner operacional):** observador de fuentes y owners, staging/copy+SHA, journal de ejecución/readback, `project_context_load` sobre roots candidatos, callbacks de outcome y receipts. Gate previo a mutaciones de alto riesgo; no hacer de Bridge un segundo motor de reglas.
- **mauroprime-skills (procedimiento):** revisar reutilización de skill existente antes de agregar nueva; incluir resolución de dueño y handoff gates en un `context-modules.json` selectivo o guide global apropiado. Actualizar routing tests/fuentes solo cuando cambien triggers.
- **Proyectos consumidores:** Auro-3D declara autoridad comercial en AGENTS/.mssr y conserva las fuentes; auro-tech es consumidor de export aprobado; lab es curso y origen histórico.

## Verificación de expansión y presión de memoria (12/11)

El ensamblador de contexto selectivo **sí está implementado**: `context-modules.json` y las entradas `.mssr/knowledge` ya permiten carga condicional. En prueba real `project_context_load`, el nuevo módulo de ownership y el estado de handoff se seleccionaron para `asset/repository + cross-agent + conflicto + mutación`, pero **no** para revisión read-only del router sin cruce de proyectos. Esto comprueba *selección*, no enforcement/pre-write ni retención de la información por el agente.

`project_context_health(D:\\Dev\\mssr)` informó `manifestStatus=valid`, **50 módulos** y nivel global `review` por `many-modules` y algunos módulos próximos al presupuesto. No aumentar budgets ni cargar todo permanentemente para solventarlo: evaluar agrupación/refs selectivos en una tarea de mantenimiento independiente. El módulo nuevo permanece opcional/indexado; esa presión ya existente no autoriza reestructuraciones automáticas.

## Continuidad y límites

## Implementación portable MSSR v1 (2026-11-12)

- `src/cross-repo-ownership-transaction.ts` contiene schemas estrictos, el evaluador puro `evaluateMssrCrossRepoAssetOwnership` y el validador `validateMssrCrossRepoOwnershipTransition`.
- `mssr_cross_repo_ownership_evaluate` y `mssr_cross_repo_transaction_transition_validate` se registran en el contrato Project Control común; los adaptadores native, Codex y OpenCode comparten esas decisiones.
- El evaluador entrega `advisoryOnly: true` y `authorizationGranted: false` en todas las salidas. No inspecciona filesystem ni ejecuta writes. Un `review-required` o `blocked` detiene el flujo del agente que respeta el contrato; un host sin integración puede ignorarlo.
- El validator exige hash staged/source para `copied`, source/readback para `verified`, source/staged hash coincidentes para retomar desde `rollback-needed`, y estado `pointer-updated` más un receipt acotado antes de `committed`; admite `rollback-needed -> aborted` como ruta de aborto.
- El fixture portable usa IDs `Auro-3D`, `impresion-3d-lab` y `auro-tech`. Cubre owner ambiguo y conflictivo, export AURO TECH con scope aprobado, hash duplicado, destinos conflictivos, rutas traversal, trace IDs distintos, hash/readback divergente, commit prematuro y recuperación.
- La prueba `test:project-control-contract` también comprueba paridad de schema y resultados en los tres MCP portables. `npm run verify` pasó en build `mssr-build:sha256:25f8a5814f8ec38a`.
- El contrato de agentes y la plantilla managed indican preflight antes de una mutación; eso no intercepta herramientas genéricas de filesystem/terminal. Bridge debe adoptar el gate y demostrar bloqueo antes del write, journal, replay idempotente, readback, compensación y recuperación física. Hasta entonces, no afirmar protección automática.

MSSR reutiliza Project Context/context-module selection, las claims explícitas del Situation Model, separación de `traceId` del lifecycle existente y el presupuesto/context economy existente. No añade almacén de memoria ni transacción distribuida propia.

Project Context Health al cierre reporta manifest válido, 51 módulos, nivel `review` por `many-modules` y un módulo por encima del umbral de revisión; los dos módulos cross-repo permanecen selectivos y dentro de presupuesto. No se aumentó el presupuesto para esta incorporación. La agrupación de módulos, el tamaño de `mssr-module-handoff-capability-escalation` y cuatro handoffs de estado no indexados quedan como mantenimiento separado, no como parte de este guard.

**Evidencias actuales:** `D:\Dev\Auro-3D\marketing\fotoproductos\compra-flexi-2026-11-11\HANDOFF-MSSR.md` + `manifest.json`; `D:\Dev\Auro-3D\compras\flexi\evidencias\2026-11-11\MANIFEST_FOTOS.json`; `D:\Dev\bridge-mcp\docs\HANDOFF-IMAGE-ASSET-IMPORT-2026-11-12.md`.

**Criterio de terminado:** no solo que exista este documento. Requiere implementación portable testada, integración host con gate real, prueba de dos owners, prueba de recuperación, adopción de versión MSSR por Bridge y comprobación de que el guard evita escrituras equivocadas. Por ahora es handoff/requisito, **NO protección automática desplegada**.

**Traza documental:** `mssr-20261112040215-ef4e77f7-246`; agente futuro debe iniciar traza propia y registrar relación, no usurpar esta identidad.
