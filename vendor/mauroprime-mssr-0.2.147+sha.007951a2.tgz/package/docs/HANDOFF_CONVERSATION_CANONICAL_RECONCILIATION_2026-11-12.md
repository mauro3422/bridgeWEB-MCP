# Handoff — reconciliación de conversaciones y estado canónico (12/11/2026)

Estado: **propuesta documentada; implementación no autorizada ni verificada**.
Owner portable: MSSR. Owner de acceso a conversaciones, evidencia host y escritura autorizada: Bridge/ChatGPT host. Índice federado: Project Observer `OBS-SYS-06`.
Trace de preparación: `mssr-20261112071817-8d4dadaf-01e`.

## Motivación y evidencia
El usuario pide que el diario matutino revise conversaciones del día anterior **realmente accesibles**, identifique compromisos, decisiones, fricciones y propuestas, y contraste con el estado vivo de cada repositorio. Detectar casos donde un chat dice que se acordó/implementó algo pero MSSR, Bridge, una skill o la memoria canónica no muestran evidencia de adopción. Distinguir falta de acceso, falta de registro, contradicción real y deuda diferida. No atribuir a todos los chats una capacidad de lectura que el host no haya demostrado.

Ejemplos existentes para inspección: Project Observer `OBS-SYS-04` (selector transversal no demostrado), `OBS-SYS-05` (guard pre-write de cambio de owner no demostrado); MSSR `CrossRepoOwnershipTransaction v1` está implementado como evaluador portable pero Bridge debe demostrar adopción operacional. Skill `mssr-module-handoff` consta en source 0.2.143, pero catálogo live de Codex aún no la reflejaba al último estado leído. No interpretar eso como bug del contrato sin comprobar host/restart.

## Reutilizar antes de ampliar
Auditar Context Plane, Project Context, owner-aware maintenance classifier, Document Freshness, skill-maintenance-loop, Notice Plane, `mssr-module-handoff`, guía Bridge `cross-project-context-inventory` y `CrossRepoOwnershipTransaction`. MSSR propone/valida; host autorizado observa y ejecuta; Project Observer indexa referencias/prioridades; cada repo dueño conserva hechos y documentación canónica. No crear router, skill, BD ni módulo paralelo sin gap reproducible.

## Contrato candidato de hallazgo (no esquema aprobado)
`findingId`, `observedAt`, `conversationRef` opcional y minimizada, `claimType` (decisión/compromiso/reporte/hipótesis), `owner`, `canonicalEvidenceRef`, `freshness`, `comparisonStatus` (coincide/pendiente-evidencia/contradicción-confirmada/no-accesible/diferido/resuelto), `impact`, `priority`, `nextGate`, `handoffRef`, `verifiedAt`. Guardar resumen mínimo, **nunca transcripciones completas, prompts, datos sensibles o secretos**. Un chat no es prueba de ejecución; un archivo no mencionado no es prueba de incumplimiento.

## Pruebas y criterios de aceptación para agente especializado
1. Caso positivo: compromiso verificable en chat y evidencia contradictoria en owner actual; registrar una sola brecha con citas/fechas y handoff al owner correcto.
2. Caso negativo: conversación sin acceso, dato stale, compromiso aplazado o ausencia de registro; NO denunciar incumplimiento ni inventar owner.
3. Caso positivo de fase transversal: AURO 3D fotos → AURO Motions composición → AURO TECH publicación; identificar cambio de fase/owner sin mover originales ni conceder permisos.
4. Caso negativo: un chat menciona varios proyectos sin transferencia real; no duplicar handoffs ni activar skills innecesarias.
5. Reejecución: mismo hallazgo mantiene ID y se actualiza sin duplicarse; cierre requiere readback/aceptación del owner y evidencia observable.
6. Capability check: confirmar acceso efectivo a conversaciones del día anterior; si no existe, declarar cobertura parcial y usar sólo conversaciones disponibles.

## Prioridad
**Diferida / investigación cuando haya espacio**. No bloquear trabajo comercial ni exigir resolver outcome/closure MSSR por mera antigüedad. La automatización del diario ya tiene permiso documental limitado, no de código ni configuración.
