# Handoff MSSR — Revisión de impacto y expansión transversal de instrucciones (2026-11-12)

## Demanda comprobada / alcance
El usuario no está pidiendo solo regenerar `AGENTS.md`: pide que cuando una regla, decisión, workflow o patrón nuevo afecte otros proyectos/hosts, el sistema **identifique consumidores y dueño, estime impacto, muestre aviso de adopción/revisión pendiente, seleccione el contexto pertinente y verifique en cuáles proyectos está operativo**. Project Observer sería dashboard de continuidad y coordinación, **no fuente única ni reescritor de todos los repos**. Demanda repetida 12/11 durante ejemplos AURO 3D → Motions → AURO TECH y distintos formatos de checklists.

## Capacidades ya verificadas: reutilizar, NO duplicar
- `D:\Dev\AGENTS.md` tiene reglas transversales de lifecycle, handoffs y prioridad de contexto. Cada repo tiene `AGENTS.md` + `.mssr/project-context.json` y módulos selectivos. `D:\Dev\mssr\templates\AGENTS.mssr.md` es bloque `mssr:managed`; presencia de plantilla NO demuestra generación/actualización automática de todos los AGENTS ni adopción de nuevos hosts.
- `src/project-knowledge-maintenance.ts` ya identifica destinos `agents/context/memory/state/skill/reference` según evidencias del proyecto, y `projectMaintenanceAttention` puede pasar por notice MSSR → Bridge. Esto es **local al proyecto**, no evaluación de expansión a repos hermanos.
- Situation Model/C2c/C2f Architecture Impact, Context Messages, referencias selectivas y revisión cross-document ya manejan claims/revisiones/consistencia **por autoridad**; no son automáticamente un detector de adopción de una regla global entre repos.
- Operational Notice v1 portable con entrega/dedup host, y `cross-project-context-inventory` / `mssr-module-handoff` guías Bridge y `CrossRepoOwnershipTransaction v1` existen. No crear segundo bus de notices, motor de memoria ni router general.

## Brecha candidata: InstructionImpactReview (contrato a evaluar, NO implementado)
Proponer una proyección **pura/advisory** que recibe evidencia explícita y revisionada:
- `ruleId`, `ruleRevision/hash`, `canonicalOwner`, `instructionKind` (workspace-global, project-local, skill, workflow-host, portable-routing, provider-contract), `scope`, `changeKind`, `sourceRef`;
- `consumerProjects/hosts` declarados y/o observados, fuente/procedencia, `dependencyKind`, `currentAppliedRevision`, `adoptionStatus` (not-applicable/candidate/review-due/blocked/approved/applied/verified), `conflicts`, `nextGate`;
- respuesta con destinos mínimos, `reasonCodes`, prioridades/avisos deduplicables por `ruleId+revision+consumer+impactKind`, **sin propuestas de edición automática**. El host/owner verifica cambios en la autoridad correcta, aplica (solo autorizado) y registra readback/adopción; Project Observer agrega el estado derivado sin copiar el contenido de reglas.
- No duplicar `AGENTS.md` global en cada repo: una regla que aplica a todo el workspace se define una vez en `D:\Dev\AGENTS.md`; una local refina; una reusable va a skill; un workflow Bridge en guías host; un cambio de semántica MSSR exige versión, tests, fixtures, changelog y adopción.

## Instrucciones y criterio de notice
- **Review-due** si regla global cambia de revisión, hay un consumidor real conocido sin adopción, conflicto global/local, cambio de contrato de skill/routing/host, o patrón confirmado con efecto transversal no representado; agrupar y no spamear por múltiples traces.
- **Block/review** si owner incierto, falta permiso o las reglas son incompatibles. **Silencio** si cambio cosmético, lectura read-only, proyecto pausado sin dependencia real, regla ya consumida por herencia, o patrón todavía hipotético.
- El aviso debe especificar owner, consumidores, evidencia/frescura, cambio propuesto, siguiente paso y condición para marcar `verified`. Su entrega no equivale a adopción ni a ejecución del workflow.

## Responsables y pruebas de aceptación
- **MSSR** posee contrato semántico y tests de selección/no selección si el gap se confirma; mantener small public API y no añadir módulo 52 de Project Context por una propuesta.
- **Bridge/Codex** poseen evidencia de repos, resoluciones de herencia del workspace, notices/adopción, side effects, journal/hash/rollback y diferencias source/runtime. Probar host parity con datos equivalentes.
- **Project Observer** mantiene índice de cambios de instrucción, consumers y pendientes de revisión; su módulo selectivo: `D:\Dev\project-observer\.mssr\knowledge\architecture\revision-expansion-instrucciones-20261112.md`, checklist `OBS-SYS-08`; no escribe otros repos.
- Fixtures: regla global que afecta dos repos sin duplicar archivo; regla local sin otros consumidores; cambio de skill que afecta host sin tocar AGENTS; conflicto entre AGENTS global y local; runtime host sin nueva versión; repeat notice dedupe; scope pausado/no-impacto; privacidad; preview y adopción explícita con comprobación real.
- Fase siguiente: auditar completamente generador/inserción de bloques managed antes de afirmar regeneración automática. Prototipo de observación read-only y muestra de aviso; **no desplegar propagación automática** ni modificar todas las instrucciones por impulso.
- Prioridad humana sigue en piloto Blender/AURO 3D; esto es deuda técnica clasificada, sin fecha impuesta.

## Consideraciones de privacidad
El contexto situacional no sensible del usuario se guardó selectivamente en `project-observer\.mssr\knowledge\operations\situacion-usuario-operativa-20261112.md`, con vigencia revisable. No propagar estados personales, salud, vida íntima, transcripciones, mensajes ni inferencias sobre la persona a AGENTS, skills, notices o otros repositorios.
