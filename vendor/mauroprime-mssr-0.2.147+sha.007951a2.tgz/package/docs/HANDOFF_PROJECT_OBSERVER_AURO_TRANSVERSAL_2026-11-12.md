# Handoff — Project Observer como índice federado de trabajo AURO (2026-11-12)

## Estado y dueño
- **Dueño de relaciones y prioridades humanas:** `D:\Dev\project-observer` (ahora inicializado con `.mssr/project-context.json`, `AGENTS.md`, `PENDIENTES.md`, `HANDOFF-MSSR.md`, módulo selectivo `.mssr/knowledge/architecture/auro-relaciones-transversales-20261112.md`).
- **Dueño de routing portátil MSSR:** este repositorio. Ya existen contrato de checklist por proyecto (MSSR 0.2.138, módulo `.mssr/knowledge/state/mssr-project-checklist-handoff-20261111.md`), identidad humana `taskKey` (`.mssr/knowledge/decision/human-task-identity.md`) y guía Bridge global `cross-project-context-inventory`. No se pidió ni se implementó una segunda cola de pendientes.
- **Fuentes primarias:** AURO 3D pedidos/productos/fotos; lab pruebas físicas y Blender educativo; Bambu Studio MCP capacidades; AURO Motions genera clips/recortes **para publicidad de AURO TECH**; AURO TECH gestiona marca, exportaciones aprobadas y publicación. Otros proyectos pausados por decisión del usuario.

## Lo verificado
- 12/11: `project_context_initialize` de Project Observer creó `.mssr` canónico; `project_context_capture` registró su relación selectiva. Un `project_context_load` con intent de coordinación `start/resume` **seleccionó** el módulo `auro-relaciones-transversales-20261112`.
- `PENDIENTES.md` y handoff de Project Observer persistidos/validados por readback; 5 tests unitarios del observador PASS. **No** se demostró el escaneo global completo ni que se actualice solo cada día.
- El `project_index.json` de Observer siguió con 9 candidatos tras falso truncamiento y un reescaneo demasiado costoso; no inferir proyectos borrados. Fuente: `D:\Dev\project-observer\INCIDENTS.md`.

## Revisión técnica futura (no ejecutar en esta tarea)
1. Con intención de usuario «retomá todos mis proyectos AURO», probar que un host elige el **owner Project Observer** y guía `cross-project-context-inventory`, carga el módulo selectivo, después consulta repositorios según necesidad. Una selección válida dentro del owner observado no prueba la activación automática desde otros proyectos/chats.
2. Verificar por qué la telemetría MSSR acumula trazas sin outcomes/verificaciones: diferenciar `taskKey` humana, traceId de un solo proyecto, `phase_completed`, `verification`, `persistence`, `outcome` y **entrega visible al usuario**, que no es observable por la mera ejecución del Bridge. No autocerrar ni atribuir tareas pendientes a todo trace abierto.
3. Diseñar casos positivos/negativos de contexto cross-project, owner mismatch, pause vs backlog, bloqueo scan y no mezcla de datos privados. Si realmente falta un comportamiento portable, implementar solo en su owner con fixtures, changelog versionado y prueba de adopción en Bridge/Codex. **Este handoff no crea una skill ni modifica el contrato MSSR.**
4. Validar scheduler de Project Observer y fuente real de chats; sin evidencia no afirmar generación continua. Limitar scans y preservar provenance, frescura, hashes y fuente.

## Política de foco
Siguiente sesión tras descanso: **un producto físico comercial modelado en Blender** (encastre de vaso aluminio 650 ml o llavero) con pasos pequeños; Bambu solo soporte QA; una comunicación reusable de AURO TECH si no bloquea. No convertir Motions ni la infraestructura en proyectos adicionales de entrega.

## Aclaración de transición de fase solicitada por el usuario (12/11)

**Pregunta resuelta:** AURO 3D no es únicamente una web ni una base de métricas. Es el owner comercial de productos, stock, costos, pedidos, fotos originales y derivados **aprobados para catálogo**; el eventual panel es solo su vista operativa. Al evolucionar una tarea de inventario/fotografía a extracción de assets, máscaras, inpaint, clips o animación, el **owner de la ejecución audiovisual** pasa a AURO Motions, manteniendo propiedad y acceso controlado de fotos originales en AURO 3D. Un export comercial revisado puede retornar a AURO 3D y un export promocional aprobado puede pasar a AURO TECH. No migrar originales ni duplicar autoridad automáticamente.

**Problema de routing:** la selección no debe depender solo de la carpeta donde empezó el chat. En cuanto el entregable y la fase cambian (p. ej., 'quiero usar las fotos de los rollos para generar un corto'), el host debe evaluar `sourceProject` vs `targetProject` y abrir una advertencia de handoff antes de escribir o mover, con tipo de asset, referencia/hash, dueño confirmado, estado de aprobación, destino, siguiente gate y trazas independientes. Al cambiar de repo: cargar contexto del destino y replanificar, jamás trasladar traceId anterior.

**Capacidades existentes:** `CrossRepoOwnershipTransaction v1` ya implementado en MSSR **portable**; el guard operacional transaccional del Bridge todavía es pendiente de adopción/verificación. `cross-project-context-inventory` y el módulo selectivo en Project Observer ayudan a descubrir la relación, pero no ejecutan el guard por sí solos. **No crear otra skill/router** antes de probar casos positivo (fotos AURO→Motions), negativo (consulta solo inventario), conflicto de owners, caso aprobado para catálogo y falso traspaso por mero contexto narrativo.

**Seguimiento:** `D:\Dev\project-observer\PENDIENTES.md` (OBS-SYS-05) y módulo `auro-relaciones-transversales-20261112`. Dejar implementación del guard Bridge como labor técnica posterior a conseguir una primera pieza piloto comercial; no aumentar el WIP humano.

## Auditoría adicional: federación de checklists y ownership de workflows (12/11)

Owner del análisis: `D:\Dev\project-observer\docs\AUDITORIA_ORQUESTACION_FEDERADA_2026-11-12.md`; seguimiento en `PENDIENTES.md` como **OBS-SYS-06**. No cambiar código ni agregar un módulo portable por esta documentación.

- AURO TECH y AURO Motions tienen `PENDIENTES.md` con checkboxes; AURO 3D tiene `docs/PLAN-OPERATIVO.md` y el laboratorio `PROGRESO.md` (formatos de tareas/estado sin casillas). La proyección federada futura debe preservar fuente, owner, estado, tipo de documento y dependencias sin autoeditar ningún repo.
- Prueba real `workflow_guide_recommend`: pedido amplio de coordinar checklists/owners dio una skill genérica `mauroprime-bridge-collaboration`, mientras `cross-project-context-inventory` quedó score 2; con el ejemplo explícito de «reconstruí últimos 7 días... tareas abiertas» la guía obtuvo score 14 y fue seleccionada. **La guía existe y carga**, pero la activación por paráfrasis no siempre la prefiere. Owner para evaluar matching/guide: `D:\Dev\bridge-mcp`, con casos positivos/negativos; MSSR solo si se demuestra defecto del contrato semántico común.
- Telemetría Bridge, últimos 7 días: 440 trazas, 838 rutas estructuradas, 131 trazas con skill load, 31 con verify, 27 con persist y 105 con outcome. No concluir que los otros trabajos estén fallidos, y no cerrar trazas automáticamente.
- Historial host filtrado por `mssr-project-maintenance` mostró 59 avisos `review-due` y 4 `review-resolved` en la ventana consultada; son **eventos**, no 59 necesidades únicas ni prueba de 4 mantenimientos resueltos. `projectMaintenanceAttention` existe en fuente portable y host, pero entrega de notice no prueba mantenimiento, cierre ni recepción visible del usuario.
- MSSR `project_context_health` marca `many-modules` review con 51 módulos y presupuestos core/módulos cercanos al límite. Antes de extender, priorizar selectores, agrupación, referencia puntual o documentar `reviewed-none` con evidencia. No inflar el core ni crear segunda cola de notices.

**Gate futuro:** observatorio realiza federación read-only/links de fuentes heterogéneas con test de privacidad y dedupe; Bridge activa guías para intención transversal mediante matching probado y entrega avisos accionables; MSSR conserva evaluación pura, provenance y aislamiento de traza por owner. Las mejoras sistémicas quedan aparcadas frente a la primera pieza comercial modelada en Blender.
