# Integration and release friction

Read when repository, project, document or MCP work reaches integration,
generated-output, lifecycle, version or publication failures. Preserve evidence,
canonical owner and next gate; a successful step is not whole-task completion.

## Reusable patterns

- **Superseded sibling branches:** compare merge-base, unique commits and diffs;
  choose the superset, rescue isolated useful work, preserve it before removing
  temporary worktrees. Passing independently does not justify merging both.
- **Generated-count conflicts:** retain current capabilities, apply the new
  semantic rule, regenerate docs/registry outputs from canonical source and
  derive counts after resolution.
- **Stale generated docs:** regenerate `TOOLS.md`, manifests or dashboards from
  canonical registries and run `--check`; don't hand-edit generated counts.
- **YAML passes regex only:** parse real YAML and validate keys, name/folder,
  quoting and Codex discovery. Presence of `name`/`description` is not proof
  the host loaded a skill.
- **Accidental artifacts:** inspect untracked/index changes for caches, logs,
  captures, prompts and secrets; ignore or remove only after ownership review.
- **Test prints success but hangs:** inspect remaining handles/processes; expose
  and test disposal on both success and failure. A timeout is only a safety net.
- **Live service older than source:** finish source/version/docs/tests first;
  request controlled restart separately, then verify live version and catalog.
  Never rewrite expectations to match a stale service.
- **Partial version bump:** search all version-bearing source, lock, docs and
  tests; update from one release decision and run consistency checks.
- **Mixed source/live verifier:** separate source and post-restart gates; report
  which failed rather than treating an intentional stale-host check as source
  regression.

## Confirmed incidents (2026-11-12)

### Lost long-command session handle

An initial 30-second wait ended before MSSR `verify`; the wrapper lost its
session id, so the exit code was unavailable. Progress was recovered from a
log. Always store and poll long-command handles; if lost, inspect process/log
evidence and rerun a bounded authoritative gate before claiming success.

### npm pack dry-run reruns prepare

`npm pack --dry-run --json --ignore-scripts` still invoked `prepare` during
first-party conformance. The nested TypeScript build failed in Node with
`Zone Allocation failed` (Windows `3221226505`, npm `134`) although direct build
and one full verify had passed. Replaced the test invocation with npm Arborist +
`npm-packlist`, checking included paths without lifecycle scripts. Real release
packing still requires `release:gate` and its read-back receipt.

### V8/Windows commit pressure leaves release unverified

One standalone build failed near a 500 MB heap, then passed with
`NODE_OPTIONS=--max-old-space-size=2048` while host RAM was ~1.9 GB free. Later,
standalone first-party conformance passed after the packlist change and one full
verify had passed before that test-only change. Gate-internal verify and a later
direct verify failed during TypeScript allocation around 450–550 MB; Windows
reported ~663 MB free virtual memory with several large user processes active.
Do not close them or infer a product defect. Latest source build passed once
with the 2 GB setting; full latest-tree verification and package receipt remain
pending.

The package conformance test passed once after the resolver change, then a later
rerun failed during Node startup at ~50 MB with V8 heap allocation failure. This
is consistent with worsening host commit pressure, not evidence of a package
assertion failure; retain the pass and failure as separate observations.
