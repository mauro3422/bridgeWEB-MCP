import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  createMssrHostCapabilityMessages,
  loadProjectContextHost,
  MssrAdapter,
  mssrHostCapabilityObservationSchema,
  selectMssrContextMessages,
  structuredSkillIntentSchema,
} from "../dist/index.js";

const now = new Date("2026-11-11T12:00:00.000Z");
const baseObservation = {
  id: "github-cli",
  capability: "github-cli",
  freshnessClass: "session",
  host: "codex-local",
  availability: "available",
  authentication: "authenticated",
  authorization: "unknown",
  connectivity: "not-checked",
  version: "2.96.0",
  observedAt: now.toISOString(),
  selectors: {
    stages: ["start", "resume"],
    domains: ["github"],
    actions: ["publish", "version"],
    artifacts: ["repository"],
    needs: ["version-control"],
    signals: ["nominal"],
  },
};
const publicationIntent = structuredSkillIntentSchema.parse({
  domains: ["github"], actions: ["publish"], artifacts: ["repository"],
  needs: ["version-control"], signals: ["nominal"], risk: "read-only",
});
const unrelatedIntent = structuredSkillIntentSchema.parse({
  domains: ["coding"], actions: ["review"], artifacts: ["code"],
  needs: ["unit-tests"], signals: ["nominal"], risk: "read-only",
});

// Correct task and stage receive the host fact; unrelated work does not.
const fresh = createMssrHostCapabilityMessages([baseObservation], now);
const selected = selectMssrContextMessages({ messages: fresh, intent: publicationIntent, stage: "start" });
assert.equal(selected.selected.length, 1);
assert.match(selected.selected[0].summary, /authenticated/);
assert.match(selected.selected[0].summary, /authorization=unknown/);
assert.deepEqual(selectMssrContextMessages({ messages: fresh, intent: unrelatedIntent, stage: "start" }).selected, []);
assert.deepEqual(selectMssrContextMessages({ messages: fresh, intent: publicationIntent, stage: "verify" }).selected, []);

// Expired evidence is explicitly stale and requests a host refresh.
const staleObservation = { ...baseObservation, freshnessClass: "volatile", observedAt: "2026-11-11T11:44:00.000Z" };
const stale = createMssrHostCapabilityMessages([staleObservation], now)[0];
assert.equal(stale.evidence[0].freshness, "stale");
assert.ok(stale.signals.includes("provider-refresh-needed"));
assert.match(stale.summary, /stale/);

// Authentication for a host-reported live session does not expire by clock alone.
const longLivedSession = createMssrHostCapabilityMessages([{
  ...baseObservation, observedAt: "2026-11-10T12:00:00.000Z",
}], now)[0];
assert.equal(longLivedSession.evidence[0].freshness, "fresh");
assert.match(longLivedSession.summary, /active/);

// Installation/version evidence has a longer bounded window than volatile probes.
const oldInstallation = createMssrHostCapabilityMessages([{
  ...baseObservation, freshnessClass: "installation", observedAt: "2026-11-10T11:00:00.000Z",
}], now)[0];
assert.equal(oldInstallation.evidence[0].freshness, "stale");

// Missing authentication and insufficient authorization remain distinct facts.
const limited = createMssrHostCapabilityMessages([{
  ...baseObservation, id: "gh-limited", authentication: "not-authenticated", authorization: "insufficient",
}], now)[0];
assert.match(limited.summary, /authentication=not-authenticated/);
assert.match(limited.summary, /authorization=insufficient/);

// Freeform credential/account payloads are rejected by the strict schema.
assert.equal(mssrHostCapabilityObservationSchema.safeParse({ ...baseObservation, token: "never-accept" }).success, false);
assert.equal(mssrHostCapabilityObservationSchema.safeParse({ ...baseObservation, accountName: "private-user" }).success, false);

// Host observations participate in one route only and never enter project runtime inbox state.
const root = await mkdtemp(join(tmpdir(), "mssr-host-capability-"));
try {
  const result = await loadProjectContextHost({
    projectRoot: root,
    intent: publicationIntent,
    stage: "start",
    now: now.toISOString(),
    hostCapabilities: [baseObservation],
  });
  assert.ok(result.contextMessages.selected.some((message) => message.kind === "host-capability"));
  assert.equal(result.inbox.enqueued.some((id) => id.startsWith("host-capability:")), false);
  assert.equal(result.inbox.saved, false);
  await assert.rejects(() => readFile(result.inbox.filePath, "utf8"), { code: "ENOENT" });
} finally {
  await rm(root, { recursive: true, force: true });
}

const adapter = new MssrAdapter(undefined, { caller: "codex-local", tracePrefix: "host-capability-test" });
try {
  await adapter.initialize();
  const route = await adapter.route({
    task: "Publish this verified change to GitHub.",
    intent: publicationIntent,
    stage: "start",
    traceId: "host-capability-route-1",
    contextNow: now.toISOString(),
    hostCapabilities: [baseObservation],
    projectRoot: root,
  });
  assert.ok(route.contextMessages.selected.some((message) => message.kind === "host-capability"));
  assert.equal(route.projectMaintenance?.due, true, "project activation should surface uninitialized project maintenance advisory");
  assert.equal(route.projectMaintenance?.targets.some((target) => target.target === "context"), true);
  assert.equal(route.projectMaintenance?.advisoryOnly, true);
  const withoutProject = await adapter.route({
    task: "Answer a general question without a project target.",
    intent: unrelatedIntent,
    stage: "start",
    traceId: "host-capability-no-project",
  });
  assert.equal(Object.hasOwn(withoutProject, "projectMaintenance"), false, "activation scan must not run without a project root");
  const changedProjectAuthority = await adapter.route({
    task: "Update a project authority after material context changes.",
    intent: structuredSkillIntentSchema.parse({
      domains: ["filesystem", "skill-system"], actions: ["edit", "maintain"],
      artifacts: ["project", "repository"], signals: ["reusable-pattern"], risk: "write",
    }),
    stage: "persist",
    traceId: "host-capability-project-maintenance",
    projectRoot: root,
    projectMaintenanceEvidence: {
      changedPaths: ["docs/decisions/0001-example.md", ".mssr/knowledge/state/PROJECT_STATE.md"],
      materialWrites: 3,
    },
  });
  assert.equal(changedProjectAuthority.projectMaintenance?.due, true);
  assert.ok(changedProjectAuthority.projectMaintenance?.targets.some((target) => target.target === "context"));
  assert.ok(changedProjectAuthority.projectMaintenanceAttention?.fingerprint);
  assert.equal(changedProjectAuthority.projectMaintenanceAttention?.advisoryOnly, true);
  const repeatedEvidence = await adapter.route({
    task: "Repeat the same maintenance evidence.",
    intent: structuredSkillIntentSchema.parse({
      domains: ["filesystem", "skill-system"], actions: ["edit", "maintain"],
      artifacts: ["project", "repository"], signals: ["reusable-pattern"], risk: "write",
    }),
    stage: "persist",
    traceId: "host-capability-project-maintenance-repeat",
    projectRoot: root,
    projectMaintenanceEvidence: {
      changedPaths: ["docs/decisions/0001-example.md", ".mssr/knowledge/state/PROJECT_STATE.md"],
      materialWrites: 3,
    },
  });
  assert.equal(repeatedEvidence.projectMaintenanceAttention?.fingerprint, changedProjectAuthority.projectMaintenanceAttention?.fingerprint);
} finally {
  await adapter.dispose?.();
}

console.log("host capability context tests passed");
