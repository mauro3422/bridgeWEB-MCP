import assert from "node:assert/strict";
import {
  MSSR_EVENT_TRIGGER_EVALUATION_CONTRACT,
  MSSR_EVENT_TRIGGER_RECEIPT_SCHEMA,
  evaluateMssrEventTrigger,
} from "../dist/index.js";

const instant = "2026-11-13T12:00:00.000Z";
const intent = {
  summary: "Review the watched repository change.",
  domains: ["github"],
  actions: ["review"],
  artifacts: ["repository"],
  needs: ["integrity-verification"],
  signals: ["nominal"],
  risk: "read-only",
  ambiguity: "low",
};
const trigger = {
  id: "watch.repo-release",
  acceptedSources: ["github:repo-events"],
  eventTypes: ["release.published"],
  subject: "repo:owner/project",
  intent,
  cooldownMs: 5_000,
  maxAgeMs: 60_000,
  dedupeWindowMs: 3_600_000,
};
const nativeEvent = {
  source: "github:repo-events",
  sourceKind: "native-event",
  eventType: "release.published",
  eventId: "evt-001",
  subject: "repo:owner/project",
  observedAt: instant,
  occurredAt: instant,
  dedupeKey: "delivery-001",
  freshness: "fresh",
  authenticity: "verified",
  sourceHealth: "available",
};

const accepted = evaluateMssrEventTrigger(nativeEvent, trigger, { evaluatedAt: instant });
assert.equal(accepted.contract, MSSR_EVENT_TRIGGER_EVALUATION_CONTRACT);
assert.equal(accepted.status, "matched");
assert.equal(accepted.reason, "event-matched");
assert.equal(accepted.intent?.signals[0], "nominal");
assert.equal(accepted.executionAuthorized, false);
assert.equal(accepted.routingInfluence, false);
assert.equal(accepted.advisoryOnly, true);
assert.equal(accepted.receiptProposal?.schemaVersion, MSSR_EVENT_TRIGGER_RECEIPT_SCHEMA);
assert.match(accepted.eventFingerprint, /^sha256:[a-f0-9]{64}$/);
for (const sourceKind of ["provider-notification", "local-runtime-event"]) {
  assert.equal(evaluateMssrEventTrigger({ ...nativeEvent, sourceKind }, trigger, { evaluatedAt: instant }).status, "matched");
}

const duplicate = evaluateMssrEventTrigger({ ...nativeEvent, dedupeKey: "redelivery-002" }, trigger, {
  evaluatedAt: "2026-11-13T12:00:01.000Z",
  priorReceipt: accepted.receiptProposal,
});
assert.equal(duplicate.status, "duplicate", "provider redelivery with the same event id must not match twice");
assert.equal(duplicate.reason, "event-already-accepted");
assert.equal(duplicate.intent, undefined);

const cooldownEvent = { ...nativeEvent, eventId: "evt-002", dedupeKey: "delivery-002" };
const cooling = evaluateMssrEventTrigger(cooldownEvent, trigger, {
  evaluatedAt: "2026-11-13T12:00:02.000Z",
  priorReceipt: accepted.receiptProposal,
});
assert.equal(cooling.status, "ignored");
assert.equal(cooling.reason, "cooldown-active");
const afterCooldown = evaluateMssrEventTrigger(cooldownEvent, trigger, {
  evaluatedAt: "2026-11-13T12:00:06.000Z",
  priorReceipt: accepted.receiptProposal,
});
assert.equal(afterCooldown.status, "matched");

assert.equal(evaluateMssrEventTrigger({ ...nativeEvent, freshness: "unknown" }, trigger, { evaluatedAt: instant }).status, "stale");
assert.equal(evaluateMssrEventTrigger({ ...nativeEvent, occurredAt: "2026-11-13T11:58:00.000Z" }, trigger, { evaluatedAt: instant }).reason, "event-stale");
assert.equal(evaluateMssrEventTrigger({ ...nativeEvent, occurredAt: "2026-11-13T12:02:00.000Z" }, trigger, { evaluatedAt: instant }).reason, "event-time-in-future");
assert.equal(evaluateMssrEventTrigger({ ...nativeEvent, authenticity: "unknown" }, trigger, { evaluatedAt: instant }).reason, "source-authenticity-unverified");
assert.equal(evaluateMssrEventTrigger({ ...nativeEvent, sourceHealth: "degraded" }, trigger, { evaluatedAt: instant }).reason, "source-unavailable");
assert.equal(evaluateMssrEventTrigger({ ...nativeEvent, source: "other:provider" }, trigger, { evaluatedAt: instant }).reason, "source-not-accepted");
assert.equal(evaluateMssrEventTrigger({ ...nativeEvent, eventType: "issue.opened" }, trigger, { evaluatedAt: instant }).reason, "event-type-not-accepted");
assert.equal(evaluateMssrEventTrigger({ ...nativeEvent, subject: "repo:other/project" }, trigger, { evaluatedAt: instant }).reason, "subject-not-matched");
assert.equal(evaluateMssrEventTrigger(nativeEvent, { ...trigger, enabled: false }, { evaluatedAt: instant }).reason, "trigger-disabled");
assert.equal(evaluateMssrEventTrigger(nativeEvent, trigger, {
  evaluatedAt: instant,
  priorReceipt: { ...accepted.receiptProposal, triggerId: "watch.other" },
}).reason, "prior-receipt-trigger-mismatch");
assert.equal(evaluateMssrEventTrigger(nativeEvent, trigger, {
  evaluatedAt: instant,
  priorReceipt: { ...accepted.receiptProposal, lastMatchedAt: "2026-11-13T12:01:00.000Z" },
}).reason, "prior-receipt-time-in-future");

const fallbackTrigger = {
  ...trigger,
  pollFallbackPolicy: { maxIntervalMs: 60_000, maxBackoffMs: 240_000 },
};
const fallbackEvent = {
  ...nativeEvent,
  sourceKind: "poll-fallback",
  eventId: "poll-001",
  dedupeKey: "poll-001",
  authenticity: "host-verified",
  sourceHealth: "degraded",
  polling: { intervalMs: 30_000, backoffMs: 60_000, maxBackoffMs: 240_000 },
};
const fallback = evaluateMssrEventTrigger(fallbackEvent, fallbackTrigger, { evaluatedAt: instant });
assert.equal(fallback.status, "matched");
assert.deepEqual(fallback.intent?.signals, ["degraded-capability"]);
assert.deepEqual(fallback.capabilityNeeds, ["native event source for this trigger"]);
assert.equal(fallback.executionAuthorized, false);
assert.equal(evaluateMssrEventTrigger(fallbackEvent, trigger, { evaluatedAt: instant }).reason, "fallback-policy-missing");
assert.equal(evaluateMssrEventTrigger({ ...fallbackEvent, polling: { ...fallbackEvent.polling, intervalMs: 90_000, backoffMs: 120_000 } }, fallbackTrigger, { evaluatedAt: instant }).reason, "fallback-bounds-exceeded");
assert.throws(() => evaluateMssrEventTrigger({ ...fallbackEvent, polling: undefined }, fallbackTrigger, { evaluatedAt: instant }), /requires bounded cadence and backoff/);

assert.throws(() => evaluateMssrEventTrigger({ ...nativeEvent, body: "raw webhook body" }, trigger, { evaluatedAt: instant }), /Unrecognized key/,
  "raw event bodies are outside the portable envelope");
assert.throws(() => evaluateMssrEventTrigger(nativeEvent, {
  ...trigger,
  acceptedSources: [],
  eventTypes: [],
  subject: undefined,
}, { evaluatedAt: instant }), /at least one bounded/,
"unbounded catch-all trigger specifications are invalid");

console.log("MSSR portable event-trigger evaluator tests passed");
