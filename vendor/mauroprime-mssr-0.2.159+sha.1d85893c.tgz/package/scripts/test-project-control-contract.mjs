import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";
import {
  CapabilityRegistry,
  MSSR_PROJECT_CONTROL_TOOL_NAMES,
  mssrInstructionImpactReviewInputSchema,
  mssrProjectDataRequirementsInputSchema,
  OpenCodeMssrAdapter,
  createCodexMssrMcpServer,
  createMssrMcpServer,
  createOpenCodeMssrMcpServer,
} from "../dist/index.js";

function json(result) {
  const item = result.content?.find((entry) => entry.type === "text");
  assert.ok(item?.text, "Expected text MCP response");
  return JSON.parse(item.text);
}

async function connect(kind) {
  const registry = new CapabilityRegistry([{ id: `${kind}-empty`, async refresh() { return { capabilities: [] }; } }]);
  let created;
  if (kind === "native") created = createMssrMcpServer(registry);
  else if (kind === "codex") created = createCodexMssrMcpServer();
  else {
    const adapter = new OpenCodeMssrAdapter(registry);
    await adapter.initialize();
    created = createOpenCodeMssrMcpServer(adapter);
  }
  const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
  await created.server.connect(serverTransport);
  const client = new Client({ name: `mssr-project-control-${kind}`, version: "1.0.0" }, { capabilities: {} });
  await client.connect(clientTransport);
  return { ...created, client };
}

const hosts = {
  native: await connect("native"),
  codex: await connect("codex"),
  opencode: await connect("opencode"),
};

const schemas = {};
for (const [kind, host] of Object.entries(hosts)) {
  const listed = await host.client.listTools();
  const names = listed.tools.map((tool) => tool.name);
  for (const name of MSSR_PROJECT_CONTROL_TOOL_NAMES) {
    assert.equal(names.includes(name), true, `${kind} missing shared project-control tool ${name}`);
    schemas[`${kind}:${name}`] = listed.tools.find((tool) => tool.name === name)?.inputSchema;
  }
}
for (const name of MSSR_PROJECT_CONTROL_TOOL_NAMES) {
  assert.deepEqual(schemas[`codex:${name}`], schemas[`native:${name}`], `${name} schema drift: Codex`);
  assert.deepEqual(schemas[`opencode:${name}`], schemas[`native:${name}`], `${name} schema drift: OpenCode`);
}

const instructionImpactInput = {
  ruleId: "workspace-managed-instruction",
  ruleRevision: "sha256:rule-r2",
  canonicalOwner: "D:/Dev/AGENTS.md",
  instructionKind: "workspace-global",
  scope: "workspace",
  changeKind: "updated",
  sourceRef: "D:/Dev/AGENTS.md#managed-mssr-routing",
  consumers: [
    { consumerId: "auro-tech", consumerKind: "project", owner: "D:/Dev/auro-tech", dependencyKind: "inherited", applicability: "applicable", currentAppliedRevision: "sha256:rule-r1", adoptionStatus: "verified", evidenceRef: "D:/Dev/auro-tech/AGENTS.md", evidenceFreshness: "fresh", observedAt: "2026-11-13T12:00:00Z" },
    { consumerId: "auro-motions", consumerKind: "project", owner: "D:/Dev/auro-motions", dependencyKind: "inherited", applicability: "applicable", currentAppliedRevision: "sha256:rule-r2", adoptionStatus: "verified", evidenceRef: "D:/Dev/auro-motions/AGENTS.md", evidenceFreshness: "fresh", observedAt: "2026-11-13T12:00:00Z" },
    { consumerId: "codex-host", consumerKind: "host", owner: "codex-local", dependencyKind: "declared", applicability: "applicable", currentAppliedRevision: "sha256:rule-r1", adoptionStatus: "blocked", evidenceRef: "codex://host/instructions", evidenceFreshness: "fresh", observedAt: "2026-11-13T12:00:00Z", conflictRefs: ["D:/Dev/auro-tech/AGENTS.md#local-override"] },
    { consumerId: "paused-project", consumerKind: "project", owner: "D:/Dev/paused-project", dependencyKind: "declared", applicability: "not-applicable", adoptionStatus: "not-applicable" },
    { consumerId: "uncertain-host", consumerKind: "host", owner: "host-unknown", dependencyKind: "observed", applicability: "unknown", adoptionStatus: "unknown" },
    { consumerId: "stale-host", consumerKind: "host", owner: "host-stale", dependencyKind: "observed", applicability: "applicable", currentAppliedRevision: "sha256:rule-r2", adoptionStatus: "verified", evidenceRef: "host:runtime-snapshot", evidenceFreshness: "stale", observedAt: "2026-11-12T12:00:00Z" },
    { consumerId: "approved-host", consumerKind: "host", owner: "host-approved", dependencyKind: "declared", applicability: "applicable", currentAppliedRevision: "sha256:rule-r1", adoptionStatus: "approved", evidenceRef: "host:review", evidenceFreshness: "fresh", observedAt: "2026-11-13T12:00:00Z" },
    { consumerId: "applied-host", consumerKind: "host", owner: "host-applied", dependencyKind: "declared", applicability: "applicable", currentAppliedRevision: "sha256:rule-r2", adoptionStatus: "applied", evidenceRef: "host:runtime-snapshot", evidenceFreshness: "fresh", observedAt: "2026-11-13T12:00:00Z" },
  ],
};
for (const kind of ["native", "codex", "opencode"]) {
  const impact = json(await hosts[kind].client.callTool({ name: "mssr_instruction_impact_review", arguments: instructionImpactInput }));
  assert.equal(impact.schemaVersion, 1, `${kind} instruction impact schema version`);
  assert.equal(impact.reviewRequired, true, `${kind} must surface stale or unresolved consumers`);
  assert.equal(impact.blocked, true, `${kind} must surface explicit conflicts`);
  assert.equal(impact.authorizationGranted, false, `${kind} must not grant authorization`);
  assert.equal(impact.persistencePerformed, false, `${kind} must not persist adoption`);
  assert.equal(impact.consumerDiscoveryPerformed, false, `${kind} must not scan/discover consumers`);
  assert.deepEqual(impact.consumers.map((item) => item.disposition), ["review-due", "verified", "blocked", "not-applicable", "review-due", "review-due", "application-pending", "verification-pending"]);
  assert.equal(impact.consumers[0].reasonCode, "revision-missing-or-different");
  assert.equal(impact.consumers[1].nextGate, "none");
  assert.equal(impact.consumers[2].nextGate, "resolve-conflict");
  assert.equal(impact.consumers[2].priority, "high");
  assert.equal(impact.consumers[5].reasonCode, "consumer-evidence-stale", "a stale readback cannot prove current adoption");
  assert.equal(impact.consumers[6].nextGate, "apply-reviewed-change");
  assert.equal(impact.consumers[7].nextGate, "verify-current-readback");
  assert.equal(impact.consumers[3].dedupeKey, json(await hosts[kind].client.callTool({ name: "mssr_instruction_impact_review", arguments: instructionImpactInput })).consumers[3].dedupeKey, "repeated evaluation must preserve a deterministic dedupe identity");
  assert.deepEqual(schemas[`${kind}:mssr_instruction_impact_review`], schemas[`native:mssr_instruction_impact_review`], `${kind} instruction impact schema drift`);
}
const noImpact = {
  ...instructionImpactInput,
  consumers: [{ consumerId: "unrelated", consumerKind: "project", owner: "D:/Dev/unrelated", dependencyKind: "declared", applicability: "not-applicable", adoptionStatus: "not-applicable" }],
};
const noImpactResult = json(await hosts.native.client.callTool({ name: "mssr_instruction_impact_review", arguments: noImpact }));
assert.equal(noImpactResult.reviewRequired, false, "explicitly non-applicable consumers must remain quiet");
assert.equal(noImpactResult.consumers[0].disposition, "not-applicable");
assert.equal(mssrInstructionImpactReviewInputSchema.safeParse({
  ...noImpact,
  consumers: [{ consumerId: "unverified", consumerKind: "host", owner: "codex", dependencyKind: "declared", applicability: "applicable", adoptionStatus: "verified", evidenceFreshness: "fresh" }],
}).success, false, "fresh adoption evidence must include source and observation time");

const projectDataRequirementsInput = {
  requirements: [
    {
      requirementId: "filament-nozzle-range", projectId: "impresion-3d-lab", canonicalOwner: "D:/Dev/impresion-3d-lab",
      subjectRef: "filaments/filanova-amazon-green", field: "nozzle-temperature-range", purpose: "validate isolated slicing profile",
      importance: "blocking", acceptedSourceKinds: ["owner-project-reference"], lookupStatus: "completed", refreshAvailable: true,
      userCanProvide: true,
      evidence: [{ sourceKind: "owner-project-reference", canonicalOwner: "D:/Dev/impresion-3d-lab", ref: ".mssr/knowledge/reference/filament-family-profiles-a2l.md#filanova-amazon-green", state: "present", freshness: "fresh", observedAt: "2026-11-13T12:00:00Z", revision: "sha256:label-rev-1" }],
    },
    {
      requirementId: "optional-manufacturer", projectId: "impresion-3d-lab", canonicalOwner: "D:/Dev/impresion-3d-lab",
      subjectRef: "filaments/ams-tray-4", field: "manufacturer", purpose: "record provenance if available",
      importance: "optional", acceptedSourceKinds: ["owner-project-reference", "provider-observation"], lookupStatus: "unavailable",
      userCanProvide: false,
    },
    {
      requirementId: "missing-required-profile", projectId: "impresion-3d-lab", canonicalOwner: "D:/Dev/impresion-3d-lab",
      subjectRef: "filaments/new-roll", field: "nozzle-temperature-range", purpose: "select safe profile",
      importance: "blocking", acceptedSourceKinds: ["owner-project-reference", "label"], lookupStatus: "completed", userCanProvide: true,
    },
    {
      requirementId: "not-yet-searched", projectId: "auro-tech", canonicalOwner: "D:/Dev/auro-tech",
      subjectRef: "product/organizer", field: "approved-background-reference", purpose: "prepare final product render",
      importance: "blocking", acceptedSourceKinds: ["owner-project-reference"], lookupStatus: "not-attempted", userCanProvide: true,
    },
    {
      requirementId: "stale-optional", projectId: "impresion-3d-lab", canonicalOwner: "D:/Dev/impresion-3d-lab",
      subjectRef: "filaments/old-roll", field: "current-availability", purpose: "decide whether to test this roll",
      importance: "optional", acceptedSourceKinds: ["owner-project-reference"], lookupStatus: "completed", refreshAvailable: true,
      evidence: [{ sourceKind: "owner-project-reference", canonicalOwner: "D:/Dev/impresion-3d-lab", ref: "inventory.md#old-roll", state: "stale", freshness: "stale", observedAt: "2026-10-01T12:00:00Z", revision: "rev-1" }],
    },
    {
      requirementId: "contradictory-sources", projectId: "auro-tech", canonicalOwner: "D:/Dev/auro-tech",
      subjectRef: "brand/logo", field: "approved-primary-variant", purpose: "select official export",
      importance: "blocking", acceptedSourceKinds: ["owner-project-reference"], lookupStatus: "completed",
      evidence: [{ sourceKind: "owner-project-reference", canonicalOwner: "D:/Dev/auro-tech", ref: "brand/current.md#logo", state: "contradictory", freshness: "fresh", observedAt: "2026-11-13T12:00:00Z", revision: "rev-2", relatedRefs: ["brand/archive.md#logo"] }],
    },
  ],
};
for (const kind of ["native", "codex", "opencode"]) {
  const result = json(await hosts[kind].client.callTool({ name: "mssr_project_data_requirements_evaluate", arguments: projectDataRequirementsInput }));
  assert.equal(result.advisoryOnly, true);
  assert.equal(result.authorizationGranted, false);
  assert.equal(result.sourceSearchPerformed, false);
  assert.equal(result.userQuestionAsked, false);
  assert.equal(result.persistencePerformed, false);
  assert.deepEqual(result.requirements.map((item) => item.status), ["satisfied", "continue-with-gap", "request-minimum-data", "retrieve-source", "refresh-source", "resolve-conflict"]);
  assert.equal(result.requirements[2].nextGate, "ask-for-minimum-field");
  assert.equal(result.requirements[3].nextGate, "search-authorized-source", "search comes before asking for missing blocking data");
  assert.equal(result.blockingRequirementsSatisfied, false);
  assert.equal(result.userQuestionRecommended, true);
  assert.deepEqual(schemas[`${kind}:mssr_project_data_requirements_evaluate`], schemas[`native:mssr_project_data_requirements_evaluate`], `${kind} data-requirement schema drift`);
}
const noTaskRequirements = json(await hosts.native.client.callTool({ name: "mssr_project_data_requirements_evaluate", arguments: { requirements: [] } }));
assert.equal(noTaskRequirements.blockingRequirementsSatisfied, true);
assert.equal(noTaskRequirements.userQuestionRecommended, false, "ordinary work with no declared requirements must not prompt");
assert.equal(noTaskRequirements.requirements.length, 0);
assert.equal(mssrProjectDataRequirementsInputSchema.safeParse({ requirements: [{ requirementId: "x", projectId: "p", canonicalOwner: "p", subjectRef: "s", field: "f", purpose: "p", importance: "blocking", acceptedSourceKinds: [], lookupStatus: "not-attempted", evidence: [{ sourceKind: "other", canonicalOwner: "p", ref: "x", state: "present", freshness: "fresh" }] }] }).success, false, "fresh field evidence must retain a revision and observedAt");

const ownershipInput = {
  transactionId: "cross-host-tx-20261112", sourceProject: "source-repo", targetProject: "owner-repo",
  currentTraceId: "source-trace-001", relatedTraceId: "owner-trace-001", artifactKind: "asset", operation: "copy",
  ownerClaim: { ownerProject: "owner-repo", authoritySource: "manifest", authorityRevision: "rev-1", scope: "commercial-work-asset", observedAt: "2026-11-12T12:00:00Z", confidenceKind: "declared", conflicts: [] },
};
for (const kind of ["native", "codex", "opencode"]) {
  const ownership = json(await hosts[kind].client.callTool({ name: "mssr_cross_repo_ownership_evaluate", arguments: ownershipInput }));
  assert.equal(ownership.decision, "cross-repo-review-required", `${kind} ownership result`);
  assert.equal(ownership.authorizationGranted, false, `${kind} must never grant write authorization`);
  assert.equal(ownership.advisoryOnly, true);
  const transition = json(await hosts[kind].client.callTool({ name: "mssr_cross_repo_transaction_transition_validate", arguments: { from: "verified", to: "committed", pointerUpdated: true } }));
  assert.equal(transition.valid, false, `${kind} must require pointer-updated before commit`);
  const committed = json(await hosts[kind].client.callTool({ name: "mssr_cross_repo_transaction_transition_validate", arguments: { from: "pointer-updated", to: "committed", pointerUpdated: true, pointerUpdateReceipt: "receipt:owner-manifest:rev-2" } }));
  assert.equal(committed.valid, true, `${kind} must accept evidenced pointer update`);
}

const root = await fs.mkdtemp(path.join(os.tmpdir(), "mssr-project-control-cross-host-"));
try {
  const repo = path.join(root, "repo");
  await fs.mkdir(path.join(repo, ".git"), { recursive: true });

  const initialized = json(await hosts.native.client.callTool({
    name: "mssr_project_initialize",
    arguments: { projectRoot: repo },
  }));
  assert.equal(initialized.initialized, true);
  assert.equal(initialized.manifestStatus, "valid");
  await fs.access(path.join(repo, ".mssr", "project-context.json"));
  await fs.access(path.join(repo, ".mssr", "knowledge"));
  await fs.access(path.join(repo, ".mssr", "runtime"));

  for (const kind of ["native", "codex", "opencode"]) {
    const health = json(await hosts[kind].client.callTool({
      name: "mssr_project_health",
      arguments: { projectRoot: repo },
    }));
    assert.equal(health.level, "ok", `${kind} health must agree`);
    assert.equal(health.manifestStatus, "valid");

    const capture = json(await hosts[kind].client.callTool({
      name: "mssr_project_capture_plan",
      arguments: {
        id: "routing-law",
        topic: "law",
        area: "routing",
        title: "Routing ownership law",
        content: "Only one canonical layer owns each routing decision.",
        domains: ["skill-system"],
        actions: ["design", "review"],
        artifacts: ["project"],
        signals: ["reusable-pattern"],
      },
    }));
    assert.equal(capture.relativePath, ".mssr/knowledge/law/routing-law.md");
    assert.equal(capture.module.topic, "law");
    assert.equal(capture.module.area, "routing");
    assert.equal(capture.advisoryOnly, true);

    const modularization = json(await hosts[kind].client.callTool({
      name: "mssr_project_modularization_plan",
      arguments: { projectRoot: repo },
    }));
    assert.equal(modularization.status, "not-needed", `${kind} modularization planner must agree on healthy fixture`);
    assert.deepEqual(modularization.candidates, []);
    assert.equal(modularization.advisoryOnly, true);
  }

  const nested = path.join(root, "nested", "repo-b");
  await fs.mkdir(path.join(nested, ".git"), { recursive: true });
  const workspace = json(await hosts.codex.client.callTool({
    name: "mssr_workspace_initialize",
    arguments: { workspaceRoot: root, maxDepth: 3 },
  }));
  assert.equal(workspace.projectCount, 2);
  assert.equal(workspace.blocked.length, 0);

  const blockedRepo = path.join(root, "blocked");
  await fs.mkdir(path.join(blockedRepo, ".git"), { recursive: true });
  await fs.mkdir(path.join(blockedRepo, ".bridge"), { recursive: true });
  await fs.writeFile(path.join(blockedRepo, ".bridge", "PROJECT_MEMORY.md"), "historical durable memory\n", "utf8");
  const blocked = json(await hosts.opencode.client.callTool({
    name: "mssr_project_initialize",
    arguments: { projectRoot: blockedRepo, initializeMissing: true, cleanupLegacyArtifacts: true },
  }));
  assert.equal(blocked.initialized, false);
  assert.deepEqual(blocked.legacy.blocked, [".bridge/PROJECT_MEMORY.md"]);
  await fs.access(path.join(blockedRepo, ".bridge", "PROJECT_MEMORY.md"));
  await assert.rejects(() => fs.access(path.join(blockedRepo, ".mssr", "PROJECT_MEMORY.md")));
} finally {
  await Promise.all(Object.values(hosts).map(({ client, server }) => Promise.allSettled([client.close(), server.close()])));
  await fs.rm(root, { recursive: true, force: true });
}

console.log("MSSR project-control cross-host tests PASS");
