import assert from "node:assert/strict";
import {
  evaluateMssrCrossRepoAssetOwnership as evaluate,
  validateMssrCrossRepoOwnershipTransition as transition,
} from "../dist/index.js";

const hash = "a".repeat(64);
const common = {
  transactionId: "asset-copy-2026-11-12",
  sourceProject: "impresion-3d-lab",
  targetProject: "Auro-3D",
  currentTraceId: "trace-source-001",
  relatedTraceId: "trace-target-001",
  artifactKind: "asset",
  operation: "copy",
  ownerClaim: {
    ownerProject: "Auro-3D",
    authoritySource: "manifest",
    authorityRevision: "git:abc123",
    scope: "commercial-work-asset",
    observedAt: "2026-11-12T12:00:00Z",
    confidenceKind: "declared",
    conflicts: [],
  },
};

const review = evaluate(common);
assert.equal(review.decision, "cross-repo-review-required");
assert.equal(review.hostWriteGate, "review-required");
assert.equal(review.authorizationGranted, false);
assert.equal(review.advisoryOnly, true);

const accepted = evaluate({ ...common, explicitCopyReview: true, sourceHash: hash });
assert.equal(accepted.decision, "cross-repo-copy-reviewed");
assert.equal(accepted.hostWriteGate, "host-preflight-required");
assert.equal(accepted.authorizationGranted, false);
const delegated = evaluate({ ...common, ownerDelegatedTransfer: true });
assert.equal(delegated.decision, "delegated-to-owner");
assert.equal(delegated.authorizationGranted, false);

const auroTechExport = evaluate({
  ...common,
  sourceProject: "Auro-3D",
  targetProject: "auro-tech",
  currentTraceId: "auro3d-trace-002",
  relatedTraceId: "aurotech-trace-002",
  ownerClaim: { ...common.ownerClaim, scope: "approved-public-export" },
  explicitCopyReview: true,
});
assert.equal(auroTechExport.decision, "cross-repo-copy-reviewed");
assert.equal(auroTechExport.authorizationGranted, false);

assert.equal(evaluate({ ...common, ownerClaim: undefined }).decision, "owner-ambiguous-blocked");
assert.equal(evaluate({ ...common, expectedOwnerProject: "print-lab" }).decision, "owner-conflict-blocked");
assert.equal(evaluate({ ...common, ownerClaim: { ...common.ownerClaim, conflicts: ["PROJECT_CONTEXT mismatch"] } }).decision, "owner-conflict-blocked");
assert.equal(evaluate({ ...common, destinationState: "conflicting-hash" }).hostWriteGate, "blocked");
assert.equal(evaluate({ ...common, sourceHash: hash, destinationHash: hash, destinationState: "matching-hash" }).decision, "duplicate-existing-abstain");
assert.equal(evaluate({
  ...common, sourceProject: "auro-tech", targetProject: "auro-tech", relatedTraceId: undefined,
  ownerClaim: { ...common.ownerClaim, ownerProject: "auro-tech", scope: "project-derivative" },
}).decision, "same-owner");
assert.throws(() => evaluate({ ...common, sourceRefs: ["../private.png"] }));
assert.throws(() => evaluate({ ...common, relatedTraceId: undefined }));
assert.throws(() => evaluate({ ...common, relatedTraceId: common.currentTraceId }));

assert.equal(transition({ from: "staged", to: "copied", sourceHash: hash, stagedHash: "b".repeat(64) }).valid, false);
assert.equal(transition({ from: "verified", to: "committed", pointerUpdated: true }).valid, false);
assert.equal(transition({ from: "pointer-updated", to: "committed", pointerUpdated: true }).valid, false);
assert.equal(transition({ from: "pointer-updated", to: "committed", pointerUpdated: true, pointerUpdateReceipt: "receipt:auro-tech:manifest-rev-2" }).valid, true);
assert.equal(transition({ from: "copied", to: "verified", sourceHash: hash, destinationReadbackHash: "b".repeat(64) }).valid, false);
assert.equal(transition({ from: "rollback-needed", to: "staged" }).valid, false, "recovery requires a matching source/staged hash");
assert.equal(transition({ from: "rollback-needed", to: "staged", sourceHash: hash, stagedHash: hash }).valid, true, "recovery may resume from a verified stage");
assert.equal(transition({ from: "staged", to: "aborted" }).valid, true, "incomplete transactions may abort without commit");

console.log("Cross-repo ownership transaction tests PASS");
