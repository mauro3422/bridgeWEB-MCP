import assert from "node:assert/strict";
import { createRequire } from "node:module";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parseSkillFrontmatter, planSkillContextPage, skillContextManifestSchema, structuredSkillIntentSchema } from "../dist/index.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const manifest = JSON.parse(await fs.readFile(path.join(root, "config", "first-party-skills.json"), "utf8"));
const names = manifest.skills.map((skill) => skill.name).sort();
assert.equal(manifest.schemaVersion, 1);
assert.equal(new Set(names).size, names.length, "first-party manifest names must be unique");

const skillRoot = path.join(root, "skills");
const directories = (await fs.readdir(skillRoot, { withFileTypes: true }))
  .filter((entry) => entry.isDirectory())
  .map((entry) => entry.name)
  .sort();
assert.deepEqual(directories, names, "bundled skill directories must exactly match the first-party manifest");

async function filesUnder(directory) {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(entries.map(async (entry) => {
    const location = path.join(directory, entry.name);
    if (entry.isDirectory()) return filesUnder(location);
    return [location];
  }));
  return nested.flat();
}

const expectedPackageFiles = [];
for (const name of names) {
  const skillFile = path.join(skillRoot, name, "SKILL.md");
  const frontmatter = parseSkillFrontmatter(await fs.readFile(skillFile, "utf8"));
  assert.equal(frontmatter.name, name, `frontmatter name must match manifest name for ${name}`);
  const rootText = await fs.readFile(skillFile, "utf8");
  assert.ok(rootText.includes("## Reference map"), `first-party root must map selective references: ${name}`);
  assert.ok(rootText.length < 5000, `first-party root must remain a compact control plane: ${name}`);
  const contextPath = path.join(skillRoot, name, "context-modules.json");
  const context = skillContextManifestSchema.parse(JSON.parse(await fs.readFile(contextPath, "utf8")));
  assert.ok(Array.isArray(context.core?.sections) && context.core.sections.length > 0, `first-party context core missing: ${name}`);
  for (const module of context.modules ?? []) {
    if (!module?.source?.path) continue;
    const referencePath = path.join(skillRoot, name, module.source.path);
    const reference = await fs.readFile(referencePath, "utf8");
    assert.ok(reference.trim().length > 0, `selective reference must be non-empty: ${name}/${module.source.path}`);
  }
  expectedPackageFiles.push(...(await filesUnder(path.join(skillRoot, name))).map((file) => path.relative(root, file).replace(/\\/g, "/")));
}

const maintenanceRoot = path.join(skillRoot, "skill-maintenance-loop");
const maintenanceReferences = (await fs.readdir(path.join(maintenanceRoot, "references")))
  .filter((name) => name.startsWith("friction-") && name.endsWith(".md"));
assert.ok(maintenanceReferences.length >= 10, "maintenance friction catalog must remain semantically partitioned");
for (const name of maintenanceReferences) {
  const chars = (await fs.readFile(path.join(maintenanceRoot, "references", name), "utf8")).length;
  assert.ok(chars < 5000, `maintenance friction module must remain below 5000 characters: ${name} (${chars})`);
}
const warningOnly = await planSkillContextPage({
  skills: [{
    skill: {
      name: "skill-maintenance-loop",
      description: "First-party maintenance regression.",
      source: "mssr-first-party",
      path: path.join(maintenanceRoot, "SKILL.md"),
    },
    obligation: "required",
    routeIndex: 0,
    routeScore: 100,
  }],
  intent: structuredSkillIntentSchema.parse({
    domains: ["skill-system"], actions: ["analyze"], artifacts: ["skill"], needs: [],
    signals: ["warning-observed"], risk: "read-only", ambiguity: "low",
  }),
  stage: "close",
  mode: "selective",
  references: "auto",
  maxContextChars: 14_000,
});
const warningModules = warningOnly.skills[0].contextAssembly.selectedModules;
assert.equal(warningModules.includes("friction-index"), false, "generic warnings are not confirmed frictions");
assert.equal(warningOnly.blocked.length, 0, "generic maintenance warning must fit one bounded page");

const confirmedFriction = await planSkillContextPage({
  skills: [{ skill: { name: "skill-maintenance-loop", description: "friction selection", source: "mssr-first-party", path: path.join(maintenanceRoot, "SKILL.md") }, obligation: "required", routeIndex: 0, routeScore: 100 }],
  intent: structuredSkillIntentSchema.parse({ domains: ["skill-system"], actions: ["document"], artifacts: [], needs: [], signals: ["repeated-friction"], risk: "read-only", ambiguity: "low" }),
  stage: "close", mode: "selective", references: "auto", maxContextChars: 14_000,
});
assert.equal(confirmedFriction.skills[0].contextAssembly.selectedModules.includes("friction-index"), true, "confirmed friction must load the canonical friction index without a code change");
assert.equal(confirmedFriction.blocked.length, 0, "confirmed friction guidance must fit one bounded page");

const v1Guide = "docs/FIRST_PARTY_SKILLS_V1.md";
assert.equal(await fs.stat(path.join(root, v1Guide)).then(() => true, () => false), true, "v1 distribution/migration/evaluation guide is required");

const npmCli = process.env.npm_execpath;
assert.ok(npmCli, "npm must expose npm_execpath while running the package conformance test");
// npm pack runs the root `prepare` lifecycle even with --ignore-scripts. That
// recursively rebuilds this large repository during tests and can exhaust the
// Windows child-process memory budget. Use npm's own Arborist + npm-packlist
// resolver to verify the exact included paths without running package scripts.
const npmRequire = createRequire(npmCli);
const Arborist = npmRequire("@npmcli/arborist");
const npmPacklist = npmRequire("npm-packlist");
const packageTree = await new Arborist({ path: root }).loadActual();
const packedFiles = new Set(await npmPacklist(packageTree));
for (const file of expectedPackageFiles) assert.equal(packedFiles.has(file), true, `npm pack must include ${file}`);
assert.equal(packedFiles.has(v1Guide), true, "npm pack must include the v1 distribution guide");
const packageJson = JSON.parse(await fs.readFile(path.join(root, "package.json"), "utf8"));
assert.equal(packageJson.scripts.postinstall, undefined, "first-party skill installation must remain opt-in");
const fixtureSchema = JSON.parse(await fs.readFile(path.join(root, "config", "skill-routing", "skill-routing-fixtures.schema.json"), "utf8"));
assert.equal(fixtureSchema.properties.cases.items.properties.sources.items.enum.includes("mssr-first-party"), true, "routing fixture schema must accept first-party provenance");

await import("./test-first-party-context-economy.mjs");
console.log("first-party skill package conformance tests passed");
