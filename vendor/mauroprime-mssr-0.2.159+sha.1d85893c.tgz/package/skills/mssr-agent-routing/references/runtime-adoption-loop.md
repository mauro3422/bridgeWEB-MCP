# MCP runtime adoption loop

Read when the host reports that the loaded MCP/server build differs from the
available build, or a representative tool schema still looks older after a
restart or reconnect.

## Ownership and states

- MSSR owns the portable decision sequence and bounded evidence.
- The host owns process lifecycle, restart/reconnect I/O, permissions, and the
  acknowledgment. A provider catalog refresh is not a process restart.
- `current`: `loadedBuild == availableBuild`; verify the affected tool/schema.
- `stale`: both build identities are known and differ; inspect the exact server
  and its host lifecycle capability.
- `restart-unavailable`: no live, authorized host capability targets that
  server. Stop and report the required host action; do not improvise a process
  kill, call another host's restart tool, or repeat a desktop restart.
- `restart-pending`: the host accepted one controlled request; wait for its
  acknowledgment and a fresh connection before checking again.
- `adoption-failed`: an acknowledged restart still reports the old build or
  schema. Stop retries and inspect installation/launcher ownership with the
  host operator.

## Bounded procedure

1. Read the current loaded/available build IDs, health, exact server identity,
   and the affected tool's live schema. Preserve the observed timestamp.
2. If the build is current, verify the specific schema/behavior that was stale
   and finish; do not restart for a catalog-only mismatch.
3. If stale, inspect the live host catalog for a restart/reconnect capability
   that explicitly targets this server. Require fresh availability,
   connectivity, and authorization evidence from the owning host. Tool names
   and schemas remain runtime registry data.
4. For one unchanged `(serverId, loadedBuild, availableBuild)` identity, issue
   at most one authorized planned restart request. Carry its request ID and
   acknowledgment. On timeout or unknown outcome, inspect request status; never
   issue a duplicate request while the first may still be running.
5. After acknowledgment, wait for the host to reconnect, then re-read loaded and
   available builds and the exact affected schema. Declare adoption only when
   the build is current and the behavior/schema is verified.
6. If the host capability is absent, denied, times out ambiguously, or returns
   the old build, stop this recovery loop. Report the loaded/available IDs,
   server identity, request/ack state, failed schema, and exact host owner/action
   needed. A new available-build identity may be investigated as a new change;
   it does not authorize repeating an unresolved request.

Keep only bounded per-trace attempt metadata. It may contain server/build IDs,
request/ack IDs, observations, and the next gate; never raw prompts, secrets,
or private reasoning. A restart request is not proof of process replacement,
and a fresh catalog is not proof that the affected tool works.
