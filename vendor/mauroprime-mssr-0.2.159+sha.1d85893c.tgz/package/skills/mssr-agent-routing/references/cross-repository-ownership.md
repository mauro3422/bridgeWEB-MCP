# Cross-repository ownership

Read before a write, move, save, or publication that may create or update an
artifact owned by a different repository.

1. Identify the requested deliverable and the production phase being changed;
   ownership can differ between research, modeling, animation, integration,
   and publication.
2. Resolve the owner from current project manifests, explicit ownership
   records, and the requested work's established project authority. Cite the
   authority and revision/path in the working summary.
3. If the active project differs from the deliverable owner, state the proposed
   owner and why before the first mutating tool. Ask for clarification when the
   authority is missing or conflicting. Never switch repositories or roots
   silently.
4. Keep the active project as owner for read-only inventory unless evidence
   shows that the requested deliverable belongs elsewhere.
5. Ownership orientation does not grant permission, select tools, or authorize
   cross-repository writes. Follow the owning host's normal safety and mutation
   workflow after the owner is resolved.

For example, creating animation for a character may belong to an animation
project even when the request begins in a modeling project; inspecting that
modeling project's inventory remains read-only work owned by the active
project. Treat this as a routing check, not an automatic transfer.
