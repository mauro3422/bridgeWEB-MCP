# Tooling, contract and scale friction

Use for verified wrapper, schema, closed-vocabulary, routing-pollution,
high-cardinality, telemetry or context-budget failures. Record evidence, owner,
cause, correction and unresolved gate; errors alone do not prove a reusable rule.

## Reusable checks

- **Wrapper false positive:** retry a safe query with a dedicated tool or simpler
  command. Change policy only if its rule is wrong; never weaken a real boundary.
- **Skill discovery disagrees with validation:** parse frontmatter as YAML,
  validate keys/name/folder, install the junction, then inspect host discovery.
  Green local validation plus missing host skill is parser/runtime parity debt.
- **Closed intent vocabulary:** query `skill_route_vocabulary` before editing.
  Map commands to existing semantic values; add a value only for a reusable
  cross-domain distinction. Run the smallest fixture before the suite.
- **Route pollution:** inspect active and deferred skills. Require the matching
  artifact/need and add both exclusion assertions for observed negatives.
- **Large argv:** use stdin pathspecs or bounded manifests; test real high counts
  on Windows instead of extrapolating from a small fixture.
- **Synthetic telemetry:** mark fake tools `__test_`; exclude them from normal
  incident summaries, retaining a separate explicit raw diagnostic mode.
- **Fragile patch:** reread exact content after EOL/duplicate mismatch; use a
  unique exact replacement or line edit. Never widen a failed patch blindly.
- **Noisy repeated verification:** one authoritative gate per layer; summarize
  success and emit cases only on failure or request.

## Confirmed incidents (2026-11-12)

### Invalid context selector stage — resolved

`context-modules.json` used unsupported `maintenance`; schema allows `start`,
`implement`, `verify`, `persist`, `close`, `resume`. Loader rejected the
manifest and fell back to full `SKILL.md`. Changed to a valid selector and
confirmed `manifestStatus=loaded` plus module selection.

### Owner module missed default context budget — resolved

The 1,880-byte `mssr-module-handoff-capability-escalation` matched but exceeded
the default budget; trimming it to 1,007 bytes still left zero capacity because
selected core was 6,511 bytes. An explicit 14,000-char test loaded it. MSSR
compacted the release-state core to 356 and selector to 827 bytes: 4,767 core +
827 module, 406 remaining under the unchanged 6,000 default.

### Provider tool differs from host connector — adoption pending

Bambu listed 47 provider tools including `bambu_slice_headless_save`; dedicated
Bridge connector calls returned `Unknown tool`, while generic
`bambu_mcp_tool_call` used provider-owned name/schema. Direct Codex MCP sliced an
isolated QA copy. Inspect host and provider catalogs separately, fetch the
provider schema, then use the authorized direct route or permitted proxy. The
Bridge fake-provider contract test passed; live Bridge adoption is unverified.

### Domain intent polluted unrelated routes — source fix verified

Bambu QA activated Steam, audio, visual-reference and Bridge skills. A first
fixture edit hid the pollution; live bootstrap exposed it. Route gates now
require Steam artifact, transcription actions, conjunctive visual QA for visual
reference work, and meaningful Bridge collaboration signals. Bambu fixtures
assert active and deferred exclusions; 294 routing fixtures pass.

### Bambu schema/isolation rejection — recovered; source freshness unresolved

An unsupported timeout field and a slice targeting the original model were
rejected before writes. Provider schema plus QA-only path rule required a unique
copy beneath `qa/`; no guard was weakened. Later readback saw the original saved
at 01:48 ART after the 01:35 slice with a different SHA. Preserve both files;
archived G-code applies only to the earlier snapshot until reconciled.

### Friction-index phase and context selection — corrected

Unsupported phase `maintenance` caused fallback; selecting every `close` also
loaded the index on nominal reviews and exceeded context budget. Index now uses
specific signals (`repeated-friction`, `manual-workaround`, `recovery-needed`,
`skill-gap`); generic warnings remain incident-ledger evidence. Regression
checks require a confirmed friction to load the index, while nominal review
stays within the 7,000-char economy fixture.

### Source changed after QA slice — unresolved

The QA copy was 26,555 bytes, SHA `0c2a59e4…`; later original readback was
27,104 bytes, SHA `b3b40a9e…`, timestamp 01:48 ART. Cause unknown. Do not restore
or overwrite either copy; do not call archived G-code current-source evidence.

### Trace checkpoint input/order — recovered

Codex-local `mssr_trace_record` rejects summaries over 300 characters; an
`outcome` also fails with `mssr-trace-missing` before a trace has its first
checkpoint. No rejected call persisted. Start each trace with a concise
`progress` checkpoint, then write the bounded outcome.
