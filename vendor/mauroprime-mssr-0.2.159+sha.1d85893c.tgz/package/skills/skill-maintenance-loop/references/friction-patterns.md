# Reusable maintenance friction patterns

This index routes recurring failures to the smallest durable reference. Read only the module whose selectors match the active phase and structured intent.

## Recording rule

Every confirmed non-nominal friction found during a task must be recorded in the smallest applicable reference below, even when no implementation change follows. Include date, canonical owner, observable reproduction/evidence, cause (`demonstrated` or `unresolved`), correction, and remaining gate. Add an entry to the owning system incident ledger as well when shared routing, skill activation, MCP contract, or host behavior failed. Keep exact project facts in that project's own authority; do not copy raw prompts, transcripts, credentials, or private reasoning into global references. If an existing entry already covers the pattern, append bounded new evidence there instead of creating a duplicate.

- `friction-integration-release.md`: branches, generated artifacts, process lifecycle, versioning and release.
- `friction-skill-runtime-routing.md`: skill installation, runtime discovery and routing composition.
- `friction-tooling-contract-scale.md`: wrappers, schemas, routing vocabulary, scale limits, telemetry and patch mechanics.
- `friction-verification-readback.md`: readback, live-effect verification and mutation boundaries.
- `friction-visual-payload-integrity.md`: decoded visual evidence, measured bytes and master/preview lineage.
- `friction-learning-decision-boundary.md`: observe-only learning decisions and guarded promotion.
- `friction-hierarchical-mutation-identity.md`: exact hierarchical targets, protected invariants and bounded recovery.
- `friction-cross-project-authority.md`: catalog/provider ownership, drift and approval evidence.
- `friction-close-checklist.md`: concise release/maintenance closure gate.

These patterns came from real cross-repository maintenance and should be recognized without overfitting to one project. They are evidence, never authority for automatic instruction mutation.
