---
name: skill-maintenance-loop
description: "Mantiene el loop completo de capacidades de MauroPrime: audita fricción y aprendizajes, identifica la fuente de verdad, corrige o crea skills, routing, fixtures, scripts, tools, guías y documentación, verifica los repositorios y decide cuándo otra aplicación o contexto debe continuar. Úsala al cerrar trabajo especializado y también cuando aparezcan fricción repetida, workaround manual, skill-gap, capability-gap, routing incorrecto, outputs generados stale, lifecycle defectuoso o una regla reutilizable faltante."
---

# Skill Maintenance Loop

Turn evidence into reusable, cross-project prevention.

## Core loop

Record every confirmed friction in its smallest canonical reference with
evidence, owner, known/unknown cause, correction, and next gate. Add a system
incident for shared routing, skill, or tool failures, even without code changes.
Never store raw prompts, transcripts, secrets, or private reasoning. Resolve the
owner, reproduce the case and a nominal neighbor, choose the smallest durable
fix, then verify source, runtime, experience, persistence, and transport.
Classify as project, skill, route, tool/guide, handoff, skill candidate, or
insufficient evidence.

Telemetry is evidence, never authority. Learning remains `observe-only`
(`routingInfluence=false`) until dataset, replay/holdout, calibration, shadow,
feature-flag, and rollback evidence passes human review.

Scale review to the finding; if nothing reusable changes, record `reviewed-none`.
Put concrete deferred debt in the project backlog with evidence, impact, reason,
next gate, and closure condition; keep suspicion `review-needed`. Audits need no
proposal, publication, restart, or new skill; load only
the candidate owner's procedure.

## Reference map

Use [learning review](references/learning-review-promotion.md) for proposals or
[ownership](references/system-map.md) when the owner is unclear. Load only the
indexed owner reference for audit, routing, provider, fixtures, publication,
incident/handoff, friction, memory, evolution, learning, architecture, debt,
automation, or context modularization. Paths belong in `context-modules.json`.

## Boundaries and exit

Do not create a skill when its owner only needs a local document, module, test,
script, or correction. Do not promote from frequency alone or make hidden
background changes. Report pattern, evidence, classification, owner, change or
proposal, verification, persistence, dimensions, and remaining limitation. If
none is reusable, report `Sin cambio de skill`.
