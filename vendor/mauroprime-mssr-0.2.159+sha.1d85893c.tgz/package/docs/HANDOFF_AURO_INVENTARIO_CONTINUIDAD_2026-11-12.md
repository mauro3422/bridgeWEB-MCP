# Handoff MSSR — inventario y continuidad de proyectos creativos

**Fecha:** 2026-11-12. **Estado:** evaluación MSSR completada 2026-11-13; no se justifica un motor de inventario paralelo. La recuperación observable por host/proyecto sigue pendiente. **Propietario:** MSSR para contratos portables y selección; cada proyecto conserva la propiedad de sus datos, archivos, decisiones y pendientes. No equivale a una orden de publicar, mover o borrar datos.

## Necesidad observada

Mauro quiere que, al retomar un proyecto o terminar una iteración, un agente pueda recuperar qué hay, cuál es la fuente vigente, cómo se llegó a las variantes, qué fue aceptado o rechazado, qué depende de qué, qué se limpió y qué conviene hacer después. Quiere evitar pedir repetidamente inventarios, handoffs y recordatorios; en proyectos visuales necesita además comprender relaciones entre láminas conceptuales, fondos reconstruidos, SVG, máscaras, logos y aplicaciones. No solicita guardar la conversación completa ni un sistema nuevo por defecto.

## Evidencia del caso AURO TECH

- `D:/Dev/auro-tech/INVENTARIO_Y_CONTINUIDAD.md`: inventario de marca, seis variantes de símbolo, logo completo, láminas 04–10/21, fondos, continuidad y pasos siguientes. Incluye fuentes y límites de revisión.
- `D:/Dev/auro-tech/docs/inventarios/auro-tech-20261112-actualizado.json`: snapshot fechado de 289 archivos, 41 SVG analizados como XML; hashes, tamaños y referencias `href` locales. El snapshot no demuestra vigencia semántica ni fidelidad visual, y envejece al cambiar archivos.
- `D:/Dev/auro-tech/.mssr/knowledge/design/auro-propiedades-visuales.md`: preferencias y estado del proyecto, ya indexado por su `project-context.json`. La lámina 10 no se aprobó; Mauro luego eligió la iteración posterior como fondo principal para actualizar todas las piezas anteriores. Esa producción todavía no se ejecutó; no inferir que los archivos existentes ya cambiaron.
- `D:/Dev/auro-tech/PENDIENTES.md`: checklist humano y próximos pasos. `.mssr/PROJECT_STATE.md` conserva resumen y referencias; no duplicar toda la lista en MSSR.
- `D:/Dev/auro-tech-limpieza/fondo-svg-20261112/`: 748 iteraciones y carpetas separadas, movidas y recuperables, con manifiesto. No suponer que el archivo externo será permanente ni que todos los elementos son basura.
- AURO Motions ya copió y verificó parte del piloto de impresora; su `D:/Dev/auro-motions/HANDOFF.md` y `PENDIENTES.md` son dueños del estado de animación. Otros proyectos como AURO TECH Web y AURO Consultorio tienen autoridades separadas.
- Fricción concreta: tras un chat largo se repitieron lecturas/explicaciones; el checklist y el estado seguían diciendo que faltaba trasladar todo a AURO Motions aunque su handoff ya describía una importación parcial. Se corrigió en AURO TECH al revisar la fuente del dueño. El histórico de exploración contenía cientos de rutas retiradas de la carpeta activa; se conservó aparte y se reescribió un índice conciso. Las láminas tienen cuatro propuestas cada una, pero el lenguaje informal «4x4» puede confundirse con 16 imágenes.
- Historia revisada: mensajes visibles del chat actual y tramo disponible de «Revisar handoff del logo D2»; no se afirma cobertura completa de chats anteriores.

## Revisar capacidades existentes primero

1. `.mssr/knowledge/state/mssr-pattern-visual-identity-handoff-20261111.md`: propuesta ya revisada e implementada parcialmente para recuperación selectiva de propiedades visuales. No duplicarla.
2. `.mssr/knowledge/state/mssr-project-checklist-handoff-20261111.md`, Project Context / Context Plane, Situation Model, freshness, Librarian, routing, `skill-maintenance-loop` y `mssr-module-handoff`: comparar contratos y adopción real por host antes de proponer otra pieza.
3. `docs/CROSS_REPO_OWNERSHIP_TRANSACTION_HANDOFF_2026-11-12.md` y módulo homónimo: cada repo es dueño de su conocimiento; código portable no significa que un guard esté adoptado por todos los hosts.
4. El repositorio MSSR ya tenía trabajo concurrente y cambios locales al redactar esto. No sobrescribirlos, no modificar archivos compartidos sin revisar estado actual y diff, y no asumir una versión/runtime a partir de este documento.

## Evaluación solicitada al próximo agente

- Determinar si lo pedido se cubre con el contexto selectivo, catálogo/snapshot local, checklist y handoff existentes, o si falta una capacidad pequeña y reutilizable. Proponer el owner correcto; no crear una segunda memoria ni un índice global de los contenidos privados por defecto.
- Explorar un contrato acotado para **inventario y continuidad**: identidad/ruta/revisión de fuentes, rol (oficial, referencia, concepto, derivado, fuente editable, export, histórico o apartado), estado/aceptación, procedencia y relaciones; dependencias y hash cuando procedan; tareas humanas y límites; enlace al owner y a evidencia visual realmente inspeccionada.
- Detectar referencias movidas, snapshot desactualizado, contradicciones entre proyectos, divergencia entre decisión aceptada e hipótesis, y patrones de repetición, como advertencias con dueño y evidencia. Ninguna telemetría o similitud autoriza editar `AGENTS.md`, archivos, pendientes o preferencias sin revisión del host y las instrucciones del usuario.
- Diseñar selección por intent/fase, con resúmenes pequeños y expansión justificada. Tratar una solicitud breve de continuación con contexto suficiente y conservar límites de privacidad; no registrar prompts, transcripciones completas ni razonamiento privado.
- Contemplar recuperación y verificación antes de limpieza: archivos protegidos, dependencias, referencias, manifiesto, hashes, archivo reversible y evidencia visual; distinguir descarte aprobado de experimento/histórico sin reemplazo probado.
- Probar casos positivos y negativos: inventario solicitado vs. edición ordinaria; lámina de cuatro propuestas vs. cuatro por cuatro; concepto IA vs. foto real; símbolo vs. logo completo; cambio de fecha/hash vs. obsolescencia semántica; proyecto hermano actualizado vs. resumen local obsoleto; referencia archivada vs. eliminada; aprobación provisional vs. identidad oficial; operación entre repos sin owner claro; host no adoptado y presupuesto de contexto.
- Entregar propuesta o implementación según el encargo vigente de Mauro y pruebas correspondientes, con recuperación, idempotencia, revisión de concurrencia y estatus separado de documentación, código, tests, runtime y adopción por host. Este handoff por sí solo no instala una skill ni modifica el routing.

## Resultado de evaluación MSSR — 2026-11-13

Se comparó la necesidad con los contratos actuales. No apareció una brecha portable que justifique un `Inventory Engine` nuevo:

- `src/document-surface.ts` genera revisiones SHA-256 y rangos exactos; los hosts validan el readback contra los bytes observados.
- `src/project-context-librarian.ts`, `src/librarian-retrieval.ts` y `src/librarian-contract.ts` recuperan candidatos y handles sobre fuentes que el caller aporta; no escanean el repositorio ni deciden si una imagen o variante es oficial.
- `src/project-document-references.ts` planifica/valida registro explícito con hashes y precondiciones; `reference-on-miss` solo devuelve candidatos. Document Freshness revisa refs y revisiones declaradas.
- `src/evidence-atom.ts`, `src/situation-claims.ts`, `src/semantic-relations.ts` y `src/semantic-consistency.ts` ya representan owner, autoridad, frescura, vigencia histórica/superada, linaje, relaciones declaradas y contradicciones deterministas. `src/project-data-requirements.ts` clasifica campos requeridos, fuente admisible y evidencia fresca/obsoleta.
- `src/cross-repo-ownership-transaction.ts` valida propiedad y transiciones declaradas, sin mover assets ni sustituir permisos del host.

Se ejecutaron y pasaron las pruebas focalizadas: `test:document-surface`, `test:librarian-contract`, `test:project-document-references`, `test:document-freshness`, `test:semantic-consistency`, `test:cross-repo-ownership` y `test:project-control-contract`. Verifican los componentes existentes por separado; **no** demuestran un ciclo integrado de inventario AURO a través de un host.

**Decisión:** reutilizar esta composición y diferir código MSSR adicional. El manifiesto/inventario AURO ya aportaba rutas, hashes y referencias; las decisiones de aceptación, rol visual y dependencias semánticas siguen en AURO TECH. El host debe descubrir/adquirir las fuentes autorizadas y actualizar sus observaciones; no se inspeccionaron ni modificaron repos AURO en esta evaluación.

**Condición para reabrir código MSSR:** aportar un repro con snapshots estructurados anteriores y actuales ya observados por el host donde no se puedan clasificar de forma determinista los cambios por hash, faltantes, movimientos explícitos, conflictos de owner o dependencias faltantes usando EvidenceAtoms, Situation Model y CrossRepoOwnershipTransaction. Si aparece, diseñar el evaluador candidate-only descrito arriba con fixture positivo/negativo, idempotencia y recuperación; nunca inferir aceptación visual, borrado o autorización.

## Verificación y recuperación del handoff

Este documento permanece en `D:/Dev/mssr/docs/`; su evaluación no modifica routing, esquema, versión, AGENTS ni autoridades de AURO TECH. AURO TECH enlaza a este documento desde su inventario. Si un repro futuro justifica persistir conocimiento de proyecto, se actualizará sólo en el owner correspondiente, con revisión de fuente, selección y readback; los handoffs bajo `.mssr/knowledge/` se registran en el índice en la misma tarea.
