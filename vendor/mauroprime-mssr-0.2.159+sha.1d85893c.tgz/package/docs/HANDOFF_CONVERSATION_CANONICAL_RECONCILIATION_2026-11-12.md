# Handoff — reconciliación de conversaciones y estado canónico (12/11/2026)

Estado: **propuesta documentada; implementación no autorizada ni verificada**.
Owner portable: MSSR. Owner de acceso a conversaciones, evidencia host y escritura autorizada: Bridge/ChatGPT host. Índice federado: Project Observer `OBS-SYS-06`.
Trace de preparación: `mssr-20261112071817-8d4dadaf-01e`.

## Motivación y evidencia
El usuario pide que el diario matutino revise conversaciones del día anterior **realmente accesibles**, identifique compromisos, decisiones, fricciones y propuestas, y contraste con el estado vivo de cada repositorio. Detectar casos donde un chat dice que se acordó/implementó algo pero MSSR, Bridge, una skill o la memoria canónica no muestran evidencia de adopción. Distinguir falta de acceso, falta de registro, contradicción real y deuda diferida. No atribuir a todos los chats una capacidad de lectura que el host no haya demostrado.

Ejemplos existentes para inspección: Project Observer `OBS-SYS-04` (selector transversal no demostrado), `OBS-SYS-05` (guard pre-write de cambio de owner no demostrado); MSSR `CrossRepoOwnershipTransaction v1` está implementado como evaluador portable pero Bridge debe demostrar adopción operacional. Skill `mssr-module-handoff` consta en source 0.2.143, pero catálogo live de Codex aún no la reflejaba al último estado leído. No interpretar eso como bug del contrato sin comprobar host/restart.

## Reutilizar antes de ampliar
Auditar Context Plane, Project Context, owner-aware maintenance classifier, Document Freshness, skill-maintenance-loop, Notice Plane, `mssr-module-handoff`, guía Bridge `cross-project-context-inventory` y `CrossRepoOwnershipTransaction`. MSSR propone/valida; host autorizado observa y ejecuta; Project Observer indexa referencias/prioridades; cada repo dueño conserva hechos y documentación canónica. No crear router, skill, BD ni módulo paralelo sin gap reproducible.

## Contrato candidato de hallazgo (no esquema aprobado)
`findingId`, `observedAt`, `conversationRef` opcional y minimizada, `claimType` (decisión/compromiso/reporte/hipótesis), `owner`, `canonicalEvidenceRef`, `freshness`, `comparisonStatus` (coincide/pendiente-evidencia/contradicción-confirmada/no-accesible/diferido/resuelto), `impact`, `priority`, `nextGate`, `handoffRef`, `verifiedAt`. Guardar resumen mínimo, **nunca transcripciones completas, prompts, datos sensibles o secretos**. Un chat no es prueba de ejecución; un archivo no mencionado no es prueba de incumplimiento.

## Pruebas y criterios de aceptación para agente especializado
1. Caso positivo: compromiso verificable en chat y evidencia contradictoria en owner actual; registrar una sola brecha con citas/fechas y handoff al owner correcto.
2. Caso negativo: conversación sin acceso, dato stale, compromiso aplazado o ausencia de registro; NO denunciar incumplimiento ni inventar owner.
3. Caso positivo de fase transversal: AURO 3D fotos → AURO Motions composición → AURO TECH publicación; identificar cambio de fase/owner sin mover originales ni conceder permisos.
4. Caso negativo: un chat menciona varios proyectos sin transferencia real; no duplicar handoffs ni activar skills innecesarias.
5. Reejecución: mismo hallazgo mantiene ID y se actualiza sin duplicarse; cierre requiere readback/aceptación del owner y evidencia observable.
6. Capability check: confirmar acceso efectivo a conversaciones del día anterior; si no existe, declarar cobertura parcial y usar sólo conversaciones disponibles.

## Prioridad
**Diferida / investigación cuando haya espacio**. No bloquear trabajo comercial ni exigir resolver outcome/closure MSSR por mera antigüedad. La automatización del diario ya tiene permiso documental limitado, no de código ni configuración.

## Caso de campo: Tollerance-Test del 05/11 — dato guardado, contexto omitido

La prueba física de encastre sí estaba documentada en el laboratorio (`BITACORA.md` 687–693 y `PROGRESO.md` 57) y un nuevo chat recomendó repetirla. No se perdieron los bytes; faltó recuperación/selectibilidad temporal o una consulta host a las fuentes finales. El laboratorio ya tiene módulo selectivo indexado y consulta positiva/negativa comprobada. Leer [diagnóstico y criterios de adopción](INCIDENTE-CONTINUIDAD-TOLLERANCE-TEST-2026-11-12.md) antes de diseñar nuevos recordatorios, editar AGENTS.md global o atribuir un defecto al motor MSSR.

## Caso de campo: AURO 3D — checklist federada obsoleta (13/11/2026)

**ID:** `OBS-SYS-08/AURO-3D-20261113`. **Detectado y actualizado:** 13/11/2026, diario y revisión por Bridge. **Prioridad:** corregir de inmediato la orientación documental. Evaluación del aviso en mantenimiento, salvo recurrencia que desvíe trabajo activo. **Estado:** contradicción verificada. Corrección de la proyección a cargo de Project Observer. Detección y aviso automáticos pendientes de validación.

- **Hecho e impacto:** `project-observer/PENDIENTES.md` (OB-01/02/03) aún ofrecía vaso/llavero como foco y sus punteros `HANDOFF-MSSR.md` y `.mssr/PROJECT_STATE.md` repetían esa orientación. El plan operativo AURO 3D (12–13/11) y el handoff de pausa del 12/11 documentan pausa para AFA/Boca/llaveros, organizador como consulta avanzada y prioridad comercial, y casco V3 como pedido confirmado con modelado y validación pendientes. Así, un agente podía reactivar una tarea pausada o confundir confirmación de un encargo con prioridad de toda la cartera. Fuentes del owner: `Auro-3D/docs/PLAN-OPERATIVO.md`, `Auro-3D/docs/HANDOFF-PAUSA-PRODUCTOS-ORGANIZADOR-MAQUILLAJE-2026-11-12.md`, `Auro-3D/pedidos/soporte-casco-v3/FICHA.md`. Referencia federada: `project-observer/PENDIENTES.md`, OBS-SYS-06/07/08. Traza MSSR: `mssr-20261113174058-02b4faeb-fbd`.
- **Hipótesis por verificar:** una fase de continuación puede recuperar la checklist y tratar su foco como vigente sin comparar el estado semántico de la tarea contra el owner. El caso comprueba la deriva documental. Queda por medir si el host entrega hoy un aviso útil y si falta alguna capacidad portable. Revisar checklist de proyecto, Document Freshness, Project Knowledge Maintenance, Situation Model y Notice Plane antes de proponer otro módulo.
- **Responsabilidades y acción propuesta:** Project Observer mantiene la referencia federada. AURO 3D posee prioridad y estado de producto. MSSR evalúa si puede emitir un aviso consultivo de revisión que identifique tarea y owner, fuente/fecha, contradicción y siguiente paso (recargar autoridad antes de orientar trabajo). Bridge/host verifica evidencia y entrega del aviso. El diario reporta y actualiza documentación/handoff con permiso, ID y readback cuando hay una discrepancia material.
- **Aceptación:** (1) Reproducir OB-01 vigente frente a pausa explícita más reciente del owner y verificar que el agente reciba un aviso antes de recomendar retomar. (2) Con una mera diferencia de fecha, evidencia ausente, diferencia de alcance o un pedido confirmado junto a otra prioridad comercial, no declarar contradicción. (3) Dos revisiones de la misma brecha producen un solo hallazgo. La corrección con relectura permite cerrar la deriva documental, independientemente de que el aviso se haya desplegado. (4) Registrar versión/capacidad del host, evidencia de entrega y resultado; la evaluación y el aviso no mutan fuentes ni conceden autoridad.

**Para retomar:** cargar el contexto MSSR de `D:\Dev\mssr`, recuperar OBS-SYS-08 y contrastar este caso con las capacidades existentes. Identificar el primer punto de pérdida de evidencia entre recuperación, evaluación y entrega del aviso. Dejar resultados y referencias verificables al owner que corresponda.
