# MSSR — Handoff de propiedad y transacciones entre repositorios (12/11/2026)

**Estado actualizado 2026-11-14:** CrossRepoOwnershipTransaction v1 está presente en el MSSR 0.2.147 vendorizado por Bridge 0.6.188 y fue probado en aislamiento junto con el guardado host. MSSR 0.2.158 pasó el release gate local; el último readback Codex MCP sigue en 0.2.157 y su adopción queda abierta. Las trazas MSSR y Bridge siguen separadas. El handoff completo, los límites de la prueba y la decisión sobre el pin están en “Bridge 0.6.188: paquete MSSR instalado y prueba aislada” abajo; no se modificaron datos comerciales ni el panel real.

## Reconciliación MSSR — 2026-11-13 (readback posterior al reinicio)

El contrato portable, validador de transiciones y fixtures de conflicto permanecen en MSSR 0.2.157 y pasan `npm run verify` / `npm run release:gate`. Tras reiniciar Codex, `skill_bootstrap` leyó loaded=available `mssr-build:sha256:5fe4a5e2897644c8` (`current`) y el catálogo expuso las herramientas actuales. Una prueba live sintética con propietario esperado distinto al declarado devolvió `owner-conflict-blocked`, `hostWriteGate=blocked` y `authorizationGranted=false`. El movimiento del estado indexado conserva el mismo ID y selectores en `.mssr/project-context.json`; el loader seleccionó el módulo desde `.mssr/knowledge/state/cross-repo-ownership-implementation-handoff.md`.

Bridge conserva la responsabilidad operacional de pre-write guard, journal/receipt, replay idempotente, readback, compensación y recuperación; su agente debe aportar su propia revisión de checkout/runtime. Esta actualización no modifica Bridge ni demuestra enforcement en vivo. La orientación de handoff antes de cualquier escritura sigue siendo distinta del guard transaccional, y las decisiones de propiedad continúan separadas por owner.

## Bridge 0.6.188: paquete MSSR instalado y prueba aislada — 2026-11-14

**Versión instalada y contrato:** Bridge fija @mauroprime/mssr 0.2.147 desde vendor/mauroprime-mssr-0.2.147+sha.007951a2.tgz, SHA-256 007951A27E409F4F3B0CA872FDE54294F4DBB96E296D40FA85AA413B0E9295D3. El paquete instalado exporta mssr_cross_repo_ownership_evaluate, mssr_cross_repo_transaction_transition_validate y sus funciones puras; el contrato portable se introdujo en MSSR 0.2.142. Por lo tanto, el contrato requerido ya está instalado y no falta un paquete para probar el pre-write gate. MSSR 0.2.158 es el candidato local más nuevo y pasó npm run verify/release:gate (receipt en .mssr/PROJECT_STATE.md); el registro público devuelve 404 y no se publicó a npm.

**Prueba aislada:** Bridge 0.6.188 pasó scripts/.test-mssr-lifecycle-host-adoption.debug-local.mjs con el vendor 0.2.147. El archivo conserva las aserciones del test canónico y agrega solo logs de inicio/fin por llamada. El caso simula D:\Dev\Auro-3D como dueño comercial y D:\Dev\auro-3d-web como dueño del panel, con trazas separadas. Verifica que las escrituras no revisadas se bloqueen antes del handler y no creen archivos; la transferencia dedicada valida hashes, journal, readback, actualización de puntero, commit y recuperación idempotente. La misma regresión verifica avisos de preflight en Notice Plane, historial/deduplicación, entrega al siguiente bootstrap compatible, aislamiento de owner/workflow, silencio para una operación sana y executed=false. El fixture aislado no toca datos de producción.

**traceId nulo:** se reprodujeron dos casos acotados: sin ruta compatible, Bridge responde traceId=null y conserva el bloqueo; con candidatos persistidos ambiguos, también se abstiene y correlaciona el aviso únicamente con owner y workflow observados. Esto no prueba la causa exacta del rechazo histórico original.

**Alineación opcional de versiones:** 0.2.147 ya satisface el contrato cross-repo, por lo que Bridge no necesita actualizar su vendor para este incidente. Si más adelante se decide alinear con 0.2.158, crear el tarball desde la fuente verificada, comparar SHA-256 contra el receipt, actualizar el path vendor y package-lock de Bridge, publicar una versión de Bridge y repetir integración/reinicio/readback. No sustituir el pin por un paquete de registry que hoy no existe.

**Runtime observado por separado:** Bridge 0.6.188 PID 27836, boot 7fcaceaf-6275-42f0-8bea-303d2de23b12; los readiness locales y del túnel respondieron HTTP 200, sin reinicio pendiente. El readback de 04:47Z tuvo 8 sesiones activas, workers de dashboard inactivos, 105 stalls acumulados desde el boot (máximo 11,303 ms; último 269 ms a 04:47:31Z) y 2 errores de cliente, el último a 03:14Z. Son métricas de runtime, sin causa atribuida; no se reinició mientras había sesiones activas.
## Incidente que motiva el módulo

- El usuario ya había separado `D:\Dev\impresion-3d-lab` (curso/pruebas), `D:\Dev\Auro-3D` (venta, inventario y fotos de productos), `D:\Dev\auro-tech` (branding/marketing transversal) y `D:\Dev\bridge-mcp` (transporte/ejecución).
- Al retomar edición de seis fotos de compras Flexi 11/11 y su composición, el agente continuó en `impresion-3d-lab` por historial de conversación, creó allí guías/manifest/handoff y llegó a tratar esa ruta como propietario. **Ya existían seis fotos originales y manifiesto canónico en `Auro-3D\compras\flexi\evidencias\2026-11-11`**, junto con inventario comercial. La escritura fue técnicamente válida pero semánticamente ubicada en el dueño equivocado.
- Se detectó el conflicto solo tras corrección expresa del usuario. Se preservaron los originales, se copiaron/hash-verificaron baseline y recorte a `Auro-3D\marketing\fotoproductos\compra-flexi-2026-11-11` y se creó `HANDOFF-MSSR.md` comercial. El laboratorio sigue teniendo documentos/copia histórica; no borrarlos automáticamente. AURO TECH consume solo una **exportación aprobada**, no fuentes privadas.
- Este incidente no prueba ausencia de Project Context, Situation Model, context-modules o skill routing. Prueba una **brecha en la selección del dueño antes del primer write y en el handoff transaccional cross-repo**. No convertirlo en permisión implícita ni atribuirlo a falta de una tool de guardar imágenes.

## Componentes ya existentes: reutilizar, NO duplicar

1. **Project Context selectivo**: `.mssr/PROJECT_CONTEXT.md`, `PROJECT_MEMORY.md`, `PROJECT_STATE.md`, manifest `project-context.json`, módulos `context/memory/state/directive` y selección por intención/fase. `requiredWhen.mutation` puede activar una directiva de mutación en un repositorio, pero no deduce la titularidad de un recurso entre repositorios.
2. **Skill context expansion**: `context-modules.json` por skill, contexto mínimo+referencias selectivas/paginadas+presupuesto; no cargar todos los handoffs y módulos permanentemente ni elevar presupuestos. No existe motivo para crear otro motor de memoria paralela.
3. **Trace lifecycle integrity**: una traza conocida jamás migra de proyecto/workflow. El destino requiere una traza propia/delegada; la relación cross-repo es evidencia acotada, NO transferencia de identidad de la traza.
4. **Situation Model / R4 / C2c**: compara claims explícitos, autoridad y temporalidad, no interpreta automáticamente texto libre ni transforma evidencias en permiso de escritura. Puede **consumir** una claim declarada `asset-owner`, no inventarla.
5. **MauroPrime Bridge**: puede observar archivos, hash, manifest, Git, copies y persistencia. Solo Bridge/host puede implementar I/O, staging, lock/rollback y transacción física. MSSR solo contrato/plan/diagnóstico portable y advisory.
6. **Asset libraries/skills existentes**: reutilizar `cross-project-asset-library` cuando esté presente y `mauroprime-bridge-collaboration`; no crear otra skill de fotografía por este motivo. Una skill **cross-project-ownership-handoff** solo si auditoría de catálogo muestra objetivo/gate verdaderamente independiente.

## Propuesta: CrossRepoOwnershipTransaction v1

Una operación que lee en proyecto A y crea/actualiza derivado en proyecto B declara:
- `transactionId` estable/idempotente y `intent` estructurado con `sourceProject`, `targetProject`, `currentTraceId`, `relatedTraceId` (si está disponible), `artifactKind`, `operation`, `expectedOwnerProject`, `sourceRefs` y `targetRefs`.
- Evidencias normalizadas **host-observed**, no inventadas: `canonicalOwnerClaim` con `ownerProject`, `authoritySource` (AGENTS/Project Context/manifest/usuario), `authorityRevision/hash`, `scope` (raw-evidence, commercial-work-asset, approved-public-export), `observedAt`, `confidenceKind` (declared/observed/unknown), `conflicts[]`.
- **Decision pura/advisory MSSR:** `same-owner`, `delegated-to-owner`, `cross-repo-copy-reviewed`, `owner-ambiguous-blocked`, `owner-conflict-blocked`, `duplicate-existing-abstain`. El decision object proporciona `nextGate`, `requiredEvidence`, `reasonCodes`, `relatedProjectRefs`, pero NO hace write ni autoriza permisos. La ausencia de evidencia debe abstenerse.
- **Transacción host por pasos:** `discovered -> owner-resolved -> proposed -> staged -> copied -> verified -> pointer-updated -> committed -> closed`. Estados alternativos `blocked`/`aborted`/`rollback-needed`. El host debe mantener journal durable, hash esperado/final, destino y evidencia de readback. El pointer/handoff de quien consume solo cambia después de validación de archivos de destino; evitar swaps sin verificación.
- **Preservación de fuentes:** `copy+verify+link` por defecto, no mover ni borrar por heurística. Si ya hay archivo idéntico en destino (hash), reutilizarlo, declarar `deduplicated` y no modificar timestamps por gusto. Diferente hash en destino = conflicto, nunca overwrite silencioso.
- **Cambios en varias autoridades**: no existe commit físico ACID entre FS y Git de varios repos; hablar de protocolo de **compensación y reconciliación**, no de 2PC atómico real. `pending` explícito si copia ok pero handoff no actualizado; nunca declarar operación completa al crear solo una carpeta.
- **Historia y memoria:** `PROJECT_CONTEXT` conserva roles estables, `PROJECT_MEMORY` decisión de ownership, `PROJECT_STATE` propietario actual, progreso y pendientes, `.mssr/runtime/` receipts/journal reconstruibles; skill guía procedural. Los módulos son seleccionados por intents y artefactos, no propagados por copia de texto entre todas las `.mssr`.

## Detección antes de escribir — gates propuestos

- Trigger **estructurado**: `risk!=read-only` y `artifacts` incluye `asset/project/document` y la operación involucra `sourceProject != targetProject`, `needs=[cross-agent]`, o handoff/copy/move de recursos. NO activar por una consulta general a varios proyectos ni por una foto sin destino.
- Obtener evidencia de owner explícita de las raíces candidatas antes de materializar una ruta de trabajo. Si la selección de repo proviene solo del chat o del cwd, proyectar `owner-ambiguous`; preguntar o inspeccionar, **sin crear manifest/handoff propietario en el repo de origen**.
- **Extensión propuesta: aviso de owner de tarea/fase antes de elegir herramienta.** El contrato actual cubre operaciones de assets entre repos, pero no está demostrada la entrega de una advertencia visible cuando el entregable o la fase especializada pertenecen a otro proyecto y todavía no hay una copia/escritura. Analizar si el host puede comparar el intent estructurado con roles declarados en `AGENTS.md` / `.mssr/` y usar el índice selectivo de Project Observer solo para descubrir relaciones. El aviso debe nombrar proyecto actual, owner propuesto, autoridad/revisión que lo respalda, motivo y próximo paso; no cambiar de proyecto automáticamente. Claims ausentes/conflictivas quedan como revisión, y una consulta read-only no debe bloquearse. No crear otro módulo/router hasta probar que el módulo de ownership y el flujo existente de Context Messages/Notice no bastan. Este aviso de orientación es distinto del preflight transaccional obligatorio antes de una mutación cross-repo.
- Si la misma foto tiene `commercial raw evidence` en AURO 3D y una copia educativa, AURO 3D manda como dueño de marketing; esa copia educativa es `source/history`, no autoridad comercial. Un proyecto puede ser **publisher/consumer** sin ser owner del source.
- Tras comprobar propietario, ejecutar bootstrap en la **raíz dueña**, con traza nueva y referencia a evidence/handoff de la traza anterior; mantener tracers cross-project aislados.
- Proyectar `review-due` si cambios del handoff/owner rompen la relación de archivos; jamás auto-reescribir contexto por notificación de drift.

## Fixtures/aceptación para el siguiente agente

1. **Caso real**: tareas «mejorar fotos de stock para web AURO» desde conversación educativa => owner `Auro-3D`, no `impresion-3d-lab`. Se permite derivado interno y consumer `auro-tech` solo luego de aprobación.
2. **Negativo**: ejercicio calibración/primer Benchy en laboratorio => dueño educativo; no carga memoria comercial ni mueve materiales.
3. **Negativo**: branding del logo D2 AURO TECH => `auro-tech` sin migrar a AURO 3D.
4. **Conflicto**: dos proyectos declaran owner incompatible de la misma identidad/scope => bloquear/abstener y pedir evidencia específica, no elegir por similitud léxica.
5. **Idempotencia**: replay con el mismo source hash ya copiado y manifest presente => no repetir importación ni modificar evidencia.
6. **Fallo a mitad**: copia sin verificar, manifest/cambio de puntero fallidos, hashes contradictorios, origen inaccesible => no `committed`; journal resumible o rollback explícito.
7. **Trazas**: no reasignar traceId del laboratorio al proyecto comercial, y no vincular éxito a otra transacción solo por compartir fecha/nombre.
8. **Contexto selectivo**: en lectura de un proyecto aislado no se inyecta la guía de transacción completa; en mutación cross-repo se carga núcleo y unidad específica, con presupuesto y receipts válidos.
9. **Host parity**: fixtures codex-local vs chatgpt-web exigen mismas decisiones puras con evidencia equivalente; host mantiene ejecución y permisos.
10. **Privacy**: hashes, rutas necesarias y ref sin tokens, sin adjuntar archivos/clientes/URLs firmadas a telemetría o aprendizaje.
11. **Aviso previo a la herramienta**: desde un contexto AURO 3D, una solicitud de crear un GIF/animación debe mostrar la derivación propuesta a AURO Motions con referencia a la regla de ownership; no necesita mover un archivo para mostrarla. Una consulta read-only sobre inventario permanece en AURO 3D. Owner desconocido o conflictivo no produce un reroute silencioso. Verificar selección de evidencia y entrega visible en Codex; la prueba del evaluador portable por sí sola no acredita adopción del host.

## Implementación sugerida y propietarias

- **MSSR portable (owner semántico):** tipo/validador/proyector y fixtures de `CrossRepoOwnershipTransaction`; integrarlo con ownership claims declarados, C2c y trace lifecycle; actualizar docs/decisions, versioned changelog y `npm run verify` antes de marcar integrado.
- **Bridge host (owner operacional):** observador de fuentes y owners, staging/copy+SHA, journal de ejecución/readback, `project_context_load` sobre roots candidatos, callbacks de outcome y receipts. Gate previo a mutaciones de alto riesgo; no hacer de Bridge un segundo motor de reglas.
- **mauroprime-skills (procedimiento):** revisar reutilización de skill existente antes de agregar nueva; incluir resolución de dueño y handoff gates en un `context-modules.json` selectivo o guide global apropiado. Actualizar routing tests/fuentes solo cuando cambien triggers.
- **Proyectos consumidores:** Auro-3D declara autoridad comercial en AGENTS/.mssr y conserva las fuentes; auro-tech es consumidor de export aprobado; lab es curso y origen histórico.

## Verificación de expansión y presión de memoria (12/11)

El ensamblador de contexto selectivo **sí está implementado**: `context-modules.json` y las entradas `.mssr/knowledge` ya permiten carga condicional. En prueba real `project_context_load`, el nuevo módulo de ownership y el estado de handoff se seleccionaron para `asset/repository + cross-agent + conflicto + mutación`, pero **no** para revisión read-only del router sin cruce de proyectos. Esto comprueba *selección*, no enforcement/pre-write ni retención de la información por el agente.

`project_context_health(D:\\Dev\\mssr)` informó `manifestStatus=valid`, **50 módulos** y nivel global `review` por `many-modules` y algunos módulos próximos al presupuesto. No aumentar budgets ni cargar todo permanentemente para solventarlo: evaluar agrupación/refs selectivos en una tarea de mantenimiento independiente. El módulo nuevo permanece opcional/indexado; esa presión ya existente no autoriza reestructuraciones automáticas.

## Caso AURO 3D: traspaso de fases

**Estado:** caso de campo y propuesta de evaluación. AURO 3D verificó el handoff y sus referencias; el modelo, laminado y ensayo siguen pendientes. Los datos de producto viven en el handoff dueño `D:/Dev/Auro-3D/docs/HANDOFF-BLENDER-ORGANIZADOR-2026-11-13.md`.

- **Otro chat, mismo trabajo:** recuperar el último estado, referencia/revisión y siguiente paso con Project Context. Usar `taskKey` si el host lo conoce explícitamente.
- **Blender → Bambu Studio → ensayo:** mismo dueño comercial; replanificar y registrar versión de entrada, salida verificada, evidencia, criterio de aceptación y próximo paso. Laminar, imprimir y ensayar son resultados separados. El ensayo declara condiciones, método, observaciones y alcance.
- **Producción audiovisual a AURO Motions:** usar `CrossRepoOwnershipTransaction v1`, traza propia del destino, referencias mínimas y entrega aprobada de vuelta por enlace.

Evaluar primero el módulo existente y sus referencias, las memorias y el contexto del dueño. Probar que la recuperación encuentra el dato vigente, omite contexto ajeno, trata referencias ausentes o desactualizadas como pendientes y no duplica entregas en reintentos. Si falta solo recuperación, ajustar selección; si faltan evidencias verificables de traspaso, evaluar un recibo acotado del host. Una capacidad nueva requiere un hueco reproducible. No se afirma detección automática ni adopción del guard en Bridge.

## Continuidad y límites

## Implementación portable MSSR v1 (2026-11-12)

- `src/cross-repo-ownership-transaction.ts` contiene schemas estrictos, el evaluador puro `evaluateMssrCrossRepoAssetOwnership` y el validador `validateMssrCrossRepoOwnershipTransition`.
- `mssr_cross_repo_ownership_evaluate` y `mssr_cross_repo_transaction_transition_validate` se registran en el contrato Project Control común; los adaptadores native, Codex y OpenCode comparten esas decisiones.
- El evaluador entrega `advisoryOnly: true` y `authorizationGranted: false` en todas las salidas. No inspecciona filesystem ni ejecuta writes. Un `review-required` o `blocked` detiene el flujo del agente que respeta el contrato; un host sin integración puede ignorarlo.
- El validator exige hash staged/source para `copied`, source/readback para `verified`, source/staged hash coincidentes para retomar desde `rollback-needed`, y estado `pointer-updated` más un receipt acotado antes de `committed`; admite `rollback-needed -> aborted` como ruta de aborto.
- El fixture portable usa IDs `Auro-3D`, `impresion-3d-lab` y `auro-tech`. Cubre owner ambiguo y conflictivo, export AURO TECH con scope aprobado, hash duplicado, destinos conflictivos, rutas traversal, trace IDs distintos, hash/readback divergente, commit prematuro y recuperación.
- La prueba `test:project-control-contract` también comprueba paridad de schema y resultados en los tres MCP portables. `npm run verify` pasó en build `mssr-build:sha256:25f8a5814f8ec38a`.
- El contrato de agentes y la plantilla managed indican preflight antes de una mutación; eso no intercepta herramientas genéricas de filesystem/terminal. Bridge debe adoptar el gate y demostrar bloqueo antes del write, journal, replay idempotente, readback, compensación y recuperación física. Hasta entonces, no afirmar protección automática.

MSSR reutiliza Project Context/context-module selection, las claims explícitas del Situation Model, separación de `traceId` del lifecycle existente y el presupuesto/context economy existente. No añade almacén de memoria ni transacción distribuida propia.

Project Context Health al cierre reporta manifest válido, 51 módulos, nivel `review` por `many-modules` y un módulo por encima del umbral de revisión; los dos módulos cross-repo permanecen selectivos y dentro de presupuesto. No se aumentó el presupuesto para esta incorporación. La agrupación de módulos, el tamaño de `mssr-module-handoff-capability-escalation` y cuatro handoffs de estado no indexados quedan como mantenimiento separado, no como parte de este guard.

**Evidencias actuales:** `D:\Dev\Auro-3D\marketing\fotoproductos\compra-flexi-2026-11-11\HANDOFF-MSSR.md` + `manifest.json`; `D:\Dev\Auro-3D\compras\flexi\evidencias\2026-11-11\MANIFEST_FOTOS.json`; `D:\Dev\bridge-mcp\docs\HANDOFF-IMAGE-ASSET-IMPORT-2026-11-12.md`.

**Criterio de terminado:** no solo que exista este documento. Requiere implementación portable testada, integración host con gate real, prueba de dos owners, prueba de recuperación, adopción de versión MSSR por Bridge y comprobación de que el guard evita escrituras equivocadas. La evidencia más reciente del candidato Bridge instala MSSR 0.2.147 (no 0.2.148) y Bridge 0.6.186 añade un gate host limitado probado con dos owners; el runtime observado sigue en Bridge 0.6.185 y no prueba ejecución. La transacción completa (staging, journal/receipt, replay, readback, rollback y recuperación) sigue pendiente.

**Traza documental:** `mssr-20261112040215-ef4e77f7-246`; agente futuro debe iniciar traza propia y registrar relación, no usurpar esta identidad.

## Adopción Bridge comprobada — 2026-11-13

- Bridge instaló el tarball revisado `@mauroprime/mssr` 0.2.147, SHA-256 `007951A27E409F4F3B0CA872FDE54294F4DBB96E296D40FA85AA413B0E9295D3`. La versión que tenía Bridge era 0.2.134; el ownership contract aparece desde 0.2.142. MSSR 0.2.148 no se instaló según esta observación.
- MSSR 0.2.149 añade la revisión de adopción de instrucciones compartidas; no modifica el contrato de transacción entre repos ni consta instalado por Bridge. El owner de Bridge debe verificar su adopción por separado.
- Bridge 0.6.186 agrega metadatos `crossRepoOwnership` al fallback `bridge_tool_action`. Antes de `write_text_file`, valida el dictamen MSSR (que sigue siendo consultivo), traza actual del target, traza relacionada distinta del source, owner esperado, raíz de destino cuyo nombre coincide con el proyecto, referencia relativa exacta y destino inexistente. La confirmación exacta `confirmToolName` sigue obligatoria.
- Fixture descartable: `D:\Dev\Auro-3D` es dueño de `commercial-data/offer.json`; `D:\Dev\auro-3d-web` es dueño de `exports/offer-summary.json`. Sin `explicitCopyReview`, el writer no se invoca ni crea archivo; con revisión, owner y ambas trazas verificadas, la escritura de prueba llega al panel. Ambas trazas permanecen separadas.
- Verificación Bridge: `npm run check`, `npm run build`, `npm run test:mssr-bridge-integration`, `npm run test:mssr-context-continuation`, `npm run test:project-health`, `npm run test:project-context` y `npm run docs:tools:check` pasaron en 0.6.186. La suite MSSR se repitió tras sumar recuperación de una ruta persistida luego de reset de memoria del coordinador; mismo owner/workflow pudo escribir en fixture nuevo. Project Context Health reporta manifest válido, WATCH, 31 módulos y ninguna señal de nivel alto; siguen avisos de agrupación/presupuesto.
- Runtime readback: 2026-11-13 15:51Z, Bridge 0.6.185 PID `26100`, boot `af13f224-3575-43d3-a9c2-984cd889f941`, `/readyz` Bridge/túnel listo, runtime health `ok`, restart pending `false`. No se reinició; 0.6.186 no está activo.
- Alcance: el gate protege esta ruta declarada, no todas las herramientas filesystem/terminal. No implementa todavía staging, journal/replay, readback, rollback ni recuperación, y no equivale a transacción distribuida.
