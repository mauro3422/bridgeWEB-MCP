# Handoff MSSR — fricción en bootstrap de repositorios nuevos (2026-11-13)
**Estado (2026-11-13):** fricción resuelta en el candidato local Bridge 0.6.186 con Notice Plane e historial deduplicado; el runtime activo sigue en 0.6.185. La causa exacta del `traceId=null` histórico después de un bootstrap sigue sin reproducirse. Una prueba nueva demuestra recuperación de una ruta Bridge persistida tras perder la memoria del coordinador, para el mismo owner/workflow.
**Dueños:** semántica/routing en `D:\Dev\mssr`; ejecución, transporte, preflight y avisos en `D:\Dev\bridge-mcp`; caso consumidor `D:\Dev\auro-3d-web`.
## Evidencia observada
1. Se decidió separar `D:\Dev\Auro-3D` (datos comerciales) de `D:\Dev\auro-3d-web` (panel privado). Preexistían los mecanismos de ownership y Project Context. El guard automático de split/pre-write todavía no está demostrado desplegado; ver `docs/CROSS_REPO_OWNERSHIP_TRANSACTION_HANDOFF_2026-11-12.md`.
2. En la sesión original, `project_context_initialize` y `write_text_file` rechazaron la creación con `executed:false`, `status:mssr-lifecycle-preflight-required`, `traceId:null`, `routePresent:false` y `reasonCodes: managed-trace-missing, side-effectful-operation`. Sus esquemas no incluyen `traceId`. La reproducción nueva separó los casos: sin ruta activa, ambos se bloquean con `traceId=null` y no escriben; tras `project_context_load` + bootstrap compatible, `project_context_initialize` en la misma sesión hereda una traza y se ejecuta. Esto explica el fixture sin ruta, pero **no identifica por qué el reintento histórico posterior al bootstrap conservó `null`**.
3. El host pudo crear directorio mediante `run_command` con `traceId=mssr-20261113040647-9a6225ff-72e`; scaffold Vite y fuentes mediante `terminal_start`/`terminal_write`, traza destino `mssr-20261113041003-0fba5d0f-97c`. Fue recuperación manual del host, **no** prueba de reparación del bootstrap.
4. Otro intento de comando PowerShell codificado devolvió `spawn ENAMETOOLONG` por longitud del comando; al usar terminal persistente se evitó. Es fricción distinta.
5. `bridge_notice_history(since 2026-11-13T04:06Z)` devolvió avisos `tool-call-failed` de ENAMETOOLONG y `mssr-web-outcome-missing-after-idle`. **En el resultado consultado no aparecieron avisos históricos específicos para los rechazos `mssr-lifecycle-preflight-required`**. No implica que nunca se emitieran en otro canal.
6. Usuario reclama que el **módulo de fricción debió manifestarse al siguiente tool call**. El problema a demostrar es el enlace entre `tool denial -> notice -> trace friction -> siguiente skill bootstrap`, no necesariamente la ausencia de un motor de detección.
## Hipótesis y límites
- Falta o falla la correlación de `projectRoot/traceId` en herramientas sin argumento de traza. No migrar trazas entre proyectos; guardar relación por handoff explícito.
- El preflight podría devolver error estructurado sin emitir Notice durable o perderse en auto-drain; verificar en dispatcher, `bridge_notice_history` y `mssr_trace_record` con un fixture aislado.
- El clasificador de fricción podría no consumir rechazos de ciclo de vida porque son respuestas operacionales, no eventos normalizados. No convertir errores benignos aislados en tareas persistentes.
- MSSR sigue siendo consultivo. Ningún aviso concede permiso para eludir preflight o escribir en otro repo.
## Propuesta de contrato de observabilidad (API MCP o contrato de eventos, no necesariamente API HTTP)
- `OperationAttempt`: id/fecha, host/tool, owner origen/destino, stage, traceId nullable, workflowKey, effect, executed, status, reasonCodes, noticeId.
- `FrictionCandidate`: errorCode normalizado, intent y contexto estructurados (no raw prompts), repeatCount, evidenceRefs, recoveryAttempted, resolved/blocked, nextGate, TTL.
- `FrictionReceipt`: relación entre intento -> notice -> checkpoint `eventType=friction` -> próxima skill/guía seleccionada -> resultado verificable.
- Privacidad: no volcar rutas privadas completas, secretos ni conversaciones en aprendizaje; usar IDs opacos. Reutilizar Notice Plane, trace records y `mssr-observability-maintenance` / `capability-gap-recovery` antes de crear módulo nuevo.
## Casos de aceptación
1. Repo inexistente -> bootstrap -> `project_context_initialize` y `write_text_file` -> causa y trace correlacionables, o bloqueo accionable sin bucle.
2. Preflight denial -> history -> checkpoint friction -> siguiente `skill_bootstrap`: demostrar detección, selección contextual y entrega.
3. Repetición/dedupe: el mismo error repetido no infla memoria; ENAMETOOLONG no se agrupa con falta de trace.
4. Cross-repo: traza destino nueva; origen como `relatedTraceId`, jamás reutilizar identidad de dueño.
5. Negativo: consulta read-only sana no activa módulo de fricción.
6. Reinicio del host: recuperar recibos si persisten; reportar límites de retención.
**Próximo agente:** no repetir la corrección Notice Plane ni el fixture de recuperación ya probados. Si se retoma el `traceId=null` histórico, capturar en el mismo Bridge si el bootstrap fue observado, qué owner/workflow recibió la llamada posterior y si había una ruta compatible en su ledger. Añadir o modificar una regresión sólo si reproduce el caso; mantener la causa como no resuelta hasta entonces. La activación de 0.6.186 y la transacción física completa son trabajos separados.
## Hallazgo adicional en la validacion del nuevo repo
- `project_context_health({projectRoot:'D:/Dev/auro-3d-web'})` tambien fue denegado con `status=mssr-lifecycle-preflight-required`, `effect=inspect`, `scale=substantial`, `traceId=null`, `managed-trace-missing`. La brecha afecta incluso un diagnostico read-only sustancial. Se valido manualmente el manifest (4 modulos, secciones en fuentes presentes), pero **esto no sustituye Project Context Health ni acredita su resultado**.
- La herramienta `mssr_trace_record(eventType=friction)` si registro eventos para las trazas MSSR y AURO 3D WEB, evidenciando que la captura de friccion puntual es posible; falta comprobar su consumo automatico en el siguiente bootstrap.

## Capacidad existente descubierta antes del cierre
- Existe `mssr_trace_evidence({traceId,limit})`, una herramienta MCP de Bridge que ya reconstruye `lifecycle`, `tools.calls`, `events`, `evidenceRefs`, version de runtime y checkpoints por traza. Probada en las trazas `mssr-20261113041003-0fba5d0f-97c` (scaffold web) y `mssr-20261113041649-d2a4d880-1ce` (diagnostico MSSR).
- La traza web recupero 42 llamadas correlacionadas (41 OK y 1 error `spawn ENAMETOOLONG`) y outcome cerrado exitosamente. La traza del diagnostico mostro los checkpoints `friction`, `verification`, `persistence` y un gate de cierre; esto demuestra que hay observabilidad de trazas existente.
- No se encontraron en el bundle de la traza web las invocaciones denegadas de herramientas que devolvieron `traceId=null`. Es consistente con que la asociacion de preflight sin traza a una operacion concreta sea el hueco, **pero no prueba perdida de todo evento**: auditar dispatcher y telemetria global por `session_key`, timestamp y herramienta.
- **Revisar alcance de cualquier API nueva**: preferir ampliar el contrato de eventos/notice + correlacion de herramientas sin trace antes de inventar otra API de lectura. Una API adicional solo si fixture demuestra falta de un endpoint/consulta indispensable.


## Reanudación operativa

**Bridge 0.6.186 (candidato):** el owner reporta Notice Plane para el rechazo preflight, dedupe y entrega al bootstrap compatible. Los tests del candidato cubren bloqueo antes del writer, repetición, aislamiento de owners/trazas, lectura sana y recuperación tras resetear memoria del coordinador. Runtime observado: 0.6.185, saludable; 0.6.186 no está activo.

**Límite:** resetear el coordinador no reproduce el `traceId=null` histórico si existe ruta persistida para el owner/workflow. Su causa sigue sin resolver. El ownership guard cubre una ruta declarada `bridge_tool_action` → `write_text_file`, no todos los writers.

Bridge reporta instalado MSSR 0.2.147; el readback es anterior a 0.2.149. Pendiente host: adoptar/readback de 0.6.186. Pendiente transacción completa: staging, receipt/journal, readback, rollback y recuperación.
