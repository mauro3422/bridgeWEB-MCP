# Proactive project knowledge detection

## Purpose

Connect the existing project health, context freshness, and project-knowledge maintenance classifier to the project activation boundary. This is a detector and advisory source, not a writer or a second notice queue.

## Ownership map

- Project-local checklists, visual patterns, architecture, decisions, and current status: each repository's `.mssr/project-context.json` and its canonical files under `.mssr/` / PROJECT_*.
- Broad repository instructions: repository `AGENTS.md`.
- Reusable cross-project procedure: the owning skill and its selected references; routing and fixtures remain under MSSR's skill-routing contract.
- MSSR contract/fixtures: only when activation semantics, portable schemas, or cross-host routing behavior changes.
- Delivery and deduplication: host-owned Operational Notice transport/state. MSSR returns advisory evidence and never creates a second queue.

## Activation flow

On `start` or `resume` with a resolved `projectRoot`, the route already loads project context. MSSR additionally reads Project Context Health and invokes `evaluateMssrProjectKnowledgeMaintenance` with only observable facts (initialization state, health level, stage, and structured intent). The route response includes `projectMaintenance` with level, targets, canonical authority, reasons, and recommended skills. REVIEW/REQUIRED identifies a visible maintenance review; WATCH remains informational. The host may pass that stable advisory through `mssr_operational_notice_evaluate` and deliver/dedupe it through its existing notice transport.

The detector does not scan sibling repositories, infer a missing list should be created, promote a visual preference from repetition, write AGENTS/PROJECT_*/skills, or mark work complete. At later meaningful phase boundaries, hosts may pass `projectMaintenanceEvidence`: root-relative changed paths, material-write count, bounded tool names, package/runtime/routing/skill-structure flags, freshness-conflict count, and user-correction count. MSSR returns the same owner-aware advisory plus `projectMaintenanceAttention` (stable fingerprint, level, canonical targets). Hosts should pass REVIEW/REQUIRED through `mssr_operational_notice_evaluate` and their existing deduplicated transport; WATCH remains informational. Evidence is metadata only; no file content or raw command output is accepted.

## Activation and negative cases

- Uninitialized project or health REVIEW on project activation returns a context maintenance target and `skill-maintenance-loop` recommendation; it does not initialize or edit the project.
- Healthy initialized project with no maintenance signals returns `level=none` and no due work.
- WATCH remains advisory and does not require a maintenance close gate.
- No `projectRoot`, unrelated project, or ordinary later-stage call does not run the activation scan.
- Existing source verification confirms that project checklists and visual modules stay selected by their own project manifest.

## Verification limits

Portable route output is not proof that a host showed a notice. Hosts must consume `projectMaintenance`, call the shared notice evaluator when appropriate, and use their existing notice delivery/readback. No host should persist project facts outside their canonical project owner.
