# Handoff — Event-driven triggers / webhook-capable hosts

Date: 2026-08-28
Status: MSSR portable evaluator Slice 1 implemented and verified in local source 0.2.157. Codex readback after restart reports loaded=available 0.2.157 (`current`) with the evaluator tool exposed; a synthetic live allow/deny check is recorded below. Provider adapters, durable receipt persistence, subscriptions, polling enforcement, and end-to-end event runs remain unimplemented/unverified.

## MSSR portable slice update — 2026-11-13

### Codex live readback — 2026-11-13 ART

After the user's restart, `skill_bootstrap` reported loaded=available `mssr-build:sha256:5fe4a5e2897644c8` (0.2.157, `current`) and the live tool catalog exposed `mssr_event_trigger_evaluate`. A synthetic verified/fresh `project.updated` event from the explicitly accepted test source returned `matched`; changing only the trigger selector to `project.deleted` returned `ignored` / `event-type-not-accepted`. Both responses had `advisoryOnly=true`, `routingInfluence=false`, and `executionAuthorized=false`. This verifies live evaluator availability and pure selection only; the proposed receipt was not persisted, and no host subscription, provider ingestion, action, or outcome was exercised. Observation timestamp: `2026-11-14T02:53:56Z`.

MSSR now exports `evaluateMssrEventTrigger` from `src/event-trigger.ts` under contract `mssr-event-trigger-evaluation-v1`. It accepts strict bounded event metadata, a selector-bounded trigger specification with the existing structured routing-intent schema, an explicit evaluation time, and an optional prior receipt. It returns `matched`, `ignored`, `duplicate`, `stale`, or `unsupported`, with a stable hashed event fingerprint, bounded intent, capability needs, and (only on a match) a receipt proposal. The output always has `advisoryOnly=true`, `routingInfluence=false`, and `executionAuthorized=false`.

The evaluator rejects raw event-body fields, requires verified or host-verified authenticity and available source health for native event modes, checks event age/future skew and cooldown, and deduplicates accepted events by source plus provider event ID (or dedupe key) inside a bounded window. `poll-fallback` requires an explicit degraded source, cadence/backoff evidence, and trigger-declared maxima; its route intent carries `degraded-capability`. No host schedule, exponential backoff loop, storage, webhook listener, secret handling, automatic route invocation, or action was added.

**Verification scope:** `scripts/test-event-trigger.mjs` exercises positive matching, duplicate redelivery, cooldown, stale/future/unverified/unavailable inputs, selector negatives, fallback bounds, trigger-scoped receipts, and raw-body rejection. `npm run verify` and `npm run release:gate` pass for source 0.2.157; `.mssr/runtime/releases/0.2.157.json` is the current local artifact receipt. This proves the portable evaluator/package candidate, not host adoption. The remaining acceptance matrix below requires host-owned adapters and live evidence. The earlier 0.2.155 readback was superseded: Codex now reports loaded=available 0.2.157 (`current`), exposes the evaluator, and passed the synthetic allow/deny check recorded above.

| Acceptance slice | MSSR source/test status | Host/runtime gate |
|---|---|---|
| Native/provider-notification/local-runtime event normalization and matching | Pass in the shared pure evaluator fixtures | Real provider ingestion/authentication remains unverified |
| Duplicate accepted event and retry | Pass by source + type + event ID (or dedupe key), with bounded prior receipt | Host must persist the proposed receipt and demonstrate restart recovery |
| Stale/future/unverified/unavailable input | Pass: stale/unsupported, no route intent | Host must preserve and display the decision/evidence |
| Poll fallback | Pass only with declared cadence/backoff bounds; route gets `degraded-capability` | Host must enforce cadence/backoff and report degraded capability; MSSR is not a scheduler |
| Shared evaluator across server variants | `test:host-conformance-cross-host` passes equal results for native, Codex, and OpenCode server source wrappers | Codex live MCP 0.2.157 tool is present and synthetic allowed/negative evaluations pass; Bridge/ChatGPT Web adoption and real provider ingestion remain unverified |
| Event → route → authorized action → verification/outcome | Not performed | Host-owned end-to-end acceptance remains open |

## Why this exists

Current scheduled/condition watches are useful when a source has no push channel, but they spend work checking even when nothing changed. The desired direction is to let a host react immediately when an authorized provider can emit an event, while preserving polling as an explicit fallback for sources that cannot.

Concrete motivating case: ChatGPT Web can run a periodic Smartwatch GPS Workshop watch, but Steam Workshop metrics do not currently provide us with a native event source through the active host. The same architecture should also work for connected apps that do expose real events, local Bridge providers, MCP notifications, GitHub/Slack/Gmail-style webhook sources, filesystem/runtime events, or future providers.

## Architectural boundary

MSSR must remain portable, deterministic/advisory and I/O-free. **MSSR should not become the webhook HTTP server, secrets vault, polling daemon, or execution proxy.**

Recommended ownership:

1. **Host/provider adapter (Bridge, Codex host, ChatGPT-connected app, other runtime)** receives or observes the external event and authenticates it.
2. Host normalizes only safe metadata into a portable `EventEnvelope`; secrets/raw bodies stay host-owned.
3. **Portable MSSR** evaluates the event against a bounded trigger/watch specification and returns advisory trigger intent/reasoning metadata.
4. Host performs the authorized action and records trace/evidence/outcome through the existing MSSR lifecycle.
5. If the provider has no event capability, the host may use a bounded polling adapter; this must be represented as fallback/degraded capability rather than pretending a webhook exists.

## Proposed portable contract

Illustrative shape; names are not frozen:

```ts
type EventEnvelope = {
  source: string;          // provider/adapter identity
  eventType: string;       // stable provider-independent or namespaced type
  eventId?: string;        // provider event id when available
  subject?: string;        // resource/watch target
  observedAt: string;
  occurredAt?: string;
  dedupeKey: string;
  cursor?: string;
  freshness?: "fresh" | "stale" | "unknown";
  authenticity?: "verified" | "host-verified" | "unknown";
  payloadRef?: string;     // opaque host-owned reference; no secret/raw payload
  metadata?: Record<string, string | number | boolean | null>;
};

type TriggerSpec = {
  id: string;
  acceptedSources?: string[];
  eventTypes?: string[];
  subject?: string;
  condition?: unknown;     // bounded portable condition representation
  cooldownMs?: number;
  dedupeWindowMs?: number;
};
```

Portable evaluation should be a pure function roughly equivalent to:

```text
evaluateTrigger(eventEnvelope, triggerSpec, priorReceipt)
→ matched | ignored | duplicate | stale | unsupported
→ normalized intent/signals/capability needs
→ bounded reason/evidence receipt
```

## Required invariants

- Event receipt does **not** grant permission to execute tools.
- Provider authentication/secrets remain host-owned.
- No raw email/message/webhook body, credentials, conversation transcript or hidden reasoning in MSSR telemetry.
- Idempotency is mandatory: duplicate delivery must not create duplicate tasks/actions.
- Preserve event provenance, source health, observed time and freshness.
- Distinguish `native-event`, `provider-notification`, `local-runtime-event`, and `poll-fallback` in evidence.
- A polling fallback must have bounded cadence/backoff and should be replaced by native events when the provider later exposes them.
- Re-plan/skill routing may be triggered by an accepted event, but the resulting route remains advisory and follows the normal trace contract.
- Event-triggered runs must still produce verification/persistence/outcome checkpoints when they mutate durable state.
- Hosts must be able to disable/unsubscribe a trigger without changing portable routing semantics.

## Bridge adoption candidate

Bridge is the natural first local host adapter because it already owns runtime/provider observation and the Notice/trace plumbing. A future Bridge patch could expose a small provider-event registry and normalize supported sources before calling MSSR. Do not hard-code ChatGPT-specific webhook schemas into portable MSSR.

Useful source classes to test:

- MCP `notifications/tools/list_changed` / provider catalog changes;
- filesystem/process/runtime events already observable locally;
- GitHub/connected-app events when an authorized connector supplies them;
- a synthetic deterministic event provider for fixtures;
- a negative provider that exposes no events, proving clean `poll-fallback` behavior.

## Steam Workshop note

Do not assume Steam Workshop can push subscriber/ranking changes. If no authenticated/native event source exists, Workshop metrics remain a polling/watch problem. MSSR can still normalize the resulting observation and avoid redundant downstream work through dedupe/change receipts, but it cannot manufacture a webhook that Steam does not expose.

A later adapter could reduce cost with lightweight conditional requests/change fingerprints before doing a full scrape, if Steam/public endpoints safely support that.

## Suggested implementation sequence

1. Add a portable event envelope + pure trigger evaluator with fixtures and cross-host conformance tests.
2. Add dedupe/receipt semantics and trace integration without execution authority.
3. Add one synthetic/native provider adapter in Bridge and prove end-to-end event → route → outcome.
4. Add a polling-fallback adapter and prove the evidence explicitly says fallback rather than native event.
5. Only then expose host UX/API for creating, listing, disabling and inspecting event-triggered watches.
6. Document security, privacy, retry/backoff and provider-health behavior.
7. Version the MSSR semantic change with a changelog and update PROJECT_CONTEXT/MEMORY/STATE as required by `AGENTS.md`.

## Acceptance matrix

- duplicate event delivered twice → one accepted trigger;
- stale event → ignored or marked stale by policy;
- bad/unverified source → no implicit action;
- native event → no periodic poll required;
- no-event provider → bounded polling fallback works and is labeled fallback;
- host restart → durable subscription/receipt state resumes without replay storm;
- event matches but required capability is unavailable → normal MSSR missing-capability/replan path;
- mutation caused by event → normal verification/persistence/outcome lifecycle;
- native/Codex/OpenCode/Bridge conformance uses the same portable evaluator even if transport differs.

## Non-goals for the first patch

- turning MSSR into a general automation scheduler;
- storing webhook secrets;
- replacing provider-specific authentication;
- executing arbitrary tools directly from event metadata;
- promising push semantics for providers such as Steam that do not expose a usable event channel.

## Resume instruction

When this work is picked up, load `docs/AGENT_PROTOCOL.md`, this handoff, current provider/Notice Plane architecture and the active release state. Re-plan as an MSSR semantic change, create the versioned changelog before persistence, and keep Bridge as an adapter rather than portable semantic owner.
