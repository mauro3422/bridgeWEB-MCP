# Incidente MSSR — recuperación de resultados físicos Tollerance-Test (12/11/2026)

**ID:** MSSR-CONTINUITY-TOLLERANCE-20261112
**Clasificación:** omisión de contexto ya persistido / recomendación redundante, con entrega de contexto incompleta. **No es evidencia de pérdida de bytes ni prueba de bug del motor portable.**
**Estado:** incidente documentado; mitigación en owner educativo verificada; mejora sistémica **pendiente de evaluación**; sin modificación de código o versión MSSR.
**Trazas:** reporte owner MSSR `mssr-20261113022045-5d813f83-1b1`; reparación de módulo en owner lab `mssr-20261113021751-99ba5f09-f3f`.

## Reproducción observable

1. El 05/11/2026, el usuario imprimió `Tollerance-Test.3mf` de [MakerWorld 423905](https://makerworld.com/models/423905) en su Bambu A2L con PLA Lite azul (50 capas, 37m41s y 11,60g previstos; telemetría FINISH).
2. **El resultado físico sí fue documentado** en `D:\Dev\impresion-3d-lab\BITACORA.md`, sección `Observación física de la prueba de holguras`, líneas 687–693, y resumido en `PROGRESO.md`, entrada `Prueba de holguras terminada (2026-11-05)`, línea histórica 57.
3. Observaciones del usuario: marcas 35/30/25 móviles y extraíbles/reinsertables; marca 20 gira libre; 15 se liberó con roce/trabas ocasionales; marca 10 inicialmente bloqueada, luego liberada con mucha fuerza y deformación, giro lateral. No interpretar cifras como milímetros sin verificar la geometría ni generalizar la tolerancia a insertos de 650 ml.
4. En el chat comercial de AURO 3D posterior, el asistente propuso repetir una prueba de holguras genérica, habló como si no existiera prueba física y confundió temporalmente este test con las plaquitas de translucidez y con los anillos paramétricos Blender no impresos. El usuario corrigió reiteradamente la respuesta.
5. La inspección de fuentes exactas recuperó los resultados que ya estaban persistidos; no hubo necesidad de volver a imprimir, pedir de nuevo el testimonio ni reconstruir telemetría.
6. La búsqueda de conversaciones anteriores fue parcial: hay constancia del ensayo, pero no se recuperó el intercambio literal completo ni archivo original de una fotografía con hash. Fotos de `/Bambu-3D` del 05/11 fueron inspeccionadas, pero no se identificó de forma inequívoca la imagen de la pieza circular en esas coincidencias. **No afirmar cobertura completa de chats o prueba visual independiente.**

## Análisis de causa y responsabilidades

- **Dato canónico: EXISTÍA.** No corresponde clasificar como fracaso del guardado inicial. `BITACORA.md` y `PROGRESO.md` conservaban resultados en secciones posteriores a entradas de estado temporal `impresión no confirmada / movilidad pendiente`.
- **Disciplina de consulta del host: INSUFICIENTE.** `D:\Dev\impresion-3d-lab\AGENTS.md` ya ordenaba consultar `PROGRESO.md`, `PLAN_DE_ESTUDIO.md` y la lección activa, y no avanzar sin evidencia. El asistente priorizó contexto resumido/no concluyente y no verificó la entrada final de `BITACORA.md` antes de recomendar otra impresión.
- **Activación selectiva: COBERTURA MEJORABLE.** El manifiesto `.mssr/project-context.json` no indexaba un módulo específico con resultados de esta práctica, por lo cual `project_context_load` devolvía contexto general sin la observación terminal del 05/11. Esto no prueba que el algoritmo de scoring portable falle: faltaba una unidad elegible asociada al intent.
- **Precedencia temporal: RIESGO ABIERTO.** Algunas líneas históricas del mismo día seguían diciendo «no confirmado». Faltó validar autoridad/fecha/fase frente a observaciones posteriores del mismo sujeto/impresión; no basta buscar el primer match o resumir el primer bloque.
- **Ausencia de recordatorio proactivo: HIPÓTESIS, no defecto probado.** El contrato MSSR ya incluye Context Plane, Project Context/Health, mantenimiento y skills de handoff. Evaluar cobertura/adopción antes de crear motor de recordatorios, agente nuevo, módulo global obligatorio o edit genérico de AGENTS.

## Mitigación ejecutada y verificada en el owner correcto

En `D:\Dev\impresion-3d-lab`:
- Nuevo módulo `.mssr/knowledge/reference/tollerance-test-fisico-20261105.md` enlaza la autoridad y preserva resultados físicos diferenciados.
- Nuevo índice selectivo `tollerance-test-fisico-20261105` en `.mssr/project-context.json`; `PROGRESO.md` ahora avisa al principio que la prueba está hecha y dónde está el resultado final.
- Prueba real positiva: `project_context_load` con intent `Tollerance-Test / prueba física de encastres` recuperó el módulo nuevo. Negativa: consulta específica de filamento Silk no cargó ese módulo. `project_context_health` no registró `unindexed-knowledge` para esta captura; mantiene otros avisos previos de presupuesto de contexto. No se enviaron impresiones ni se cambió el 3MF.
- El experimento nuevo de encastre de **inserto Flexi 650 ml** sigue siendo distinto: medir inserto real y generar pieza de ajuste específica, sin repetir el test genérico.

## Handoff — evaluación sistémica por owners

**No crear una skill paralela ni alterar la versión MSSR sin demostrar qué capa incumple.** Reusar `docs/HANDOFF_CONVERSATION_CANONICAL_RECONCILIATION_2026-11-12.md`, `AGENT_PROTOCOL.md`, `.mssr/knowledge/operations/mssr-project-knowledge-drift-review.md` y skill `mssr-module-handoff`.

1. **Host ChatGPT Web / Bridge — owner de activación y retrieval:** reproducir una consulta sobre «ya habíamos probado tolerancias, giraban las piezas» contra estado canónico. Comprobar secuencia proyecto correcto → contexto selectivo → búsqueda exacta en autoridad → síntesis con resultado físico final. Establecer checkpoint antes de sugerir repetir práctica/gastar material: **¿existe ya un resultado final para la misma identidad de prueba?** Si el historial no es accesible, decirlo, pero sí revisar repositorio dueño.
2. **MSSR portable — owner de contratos/selección, solo si una prueba lo justifica:** comparar intent estructurado, selección del módulo disponible, presupuesto y evidencia de omisión. En caso positivo nuevo, confirmar que `project_context_load` lo selecciona sin arrastrar documentos irrelevantes. Si falla con módulo indexado y criterios pertinentes, crear fixture positivo/negativo y corrección mínima. Si pasa, clasificar **host-adoption / consulta omitida**, no bug de scoring.
3. **Laboratorio — owner de hechos:** mantener `PROGRESO.md` como estado vigente y `BITACORA.md` como historia fechada; conservar módulo indexado, nombres originales (incluido typo `Tollerance`) y evidencia por marca. Sólo cambiar resultados tras observación nueva autorizada, no por telemetría inferida.
4. **Observer — índice transversal, sin mutar al dueño:** vincular el caso al seguimiento de continuidad/reconciliación `OBS-SYS-06` cuando se revise ese flujo; evitar generar un segundo backlog paralelo por cada conversación.

## Criterios verificables del siguiente agente

- **Positivo:** retomar Tollerance-Test devuelve resultados de 35/30/25/20/15/10, sin afirmar que 10 giró libre ni que la escala se comprobó en milímetros.
- **Negativo 1:** consulta de PLA Silk no activa la memoria de Tollerance-Test.
- **Negativo 2:** un ensayo diferente (plaquitas de translucidez; Blender Ø6 con holguras 0,2/0,3/0,5; prueba nueva anillo Flexi) no se fusiona con el test histórico.
- **Temporalidad:** frente a `pendiente` y `FINISH + comprobación física` del mismo trabajo, la respuesta usa la observación final, con fecha/procedencia.
- **Gobernanza:** resultado verificado → handoff indexado/readback → corrección del owner → adopción host observada, sin escritura automática a AGENTS, skill ni documentación por mero notice. Incertidumbre de fotos y del chat literal se mantiene explícita.
- **Cierre:** después de probar en un chat nuevo el selector y la lectura de autoridad final, documentar resultado y resolver/incorporar esta incidencia al handoff canónico. El reporte por sí solo no prueba reparación transversal.

**Prioridad:** media-alta como patrón de no repetir costos/material y correcciones del usuario, pero no bloquear el prototipo 650 ml ni crear tareas de infraestructura por encima de fabricar una primera pieza útil.
