import assert from "node:assert/strict";
import {
  CapabilityRegistry,
  FilesystemSkillProvider,
  planSkillRoute,
} from "../dist/index.js";

const registry = new CapabilityRegistry([new FilesystemSkillProvider()]);
const snapshot = await registry.refresh();
const skills = snapshot.capabilities.flatMap((capability) =>
  capability.kind === "skill" && capability.skill ? [capability.skill] : []);

assert.ok(skills.length > 0, "Filesystem provider returned no skills");

const readOnlyAudit = await planSkillRoute({
  task: "Auditar profundamente MSSR, routing, observabilidad y dashboard sin modificar nada.",
  intent: {
    summary: "Auditar MSSR de forma read-only con fricción observada.",
    domains: ["skill-system", "agent-orchestration", "coding"],
    actions: ["analyze", "review", "verify", "debug"],
    artifacts: ["mcp", "repository", "code"],
    needs: ["integrity-verification", "performance", "cross-agent"],
    signals: ["repeated-friction", "conflicting-evidence"],
    risk: "read-only",
    ambiguity: "low",
  },
  caller: "chatgpt-web",
  stage: "verify",
  completedPhases: ["discovery"],
  maxSkills: 16,
  skills,
});

const selectedReadOnly = [...readOnlyAudit.loadOrder, ...readOnlyAudit.deferredLoadOrder];
assert.equal(
  selectedReadOnly.includes("steam-workshop-publication"),
  false,
  `generic MSSR/coding audit must not select Steam Workshop publication: ${selectedReadOnly.join(", ")}`,
);
assert.equal(
  readOnlyAudit.coverage.requiredPhases.includes("maintenance"),
  false,
  `read-only observed friction must not create maintenance debt: ${readOnlyAudit.coverage.requiredPhases.join(", ")}`,
);
assert.equal(
  readOnlyAudit.semanticSignals.maintenanceRecommended,
  false,
  "read-only observed friction must not recommend maintenance by itself",
);

const maintenanceWork = await planSkillRoute({
  task: "Corregir y mantener el router MSSR después de fricción repetida.",
  intent: {
    summary: "Mantener el router MSSR después de fricción repetida.",
    domains: ["skill-system", "agent-orchestration", "coding"],
    actions: ["maintain", "edit", "verify", "test"],
    artifacts: ["skill", "code", "repository"],
    needs: ["unit-tests", "integrity-verification"],
    signals: ["repeated-friction"],
    risk: "write",
    ambiguity: "low",
  },
  caller: "chatgpt-web",
  stage: "verify",
  completedPhases: ["discovery", "safety", "implementation"],
  maxSkills: 16,
  skills,
});

assert.equal(
  maintenanceWork.coverage.requiredPhases.includes("maintenance"),
  true,
  "actual write/maintenance work with repeated friction must still require maintenance",
);
assert.equal(
  maintenanceWork.semanticSignals.maintenanceRecommended,
  true,
  "actual maintenance work must still recommend maintenance",
);

console.log(JSON.stringify({
  ok: true,
  readOnlyRequiredPhases: readOnlyAudit.coverage.requiredPhases,
  readOnlySelected: selectedReadOnly,
  maintenanceRequiredPhases: maintenanceWork.coverage.requiredPhases,
}, null, 2));
